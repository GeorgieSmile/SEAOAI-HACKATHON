setSearchContainer("header");
let eSearchV2 = document.getElementById("do-search-v2");
if (void 0 !== eSearchV2 && null != eSearchV2) {

    let e = "normal",
        t = localStorage.getItem("search_order");
    t ? e = t : document.querySelector(".sort-bar-btn.active") && (e = document.querySelector(".sort-bar-btn.active").getAttribute("data-order")),
        TTPSearch_v2(eSearchV2.dataset.keyword, e)
}
const SearchBtn = document.querySelector("#serp-btn:not(.processing)");
function getSearchKeyword() {
    return localStorage.getItem("search_keyword")
}
function getSearchProvider(e) {
    let t = document.getElementById("serp-provider");
    return "text" == e ? t.options[t.selectedIndex].text : t.options[t.selectedIndex].value
}
function hideSearch_Old() {
    document.getElementById("serp-con").style.display = "none"
}
function TTPSearch_v2(e, t, a, r) {
    var userText = $('header#header>.header-top>.container>span').text();
    var user_id = userText.substring(userText.indexOf(' ') + 1).replace('ttp', "");

    save_history_search(e, '1688', a, user_id);

    hideSearch_Old();
    let n = {};
    n.keyword = e, n.order = "", n.start_price = "", n.end_price = "", n.min_qty = "", n.sort_paged = "",
        r || (t ? n.order = t : document.querySelector(".sort-bar-btn.active") ? n.order = document.querySelector(".sort-bar-btn.active").getAttribute("data-order") : localStorage.getItem("search_order") ? n.order = localStorage.getItem("search_order") : n.order = "normal",
            a ? n.sort_paged = a : getSearchValue("sort-paged").length ? n.sort_paged = getSearchValue("sort-paged") : localStorage.getItem("sort_paged") && (n.sort_paged = localStorage.getItem("sort_paged")),
            getSearchValue("start-price").length ? n.start_price = getSearchValue("start-price") : localStorage.getItem("start_price") && (n.start_price = localStorage.getItem("start_price")),
            getSearchValue("end-price").length ? n.end_price = getSearchValue("end-price") : localStorage.getItem("end_price") && (n.end_price = localStorage.getItem("end_price")),
            getSearchValue("min-qty").length ? n.min_qty = getSearchValue("min-qty") : localStorage.getItem("min_qty") && (n.min_qty = localStorage.getItem("min_qty"))),
        localStorage.setItem("search_order", n.order), localStorage.setItem("start_price", n.start_price), localStorage.setItem("end_price", n.end_price),
        localStorage.setItem("min_qty", n.min_qty), localStorage.setItem("sort_paged", n.sort_paged), searchLoading(e), asyncGetSearch(n)
}
function getSearchValue(e) {
    let t = document.getElementsByClassName(e);
    return t[0] ? t[0].value.trim() : ""
}
async function asyncGetSearch(e) {
    // console.log(e)
    e.start = ttpGetTime();
    // console.log(1)
    // const t = new FormData;
    // t.append("action", "ttp_search_v111"), t.append("keyword", e.keyword), t.append("order", e.order),
    //     t.append("start_price", e.start_price), t.append("end_price", e.end_price), t.append("paged", e.sort_paged),
    //     t.append("start", ttpGetTime());
    // const a = new URLSearchParams(t),
    //     r = await fetch(ttp.ajaxurl, {
    //         method: "POST",
    //         mode: 'no-cors',
    //         credentials: "same-origin",
    //         headers: {
    //             "Content-Type": "application/x-www-form-urlencoded",
    //             "Cache-Control": "no-cache"
    //         },
    //         body: a
    //     });
    let z = {};
    // let d = (await r.json());
    // console.log(d)
    try {
        z = await ttp_search_v112(e) 
        console.log("E :",e)
        console.log("Z :",z)
    } catch (error) {
        console.log(error)
    }
    let t = {
        keyword: e.keyword,
        order: e.order,
        start_price: e.start_price,
        end_price: e.end_price,
        // quantity_begin: e.min_qty,
        paged: e.sort_paged
    };
    if (z.status == "success") {
        // console.log(2)
        generateSearchTemplate(z.data, t, z), localStorage.setItem("search_keyword", e.keyword)
    }else{
        generateSearchTemplate([], t, []), localStorage.setItem("search_keyword", e.keyword)
    }
    // if (r.ok) {
    //     console.log(2)
    //     let t = {
    //         keyword: e.keyword,
    //         order: e.order,
    //         start_price: e.start_price,
    //         end_price: e.end_price,
    //         // quantity_begin: e.min_qty,
    //         paged: e.sort_paged
    //     };
    //     generateSearchTemplate(d.data, t), localStorage.setItem("search_keyword", e.keyword)
    // }
}


async function ttp_translate_keyword_via_lambda(text) {
    text = (text || '').trim();
    if (!text) return '';

    try {
        const r = await fetch(
            'https://4bnzlzcd6vd3joycevdwlxaace0yzaay.lambda-url.ap-southeast-2.on.aws/',
            {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    text: text
                })
            }
        );

        const data = await r.json();

        return data.result || '';
    } catch (e) {
        console.error(e);
        return '';
    }
}



// ttp_searcg_v111 onebound
async function ttp_search_v112(e) {
    try {
        // console.log(e)
        let translated_keyword = "";
        if (e.keyword == 'กระเป๋า') {
            translated_keyword = '肩包';
        }
        else if (e.keyword == 'ชุดนอน') {
            translated_keyword = '睡衣';
        }
        else if (e.keyword == 'เสื้อผ้าเด็ก' || e.keyword == 'ชุดเด็ก') {
            translated_keyword = '婴儿服装';
        }
        else if (e.keyword == 'รองเท้า') {
            translated_keyword = '鞋子';
        }
        else if (e.keyword == 'กระเป๋าสะพาย') {
            translated_keyword = '单肩包';
        }
        else if (e.keyword == 'เสื้อผ้าผู้หญิง') {
            translated_keyword = '女装';
        }
        else if (e.keyword == 'ที่ใส่น็อต') {
            translated_keyword = '螺母架';
        }
        else if (e.keyword == 'พัดลม') {
            translated_keyword = '风扇';
        }
        else if (e.keyword == '') {
            let a = ["睡衣", "鞋子", "单肩包", "肩包", "婴儿服装"];
            translated_keyword = a[Math.floor(Math.random() * a.length)];
        }
       else {
    try {
        translated_keyword = await ttp_translate_keyword_via_lambda(e.keyword);
    } catch (err) {
        console.warn("Lambda translate failed:", err);
        translated_keyword = "";
    }

    if (!translated_keyword) {
        translated_keyword = e.keyword;
    }

        }
        let out = {
            'status': 'error',
            'status_info': '',
            'action': '',
            'keyword': e.keyword,
            'keyword_trn': translated_keyword,
            'data': '',
            'provider': 'provider_2',
            // 'start': chokstudio_ali_ttp_get_date(),
            'start-js': e.start,
            'end': '',
            'end-gen-php-template': '',
        };
      let url = 'https://api-gw.onebound.cn/1688/item_search/?key=[REDACTED-CREDENTIAL]&q=' 
    + encodeURIComponent(translated_keyword)  
    + '&start_price=&end_price=&cat=0&page_size=42&seller_info=no&cache=no&lang=zh-CN&secret=[REDACTED-CREDENTIAL]';
        // let url = 'https://api-4.onebound.cn/1688/item_search/?key=[REDACTED-CREDENTIAL]&q=' +translated_keyword + '&start_price=&end_price=&page=1&cat=0&page_size=18&seller_info=no&cache=no&&lang=zh-CN&secret=[REDACTED-CREDENTIAL]';
        // $url ='https://api-3.onebound.cn/1688/item_search/?key=[REDACTED-CREDENTIAL]&q='.$translated_keyword.'&start_price=&end_price=&page=1&cat=0&page_size=40&seller_info=no&cache=no&&lang=zh-CN&secret=[REDACTED-CREDENTIAL]';
        // $url = 'https://api.openchinaapi.com/v3/1688/search-pro/?q=' + $translated_keyword + ' &page=1&page_size=18 ';
        // Start Price
       if (e.start_price && e.start_price != "") {
    url += '&start_price=' + e.start_price;
}

if (e.end_price && e.end_price != "") {
    url += '&end_price=' + e.end_price;
}
        // Order
        if (e.order && e.order != "" && e.order != "normal") {
            url += '&sort=' + e.order;
            // url += '&order=' + e.order;
        }
      
        // Page
        if (e.sort_paged && e.sort_paged != "") {
            url += '&page=' + e.sort_paged;
        } else {
            url += '&page=1';
        }
    
        // Quantity Begin
        if (e.quantity_begin && e.quantity_begin != "") {
            url += '&quantityBegin=' + e.quantity_begin;
        }
/////////////////////////////////////////////////////////////////////////


let provider = 'onebound1';

let data = null;

const shouldFallbackApi = (data) => {
    const err = String(data?.error || '').toLowerCase().trim();

    return (
        err === 'data_error' ||
        err === 'data error' ||
        err === 'item-not-found'
    );
};

let apiUrls = [
    {
        name: 'api-gw',
        url: url,
        maxRetry: 1
    },
    {
        name: 'api-1',
        url: url.replace('https://api-gw.onebound.cn', 'https://api-1.onebound.cn'),
        maxRetry: 3
    }
];

for (let apiIndex = 0; apiIndex < apiUrls.length; apiIndex++) {
    let api = apiUrls[apiIndex];
    let currentApiFailed = true;

    for (let i = 1; i <= api.maxRetry; i++) {
        let retryUrl = api.url + '&_retry=' + Date.now() + '_' + i;

        try {
            let r = await fetch(retryUrl, {
                method: "GET",
                headers: {
                    "Cache-Control": "no-cache"
                }
            });

            if (!r.ok) {
                console.warn("fetch not ok:", api.name, r.status);
                currentApiFailed = true;
                break;
            }

            data = await r.json();

            console.log("api:", api.name);
            console.log("search try:", i, data);

            if (!data?.error || data.error === '') {
                currentApiFailed = false;
                break;
            }

            if (shouldFallbackApi(data)) {
                currentApiFailed = true;
                break;
            }

            currentApiFailed = false;
            break;

        } catch (err) {
            console.warn("fetch failed:", api.name, err);
            currentApiFailed = true;
            break;
        }
    }

    if (!currentApiFailed) {
        break;
    }

    await new Promise(resolve => setTimeout(resolve, 500));
}
if (data && (data.error == '' || !data.error)) {
    const items = data?.items?.item || [];

    out.data = await ttp_array_generate_search_template(items, provider);
    out.dataPaginate = await ttp_object_generate_search_template(data, provider);
    out.status = 'success';
    out.dataDeep = data;
} else {
    out.status = 'error';
    out.status_info = data?.reason || data?.error || 'search failed';
    out.data = [];
    out.dataDeep = data || {};
    out.dataPaginate = {};
}
        
    
    
    
    
        return out;
        // echo wp_json_encode( $out );
    } catch (error) {
        console.log(error)
    }

}

/// openchinaapi
async function ttp_search_v111(e) {
    try {
        let translated_keyword = "";

        // แปลงคำไทยเป็นจีน
        if (e.keyword == 'กระเป๋า') translated_keyword = '肩包';
        else if (e.keyword == 'ชุดนอน') translated_keyword = '睡衣';
        else if (e.keyword == 'เสื้อผ้าเด็ก' || e.keyword == 'ชุดเด็ก') translated_keyword = '婴儿服装';
        else if (e.keyword == 'รองเท้า') translated_keyword = '鞋子';
        else if (e.keyword == 'กระเป๋าสะพาย') translated_keyword = '单肩包';
        else if (e.keyword == 'เสื้อผ้าผู้หญิง') translated_keyword = '女装';
        else if (e.keyword == 'ที่ใส่น็อต') translated_keyword = '螺母架';
        else if (e.keyword == 'พัดลม') translated_keyword = '风扇';
        else if (!e.keyword || e.keyword.trim() === "") {
            let a = ["睡衣", "鞋子", "单肩包", "肩包", "婴儿服装"];
            translated_keyword = a[Math.floor(Math.random() * a.length)];
        } else {
            // translated_keyword = await chokstudio_ali_translate_if_thai(e.keyword);
            translated_keyword = e.keyword
        }

        let out = {
            status: 'error',
            status_info: '',
            action: '',
            keyword: e.keyword,
            keyword_trn: translated_keyword,
            data: '',
            provider: 'openchinaapi/whale',
            start: Date.now(),
            start_js: e.start,
            end: '',
            end_gen_php_template: ''
        };

        // สร้าง URL
        // let url = `https://api.openchinaapi.com/v3/1688/search-pro/?q=`+translated_keyword+`&page=1&page_size=18&&lang=zh-CN`;
        let url = `https://api.openchinaapi.com/v3/1688/search-pro/?q=`+translated_keyword+`&page=1&page_size=18`;
        

        if (e.start_price) url += `&start_price=${e.start_price}`;
        if (e.end_price) url += `&end_price=${e.end_price}`;
        if (e.order && e.order != "normal") url += `&order_by=${e.order}`;
        if (e.sort_paged) url += `&page=${e.sort_paged}`;
        if (e.quantity_begin) url += `&quantityBegin=${e.quantity_begin}`;

        // เรียก API ด้วย fetch
        let r = await fetch(url, {
            method: "GET",
            headers: {
                "Authorization": "Token 7ec470419ace67b4a02dfc39272ac86c5d203673",
            }
        });

     

        if (r.ok) {
            let data = await r.json();
            if (!data.error) {

            //       console.log(url)
            // console.log(data)
                out.data = await ttp_array_generate_search_template(data.data.item, out.provider);
                out.dataPaginate = await ttp_object_generate_search_template(data, out.provider);
                out.status = 'success';
                out.end = Date.now();
                out.end_gen_php_template = Date.now();
            } else {
                out.status = 'error';
                out.dataDeep = {};
                out.dataPaginate = {};
                out.status_info = data.reason || "Unknown error";
            }
        } else {
            out.status_info = `HTTP Error ${r.status}`;
        }

        return out;

    } catch (error) {
        console.error(error);
        return { status: 'error', status_info: error.message };
    }
}


// ttp_array_search_template
function ttp_array_search_template() {
    return {
        'shop_tag': '',
        'shop_seller_id': '',
        'img': '',
        'price': '',
        'shop_member_id': '',
        'turnover_rate': '',
        'bookedCount': '',
        'shop_name': '',
        'id': '',
        'shop_url': '',
        'title': '',
        'url': '',
        'prices': '',
    };
}


// ttp_array_search_paginate_template
function ttp_array_search_paginate_template() {
    return {
        'page': '',
        'page_count': '',
        'page_size': '',
        'real_total_results': '',
        'total_results': '',
    };
}
// ttp_array_generate_search_template
async function ttp_array_generate_search_template(data, provider) {
    try {
        let ttp_array = ttp_array_search_template();
        let all_product = [];
        // console.log(data)
        if (provider == '99api.com') {
            data.forEach((i, item) => {
                let each_product = {};
                for (let k in ttp_array) {
                // ttp_array.forEach((k, v) => {
                // foreach($ttp_array as $k => $v) {
                    if (k == 'shop_tag') each_product[k] = item.shopTag;
                    if (k == 'shop_seller_id') each_product[k] = item.shopSellerId;
                    if (k == 'img') each_product[k] = item.img;
                    if (k == 'price') each_product[k] = item.price;
                    if (k == 'shop_member_id') each_product[k] = item.shopMemberId;
                    if (k == 'turnover_rate') each_product[k] = item.turnoverRate;
                    if (k == 'bookedCount') each_product[k] = item.bookedCount;
                    if (k == 'shop_name') each_product[k] = item.shopName;
                    if (k == 'id') each_product[k] = item.id;
                    if (k == 'shop_url') each_product[k] = item.shopUrl;
                    if (k == 'title') each_product[k] = item.title;
                    if (k == 'url') each_product[k] = item.url;
                    if (k == 'prices') {
    
                        each_product[k] = [];
                        if (item['prices']) {
                            item.prices.forEach(p => {
                            // foreach($item['prices'] as $p) {
                                each_product[k].push({
                                    'price_rang': p.number,
                                    'price': p.price,
                                });
                            })
                        }
                    }
                };
                all_product.push(each_product);
            });
            // foreach ( $data as $i => $item ) {
    
            // }
        } else if (provider == 'onebound') {
            data.forEach((item) => {
            // foreach($data as $i => $item) {
    
                let each_product = {};
    
                for (let k in ttp_array) {
                // ttp_array.forEach((k, v) => {
                // foreach($ttp_array as $k => $v) {
    
                    if (k == 'shop_tag') each_product[k] = item.shopTag;
                    if (k == 'shop_seller_id') each_product[k] = item.shopSellerId;
                    if (k == 'img') each_product[k] = item.pic_url;
                    if (k == 'price') each_product[k] = item.price;
                    if (k == 'shop_member_id') each_product[k] = item.seller_id;
                    if (k == 'turnover_rate') each_product[k] = item.tag_percent;
                    if (k == 'bookedCount') each_product[k] = item.sales;
                    if (k == 'shop_name') each_product[k] = item.seller_nick || "";
                    if (k == 'id') each_product[k] = item.num_iid;
                    if (k == 'shop_url') each_product[k] = item.shopUrl;
                    if (k == 'title') each_product[k] = item.title;
                    if (k == 'url') each_product[k] = item.detail_url;
                    if (k == 'prices') {
    
                        each_product[k] = [];
                        if (item['prices']) {
                            item.prices.forEach(p => {
                            // foreach(item['prices'] as $p) {
                                each_product[k].push({
                                    'price_rang': p.number,
                                    'price': p.price,
                                });
                            })
                        }
                    }
                };
                all_product.push(each_product);
            });
        }
        else if (provider == 'onebound1') {
    if (Array.isArray(data)) {
        data.forEach((item) => {
            let each_product = {};

            for (let k in ttp_array) {
                if (k == 'shop_tag') each_product[k] = item.shopTag || '';
                if (k == 'shop_seller_id') each_product[k] = item.shopSellerId || '';
                if (k == 'img') each_product[k] = item.pic_url || item.picUrl || item.img || item.image || '';
                if (k == 'price') each_product[k] = item.price || item.promotion_price || item.price_val || '';
                if (k == 'shop_member_id') each_product[k] = item.seller_id || '';
                if (k == 'turnover_rate') each_product[k] = item.tag_percent || '';
                if (k == 'bookedCount') each_product[k] = item.sales || item.bookedCount || 0;
                if (k == 'shop_name') each_product[k] = item.seller_nick || item.shop_name || '';
                if (k == 'id') each_product[k] = item.num_iid || item.item_id || '';
                if (k == 'shop_url') each_product[k] = item.shopUrl || '';
                if (k == 'title') each_product[k] = item.title || '';
                if (k == 'url') each_product[k] = item.detail_url || item.url || '';

                if (k == 'prices') {
                    each_product[k] = [];

                    if (Array.isArray(item.prices)) {
                        item.prices.forEach(p => {
                            each_product[k].push({
                                price_rang: p.number || p.price_rang || '',
                                price: p.price || ''
                            });
                        });
                    } else if (item.price || item.promotion_price) {
                        each_product[k].push({
                            price_rang: 1,
                            price: item.price || item.promotion_price
                        });
                    }
                }
            }

            all_product.push(each_product);
        });
    }
}
       else if (provider == 'openchinaapi/whale') {
    if (data && Array.isArray(data)) {

   
        data.forEach(item => {
           
            let each_product = {};
            
//             if (Array.isArray(ttp_array)) {
//                 console.log("TTP_ARRAY:", ttp_array);

//                 ttp_array.forEach(k => {
//                     switch(k){
//                         case 'shop_tag': each_product[k] = item.shopTag; break;
//                         case 'shop_seller_id': each_product[k] = item.shopSellerId; break;
//                        console.log("CHECK pic_url:", item.pic_url);
// if(item.pic_url){
//     each_product[k] = item.pic_url.replace('_350x350.jpg','') + '_270x270xzq60.jpg';
//     console.log("FIXED pic_url:", each_product[k]);
// } else {
//     each_product[k] = 'https://taobao.ttpcargo.com/default_270x270xzq60.jpg';
//     console.log("USED DEFAULT pic_url");
// }


//                         case 'price': each_product[k] = item.price_original; break;
//                         case 'shop_member_id': each_product[k] = item.seller_id; break;
//                         case 'turnover_rate': each_product[k] = item.repurchaseRate; break;
//                         case 'bookedCount': each_product[k] = item.sales; break;
//                         case 'shop_name': each_product[k] = item.seller_nick || ""; break;
//                         case 'id': each_product[k] = item.num_iid; break;
//                         case 'shop_url': each_product[k] = item.shopUrl; break;
//                         case 'title': each_product[k] = item.title; break;
//                         case 'url': each_product[k] = item.detail_url; break;
//                         case 'prices':
//                             each_product[k] = [];
//                             if(Array.isArray(item.prices)){
//                                 item.prices.forEach(p => {
//                                     each_product[k].push({price_rang: p.number, price: p.price});
//                                 });
//                             }
//                             break;
//                     }
//                 });
//             }

 for (let k in ttp_array) {
     
                // ttp_array.forEach((k, v) => {
                // foreach($ttp_array as $k => $v) {
    
                    if (k == 'shop_tag') each_product[k] = item.shopTag;
                    if (k == 'shop_seller_id') each_product[k] = item.shopSellerId;
                   if (k == 'img') {
    if(item.pic_url && typeof item.pic_url === 'string'){
        each_product[k] = item.pic_url.replace('_350x350.jpg',''); // ตัด _350x350.jpg ออก
    } else {
        each_product[k] = 'https://taobao.ttpcargo.com/default_270x270xzq60.jpg'; // fallback
    }
}

                    if (k == 'price') each_product[k] = item.price_original;
                    if (k == 'shop_member_id') each_product[k] = item.seller_id;
                    if (k == 'turnover_rate') each_product[k] = item.repurchaseRate;
                    if (k == 'bookedCount') each_product[k] = item.sales;
                    if (k == 'shop_name') each_product[k] = item.seller_nick || "";
                    if (k == 'id') each_product[k] = item.num_iid;
                    if (k == 'shop_url') each_product[k] = item.shopUrl;
                    if (k == 'title') each_product[k] = item.title;
                    if (k == 'url') each_product[k] = item.detail_url;
                    if (k == 'prices') {
    
                        each_product[k] = [];
                        if (item['prices']) {
                            item.prices.forEach(p => {
                            // foreach(item['prices'] as $p) {
                                each_product[k].push({
                                    'price_rang': p.number,
                                    'price': p.price,
                                });
                            })
                        }
                    }
                };
            all_product.push(each_product);
        });
    } else {
        
    }
}

    
        return all_product;
    } catch (error) {
        console.log(error)
    }

}

console.log("517");


async function ttp_object_generate_search_template(data, provider) {
    try {
        let ttp_array = ttp_array_search_paginate_template();
        let all_product = {};
        // console.log(data)
        if (provider == '99api.com') {
            for (let k in ttp_array) {

                if (k == 'page') all_product[k] = parseInt(data.items.page);
                if (k == 'page_count') all_product[k] = parseInt(data.items.page_count);
                if (k == 'page_size') all_product[k] = parseInt(data.items.page_size);
                if (k == 'real_total_results') all_product[k] = parseInt(data.items.real_total_results);
                if (k == 'total_results') all_product[k] = parseInt(data.items.total_results);
            }
            // data.forEach((i, item) => {
            //     let each_product = {};
            //     for (let k in ttp_array) {
            //         if (k == 'shop_tag') each_product[k] = item.shopTag;
            //         if (k == 'shop_seller_id') each_product[k] = item.shopSellerId;
            //         if (k == 'img') each_product[k] = item.img;
            //         if (k == 'prices') {
    
            //             each_product[k] = [];
            //             if (item['prices']) {
            //                 item.prices.forEach(p => {
            //                     each_product[k].push({
            //                         'price_rang': p.number,
            //                         'price': p.price,
            //                     });
            //                 })
            //             }
            //         }
            //     };
            //     all_product.push(each_product);
            // });
        } else if (provider == 'onebound') {
            for (let k in ttp_array) {

                if (k == 'page') all_product[k] = parseInt(data.items.page);
                if (k == 'page_count') all_product[k] = parseInt(data.items.page_count);
                if (k == 'page_size') all_product[k] = parseInt(data.items.page_size);
                if (k == 'real_total_results') all_product[k] = parseInt(data.items.real_total_results);
                if (k == 'total_results') all_product[k] = parseInt(data.items.total_results);
            }
        } else if (provider == 'openchinaapi/whale') {


                const page = parseInt(data.data.page);
                const pageSize = parseInt(data.data.pageSize);
                let totalResults = parseInt(data.data.totalResults);


                  if (!Number.isFinite(totalResults) || totalResults < 361) {
                 totalResults = 360;
                     }

                      const pageCount = Math.ceil(totalResults / pageSize);

                 globalPageData = {
                page_count: pageCount,

                
                
 
    };

                for (let k in ttp_array) {

                    if (k == 'page')              all_product[k] = page;
                    if (k == 'page_count')        all_product[k] = pageCount;
                    if (k == 'pagesize')         all_product[k] = pageSize;
                    if (k == 'total_results')     all_product[k] = totalResults;
                }
        }

    
        return all_product;
    } catch (error) {
        console.log(error)
    }
}
// chokstudio_ali_ttp_get_date
// function chokstudio_ali_ttp_get_date() {
//     return date_i18n(get_option('date_format'), current_time('timestamp')).' @ '.date_i18n(get_option('time_format'), current_time('timestamp'));
// }
// chokstudio_ali_translate_if_thai

async function chokstudio_ali_translate_if_thai(e) {
    // console.log(e)
    e = e.toString();
    if (e.replace(/[^ก-ฮ]/gu, '') !== '') {
        return await chokstudio_ali_translate(e);
    }
    return await chokstudio_ali_translate_zh(e);
}
// chokstudio_ali_translate_zh
async function chokstudio_ali_translate_zh(e) {
    try {
        // let key = '[REDACTED-API-KEY]';
        let key = '[REDACTED-API-KEY]';
        let endpoint = 'https://translation.googleapis.com/language/translate/v2';

        let q = '&q=' + e;

        let source = '&source=zh-TW';
        let target = '&target=zh-CN';
        let nKey = '?key=' + key;

        let url = endpoint + nKey + source + target + q;

        // $response = wp_remote_get( $url,
        // 			array(
        // 				'timeout'	=> 15,
        // 			)
        // );
        let r = await fetch(url, {
            method: "GET",
            headers: {
                "Cache-Control": "no-cache"
            },
        });

        if (r.ok) {
            return (await r.json()).data.translations[0].translatedText;
        }
        return "";

        // $body = wp_remote_retrieve_body( $response );
        // $data = json_decode( $body, true );

        // $out = '';
        // if ( ! empty( $data ) && is_array( $data ) ) {
        //     if ( isset( $data['data']['translations'][0]['translatedText'] ) ) {
        //         $out = $data['data']['translations'][0]['translatedText'];
        //     }
        // }

        // return $out;
    } catch (error) {
        console.log(error)
    }
}
// chokstudio_ali_translate
async function chokstudio_ali_translate(e) {
    try {
        // let key = '[REDACTED-API-KEY]';
        let key = '[REDACTED-API-KEY]';
        let endpoint = 'https://translation.googleapis.com/language/translate/v2';

        let q = '&q=' + e;

        let source = '&source=th';
        let target = '&target=zh';
        let nKey = '?key=' + key;

        let url = endpoint + nKey + source + target + q;

        let r = await fetch(url, {
            method: "GET",
            headers: {
                "Cache-Control": "no-cache"
            },
        });

        if (r.ok) {
            return (await r.json()).data.translations[0].translatedText;
        }
        return "";

        // if( is_wp_error( $url ) ) {
        // 	//return false; // Bail early
        // }

        // $response = wp_remote_get( $url,
        // 			array(
        // 				'timeout'	=> 15,
        // 			)
        // );

        // $body = wp_remote_retrieve_body( $response );
        // $data = json_decode( $body, true );

        // $out = '';
        // if ( ! empty( $data ) && is_array( $data ) ) {
        //     if ( isset( $data['data']['translations'][0]['translatedText'] ) ) {
        //         $out = $data['data']['translations'][0]['translatedText'];
        //     }
        // }

        // return $out;

        //echo json_encode( $data, JSON_FORCE_OBJECT );
    } catch (error) {
        console.log(error)
    }
}

document.addEventListener('input', (e) => {
    if (e.target.classList.contains('sort-paged')) {
        let pageCount = globalPageData.page_count || 99;
        let valStr = e.target.value; 
        let val = parseInt(valStr);
        if (valStr === "") {
            e.target.value = "";
            return;
        }
        if (isNaN(val) || val < 1) val = 1;
        if (val > pageCount) val = pageCount;

        e.target.value = val;
    }
});

function setSearchPageTitle(keyword, provider = '1688') {
  const elTitle = document.querySelector('title');
  const nowTitle = elTitle?.textContent || document.title || '';

  const spTitle = nowTitle.split(' | ').map(s => s.trim()).filter(Boolean);
  const suffix = spTitle.length > 1 ? spTitle.slice(1).join(' | ') : (nowTitle.trim() || 'TTPCARGO');

  const kw = (keyword == null) ? '' : (typeof keyword === 'string' ? keyword : String(keyword));
  const kwTrim = kw.trim();

  const left = `Search ${kwTrim} - ${provider.toUpperCase()}`;

  const newTitle = suffix ? `${left} | ${suffix}` : left;

  if (elTitle) elTitle.textContent = newTitle;
  document.title = newTitle;
}


// ttpcargo_translate();
function generateSearchTemplate(e, t, z) {
    let a = "";
    let pageCount = z?.dataPaginate?.page_count || 99;


    if (e && e.length) {
        a += ' <div class="ttp-sort-bar2" ></div>';
        a += ' <i class="fa fa-close" onclick="filter_close()" style="font-size:36px;display:none"></i>';
        a += '<div class="f-rung">';
        a += '<i class="fa fa-filter" onclick="filter_click()"></i>';
        a += '</div>';
        a += '<div id="ttp-sort-bar" class="sort-bar sort-bar-1688 sort-bar-provider-2">', a += '<span>' + ttp.translate.sort_by + "</span>";
        let r = "";
        "normal" == t.order && (r = " active"), a += '<button type="button" class="btn btn-default sort-bar-btn' + r + '" data-order="normal">' + ttp.translate.related + "</button>", r = "", "va_rmdarkgmv30rt" == t.order && (r = " active"),
            a += '<button type="button" class="btn btn-default sort-bar-btn' + r + '" data-order="va_rmdarkgmv30rt">' + ttp.translate.turnover + "</button>",
            r = "", "price-asc" == t.order && (r = " active"), a += '<button type="button" class="btn btn-default sort-bar-btn' + r + '" data-order="price-asc">' + ttp.translate.price_asc + "</button>", r = "", "price-desc" == t.order && (r = " active"),
            a += '<button type="button" class="btn btn-default sort-bar-btn' + r + '" data-order="price-desc">' + ttp.translate.price_desc + "</button>", a += '<div class="group-field ml-1"><span>ช่วงราคา </span>',
            a += '<input type="number" class="x-price start-price text-center" placeholder="น้อยสุด" value="' + localStorage.getItem("start_price") + '">', a += " <strong>-</strong> ", a += '<input type="number" class="x-price end-price text-center" placeholder="มากสุด" value="' + localStorage.getItem("end_price") + '">',
           
            a += '<button type="button" class="sort-go btn btn-default" data-type="x-price">ตกลง</button>', a += "</div>", a += '<div class="group-field ml-1"><span>จำนวนสินค้า </span>', a += '<input type="number" class="min-qty text-center" placeholder="น้อยสุด" value="' + localStorage.getItem("min_qty") + '">', a += '<button type="button" class="sort-go btn btn-default" data-type="min-qty">ตกลง</button>',
            //  a += "</div>", a += '<div class="group-field float-r">', a += "<span>หน้า </span> ", a += '<input type="number" class="sort-paged text-center" placeholder="" value="' + localStorage.getItem("sort_paged") + '">', a += '<button type="button" class="sort-go btn btn-default" data-type="paged">ตกลง</button>',
            a += "</div>", a += '<div class="group-field float-r">', a += "<span>หน้า </span> ",a += '<input type="number" class="sort-paged text-center" placeholder="" ' + 'value="' + localStorage.getItem("sort_paged") + '" ' +' max="' + pageCount + '">', a += '<button type="button" class="sort-go btn btn-default" data-type="paged">ตกลง</button>',
            a += "</div>", a += "</div>", a += '<div class="row" style="margin-top:16px;">';
        let n = 0;
        e.forEach(function (e, t) {
            if (n < 42) {
                n++, a += '<section class="item col-xs-6 col-sm-4 col-lg-2">', a += '<a href="' + window.location.origin + '/product?provider=1688&itemId=' + e.id + '" target="_blank">', a += '<div class="product">', a += '<div class="p-top" style="width:100%; aspect-ratio:1/1; background-image: url(https://taobao.ttpcargo.com/wp-content/uploads/2021/11/taobao-logo-test.png);background-size: contain;">', a += '<img src="' + e.img + '_270x270xzq60.jpg" alt="">',
                    a += '<div class="txt-view-product text-center">' + ttp.translate.view_product + "</div>", a += "</div>", a += '<div class="price-rang">', a += '<div class="price-item">', a += '<span class="f11 clr-7">&#165;</span> ', a += '<span class="">' + e.price + "</span>", a += "</div>", a += "</div>", a += '<h2 class="search-title px-2 pb-0 my-2">' + e.title + "</h2>", a += '<div class="shop-name p-2 pt-0 pb-0 f10">' + (e.shop_name !== null ? e.shop_name : "") + "</div>",
                    a += '<div class="turnover-rate p-2 pt-0 pb-0 clr-6">' + ttp.translate.turnover_rate + " " + e.turnover_rate + "</div>", a += '<div class="bookedCount p-2 pt-0 pb-0 clr-6"> ขายได้ ' + e.bookedCount + " ชิ้น </div>", a += '<div class="price-con p-2 pt-0">', a += '<span class="f11 clr-7">&#165;</span> ', a += '<span class="">' + e.price + "</span>", a += "</div>", a += "</div>", a += "</a>", a += "</section>"
            }
        }), a += "</div>", a += htmlPaged(t, e, z)
    } else {
        a += '<div class="text-center" style="padding:60px 0;">', a += '<p class="kwnotfound"><img src="' + window.location.origin + '/wp-content/uploads/2022/04/keywordnotfound.png" width="40%"></p>', a += '<p>ขณะนี้มีผู้เข้าชมหน้านี้จำนวนมาก กรุณาลองค้นหาใหม่อีกครั้ง</p>', a += '<a href="' + window.location.origin + '/search?provider=1688&keyword=' + t.keyword + '" class="btn_or">ค้นหาอีกครั้งด้วย 1688</a>', a += '<a href="' + window.location.origin + '/search?provider=taobao&keyword=' + t.keyword + '" class="btn_or">ค้นหาอีกครั้งด้วย taobao</a>', a += "</div>";
        recommend(20);
    }
    document.getElementById("search-list-container").innerHTML = a, document.querySelector("#serp-btn").classList.remove("spinner", "processing");
    setSearchPageTitle(t?.keyword || localStorage.getItem("search_keyword") || "", "1688");
}

function htmlPaged1(e, ea, z) {
    let t, a, r;
    // console.log(e, ea, z)
    let html = '<nav class="pagination-con" aria-label="Page navigation">'
    html += '<ul class="pagination ttp_paged text-center">';
    let pageNum = ((e.paged == "") ? 1 : parseInt(e.paged));
    let maxPage = parseInt(Math.ceil(z.dataPaginate.total_results / z.dataPaginate.page_size)) > 99 ? 99 : parseInt(Math.ceil(z.dataPaginate.total_results / z.dataPaginate.page_size));
    let minNum = (((pageNum - 5) < 1) ? 1 : (pageNum - 5));
    let maxNum = (((pageNum + 5) > maxPage) ? maxPage : (pageNum + 5));
    if(minNum > 1){
        html += '<li><a href="#" class="paged-item" data-page="' + 1 + '">'+ 1 + "</a></li>";
        if (minNum > 2) {
            html += '<li><a class="at-item">...</a></li>';
        }
    }
    // console.log(pageNum, minNum, maxNum)
    for (t = minNum; t <= maxNum; t++) {
        a = "", r = '<a href="#" class="paged-item" data-page="' + t + '">' + t + "</a>",
        (e.paged == t || (t == 1 && e.paged == "")) && (a = ' class="active"', r = '<span class="at-item">' + t + "</span>"), html += "<li" + a + ">", html += r, html += "</li>";
    }
     if (maxNum < maxPage - 1) {
        html += '<li><a class="at-item">...</a></li>';
    }

    if((maxNum != maxPage) || (pageNum != maxPage)){
        html += '<li><a href="#" class="paged-item" data-page="' + maxPage + '">'+ maxPage + "</a></li>";
    }
    html += "</ul>"
    html += "</nav>"
    return html;


    // for (html = '<nav class="pagination-con" aria-label="Page navigation">', html += '<ul class="pagination ttp_paged text-center">', t = 1; t < 21; t++) a = "", r = '<a href="#" class="paged-item" data-page="' + t + '">' + t + "</a>",
    //     (e.paged == t || (t == 1 && e.paged == "")) && (a = ' class="active"', r = '<span class="at-item">' + t + "</span>"), html += "<li" + a + ">", html += r, html += "</li>";
    // return html += "</ul>", html += "</nav>", html
}

function htmlPaged(e, ea, z) {
    let t, a, r;

    let html = '<nav class="pagination-con" aria-label="Page navigation">';
    html += '<ul class="pagination ttp_paged text-center">';

    let pageNum = (e.paged == "" ? 1 : parseInt(e.paged));
    let maxPage;
let raw1 = NaN;

// 1) ใช้ page_count ก่อนสุด
if (z?.dataPaginate?.page_count) {
    maxPage = parseInt(z.dataPaginate.page_count);

}
// 2) ถ้าไม่มี page_count → ค่อยคำนวณจาก pageSize/page_size
else if (z?.dataPaginate?.pageSize && z?.dataPaginate?.page_size) {
    raw1 = Math.ceil(z.dataPaginate.pageSize / z.dataPaginate.page_size);
    maxPage = raw1;
}
// 3) ถ้าไม่มีอะไรเลย → default
else {
    maxPage = 99;
}

// จำกัดไม่เกิน 99
maxPage = maxPage > 99 ? 99 : parseInt(maxPage);


    let minNum = (pageNum - 5 < 1 ? 1 : pageNum - 5);
    let maxNum = (pageNum + 5 > maxPage ? maxPage : pageNum + 5);

    if (minNum > 1) {
        html += '<li><a href="#" class="paged-item" data-page="1">1</a></li>';
        if (minNum > 2) {
            html += '<li><a class="at-item">...</a></li>';
        }
    }

    for (t = minNum; t <= maxNum; t++) {
        a = "";
        r = '<a href="#" class="paged-item" data-page="' + t + '">' + t + "</a>";
        if (e.paged == t || (t == 1 && e.paged == "")) {
            a = ' class="active"';
            r = '<span class="at-item">' + t + "</span>";
        }
        html += "<li" + a + ">" + r + "</li>";
    }

    if (maxNum < maxPage - 1) {
        html += '<li><a class="at-item">...</a></li>';
    }

    if (maxNum != maxPage && pageNum != maxPage) {
        html += '<li><a href="#" class="paged-item" data-page="' + maxPage + '">' + maxPage + "</a></li>";
    }

    html += "</ul></nav>";

    return html;



    // for (html = '<nav class="pagination-con" aria-label="Page navigation">', html += '<ul class="pagination ttp_paged text-center">', t = 1; t < 21; t++) a = "", r = '<a href="#" class="paged-item" data-page="' + t + '">' + t + "</a>",
    //     (e.paged == t || (t == 1 && e.paged == "")) && (a = ' class="active"', r = '<span class="at-item">' + t + "</span>"), html += "<li" + a + ">", html += r, html += "</li>";
    // return html += "</ul>", html += "</nav>", html
}

function on(e, t, a) {
    document.body.addEventListener(e, function (e) {
        e.target.classList.contains(t) && a(e)
    })
}
// <div class="bounce1"></div>t += '<div class="bounce2"></div>', t += '<div class="bounce3"></div>',
function searchLoading(e) {
    let t = "";
    t += '<div class="text-center" style="padding: 64px 0 32px 0">', t += '<div id="do-search-v2x" class="do-search-v2x" data-keyword="' + e + '">', t += "<span>กำลังค้นหา</span> ", t += '<span style="font-weight:600;">' + e + "</span> ",
        t += "</div>", t += '<div class="spinner2">', t += '<div class="loadicon"></div>', t += "</div>", t += "</div>";
    let a = document.getElementById("search-list-container");
    a.classList.remove("d-none"), a.innerHTML = t
}
function setSearchContainer(e) {
    let t = document.getElementById("header"),
        a = document.createElement("div");
    r = document.createElement("div");
    r.id = "recommend-list-container", r.className = "container", t.parentNode.insertBefore(r, t.nextSibling);
    a.id = "search-list-container", a.className = "search-v2 product-container container d-none", t.parentNode.insertBefore(a, t.nextSibling)
}
async function asyncGetJSON_P(e) {
    let t = e,
        a = await fetch(t, {
            method: "POST",
            credentials: "include",
            headers: {
                "Content-Type": "application/x-www-form-urlencoded"
            }
        });
    if (a.ok) {
        await a.json()
    }
}
async function asyncGetJSON(e, t) {
    const a = await fetch("-", {
        method: "POST",
        mode: "cors",
        credentials: "omit",
        headers: {
            "Content-Type": "application/x-www-form-urlencoded",
            "Cache-Control": "no-cache"
        }
    });
    if (a.ok) {
        await a.json()
    }
}
function loadJSON(e) {
    var t = new XMLHttpRequest;
    t.open("POST", "-", !0), t.setOption(2, 13056), t.setRequestHeader("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8"), t.overrideMimeType("application/json"), t.responseType = "json", t.onreadystatechange = function () {
        4 == t.readyState && "200" == t.status && e(t.responseText)
    };
    let a = "apikey=55&keyword=shirt";
    a = "", t.send("")
}
function TTPSearch_v1(e) {
    var t = new XMLHttpRequest;
    t.onreadystatechange = function () {
        4 == this.readyState && this.status
    }, t.ontimeout = function (e) { }, t.open("POST", ttp.ajaxurl, !0), t.timeout = 2e4, t.setRequestHeader("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8"),
        t.overrideMimeType("application/json"), t.responseType = "json", t.onerror = function () { };
    ttpGetTime(), encodeURIComponent(e.keyword);
    let a = "action=ttp_search_v1&keyword=" + e.keyword + "&provider=1688";
    t.send(a)
}
function TTPSearch_v111(e) {
    console.log('TTPSearch_v111');
    var t = new XMLHttpRequest;
    t.onreadystatechange = function () {
        4 == this.readyState && this.status
    }, t.ontimeout = function (e) { }, t.open("POST", ttp.ajaxurl, !0), t.timeout = 2e4, t.setRequestHeader("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8"),
        t.overrideMimeType("application/json"), t.responseType = "json", t.onerror = function () { };
    ttpGetTime(), encodeURIComponent(e.keyword);
    let a = "action=ttp_search_v111&keyword=" + e.keyword + "&provider=1688";
    t.send(a)

}
function ttpGetTime() {
    let e = new Date;
    return e.getHours() + ":" + e.getMinutes() + ":" + e.getSeconds()
}
function ttpActiveMiniCart() {
    let cart = JSON.parse(localStorage.getItem('ali_cart'));
    if (cart) {
        console.log('has cart');
    } else {
        console.log('empty cart');
    }
}
function ttpUpdateMiniCart(cart) {
    let h = '';
    if (cart.skus.length) {
        for (let i = 0; i < cart.skus.length; i++) {
            h += '<div>' + cart.skus[i].skuMap + '</div>';
        }
    }
    let el_MiniCart = document.getElementsByClassName('shopcart-description');
    for (let i = 0; i < el_MiniCart.length; i++) {
        el_MiniCart[i].innerText = h;
    }
}
SearchBtn && SearchBtn.addEventListener("click", async function (e) {
    let btnSerp = document.getElementById('serp-btn');
    btnSerp.setAttribute('disabled', true);
    btnSerp.innerHTML = '<i class="fa fa-circle-o-notch fa-spin"></i>';
    let t = document.getElementById("serp-search");
    let sp = getSearchProvider();

    if (-1 !== t.value.indexOf(".com") || -1 !== t.value.indexOf("m.tb.cn") || -1 !== t.value.indexOf("e.tb.cn")) {
        var a = await ctsp.get_provider_n_id(t.value.trim());
        cso.goSingleProduct(a.provider, a.id);
    }
    else if (!SearchBtn.classList.contains("processing")) {
        window.location = "/search?provider=" + sp + "&keyword=" + t.value;
    }
}), on("click", "sort-bar-btn", function (e) {
    if (!e.srcElement.classList.contains("active")) {
        let t = localStorage.getItem("search_keyword");
        t.length && TTPSearch_v2(t, e.srcElement.getAttribute("data-order"))
    }
}), on("click", "sort-bar-btn2", function (e) {
    if (!e.srcElement.classList.contains("active")) {
        let t = localStorage.getItem("search_keyword");
        t.length && TTPSearch_v3(t, e.srcElement.getAttribute("data-order"))
    }
}), on("click", "sort-go", function (e) {
    let t = localStorage.getItem("search_keyword");
    t.length && TTPSearch_v2(t)
}), on("click", "sort-go2", function (e) {
    let t = localStorage.getItem("search_keyword");
    t.length && TTPSearch_v3(t)
}), on("click", "paged-item", function (e) {
    e.preventDefault(), e.srcElement.classList.add("mystyle-5566");
    let t = localStorage.getItem("search_keyword");
    t.length && (TTPSearch_v2(t, null, e.srcElement.getAttribute("data-page")), document.querySelector("#header").scrollIntoView({
        behavior: "smooth"
    }))
    // }), on("click", "ttp-link-img", function (e) {
    // e.preventDefault(), e.srcElement.classList.add("mystyle-5566");
    // let t = localStorage.getItem("search_keyword");
    // t.length && (template_searchimg(t, null, e.srcElement.getAttribute("data-page")), document.querySelector("#header").scrollIntoView({
    //     behavior: "smooth"
    // }))

    // ใช้ event delegation เผื่อ element ถูกสร้างทีหลัง






}), on("click", "paged-item2", function (e) {
    e.preventDefault(), e.srcElement.classList.add("mystyle-5566");
    let t = localStorage.getItem("search_keyword");
    t.length && (TTPSearch_v3(t, null, e.srcElement.getAttribute("data-page")), document.querySelector("#header").scrollIntoView({
        behavior: "smooth"
    }))
});
function filter_click() {
    jQuery('div#ttp-sort-bar').addClass("rung-menu");
    jQuery('.body-overlay').css({ "opacity": '555', "visibility": 'inherit' });
    jQuery('div#ttp-sort-bar.rung-menu').animate({ "margin-right": '+=400' });
    jQuery('.sort-bar').css({ "display": 'table' });
    jQuery('i.fa.fa-close').css({ "display": '' });
    jQuery('.group-field').css({ "position": 'initial' });
    jQuery('.sort-bar .group-field').attr("style", "display: inline-table  !important");
    jQuery('button.btn.btn-default').click(function () {
        jQuery('.body-overlay').css({ "opacity": '777', "visibility": 'hidden' });
    });
}
function filter_close() {
    jQuery('div#ttp-sort-bar.rung-menu').animate({ "margin-right": '-=400' });
    jQuery('i.fa.fa-close').css({ "display": 'none' });
    jQuery('.group-field').css({ "position": 'absolute' });
    jQuery('.body-overlay').css({ "opacity": '777', "visibility": 'hidden' });
    jQuery('.sort-bar .group-field').attr("style", "display: none  !important");
    setTimeout(function() {
    if (window.innerWidth <= 1024) {
        jQuery('.sort-bar').css("display", "none");
    } else {
        jQuery('.sort-bar').css("display", "flex");
    }
    jQuery('div#ttp-sort-bar2').removeClass("rung-menu");
}, 400);
}
// document.addEventListener("click", function(e){

//     // console.log("global click", e.target);

//     const link = e.target.closest(".ttp-link-img");
//     if (!link) return;

//     e.preventDefault();

//     let page = link.dataset.page;
//     let keyword = localStorage.getItem("search_keyword");
//     let imgs = window.currentImgs;

//     if (keyword && keyword.length > 0) {

//         if (typeof my_ajax_object === "undefined") {
//             console.error("my_ajax_object ไม่ได้ถูกส่งมาจาก PHP");
//             return;f
//         }

//         // console.log("จะยิง AJAX ไปหน้า:", page, "keyword:", keyword, "url:", my_ajax_object.ajax_url);

        

//         fetch(my_ajax_object.ajax_url, {
//             method: "POST",
//             headers: {
//                 "Content-Type": "application/x-www-form-urlencoded"
//             },
//             body:
//                 "action=ttp_search_imgs2" +
//                 "&page=" + encodeURIComponent(page) +
//                 "&imgs=" + encodeURIComponent(imgs) 
//         })
//         .then(function(res) {
//             console.log("status:", res.status);
//             return res.text();
//         })
//         .then(function(html) {

//             console.log("response length:", html.length);

//             const container = document.querySelector("#search-results");
//             if (!container) {
//                 console.error("ไม่เจอ element #search-results");
//                 return;
//             }

//             container.innerHTML = html;

//             const header = document.querySelector("#header");
//             if (header) {
//                 header.scrollIntoView({ behavior: "smooth" });
//             }
//         })
//         .catch(function(err) {
//             console.error("AJAX error:", err);
//         });
//     }
// });

jQuery(document).on('click', '.ttp-page-link', function(e){
    e.preventDefault();

    var page = jQuery(this).data('page');
   var imgid = currentImgs;

    if(!imgid){
        console.error('imgid ว่าง, ไม่สามารถเรียก API ได้');
        return;
    }

    jQuery.post(
        ajaxurl,
        {
            action: 'ttp_search_imgs2',
            imgs: imgid,
            page: page
        },
        function(res){
            jQuery('#search-list-container').html(res);
            jQuery('html, body').animate({ scrollTop: 0 }, 200);
        }
    );
});

