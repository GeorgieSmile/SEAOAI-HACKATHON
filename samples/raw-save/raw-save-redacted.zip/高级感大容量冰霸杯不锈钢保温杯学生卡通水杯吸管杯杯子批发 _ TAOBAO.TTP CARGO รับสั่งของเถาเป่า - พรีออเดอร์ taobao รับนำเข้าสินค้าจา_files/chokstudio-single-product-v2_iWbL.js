console.log('Ali V.2');
if(document.referrer == 'https://ttpcargo.com/out/?goto='+encodeURIComponent(window.location.href) ){
	console.log('ref:'+document.referrer);
	location.reload();
}
// window.onload = function (){
//     const queryString = window.location.search;
//     const urlParams = new URLSearchParams(queryString);
//     const urlLoggedin = urlParams.get('loggedin')
//     const urlProvider = urlParams.get('provider')
//     const urlItemId = urlParams.get('itemId')
//     // console.log(queryString);
//     // console.log(urlLoggedin);
//     const urlNoLoggedinParam    = location.protocol + '//' + location.host + location.pathname + '?provider=' + urlProvider + '&itemId=' +urlItemId;
//     // console.log('set url : '+urlNoLoggedinParam);
//     if(urlLoggedin != null){
//         setTimeout(function(){
//             window.location.href = urlNoLoggedinParam;
//         },2000);
//     }
// }
var onProductV2Exist = setInterval(function() {
    const ProductV2 = document.getElementById('ttp-product-v2');
    if(typeof(ProductV2) != 'undefined' && ProductV2 != null) {
        clearInterval(onProductV2Exist);
        serpLoading(ProductV2);
        const data = {
            provider: ProductV2.getAttribute('data-provider'),
            product_id: ProductV2.getAttribute('data-itemid')
        };
        console.log('Start V2');
        ttpAliGetSingle(data);
        activeSingle();
    }
}, 100);
function activeSingle() {
    var AliProduct = JSON.parse(localStorage.getItem('ali_product'));
    ali_on('click', 'single-product-thumbnail-img', function(e){
        document.getElementById('selected-img').classList.add('d-none');
    });
    ali_on('click', 'parent-sku', function(e){
        document.getElementById('selected-img').classList.remove('d-none');
        updateDynamicAttr( e.target.getAttribute('data-sku'), AliProduct );
        if( e.target.tagName == 'IMG' ) {
            let new_src = e.target.getAttribute('data-src');
            let elmSelectedImg = document.getElementById('ali-selected-img');
            elmSelectedImg.src = new_src;
            elmSelectedImg.setAttribute('data-original-img', new_src );
            let elmSelectedA = document.getElementById('ali-selected-a');
            elmSelectedA.setAttribute('data-featherlight', new_src );
            elmSelectedA.href = new_src;
        }
    });
}
function AliOnAddToCart() {
    document.getElementById('add-to-cart').addEventListener('click', AliAddToCart);
}
function getProductSKUs() {
    const elSKUs = document.querySelectorAll('.sku_qty');
    let d = {};
    for (var i = 0; i < elSKUs.length; i++) {
        if( elSKUs[i].value.trim().length && elSKUs[i].value.trim() > 0 ) {
            d[ elSKUs[i].getAttribute('data-sku-map') ] = {
                skuMap: elSKUs[i].getAttribute('data-sku-map'),
                qty: elSKUs[i].value.trim(),
            };
        }
    }
    return d;
}
function AliAddToCart(e) {
    e.preventDefault();
    const Product = document.getElementById('ttp-product-v2');
    let p_data = {
        'taobao_ttp_x'	: Product.getAttribute('data-x'),//user-id
        "provider"		: Product.getAttribute('data-provider'),
        "product_id"	: Product.getAttribute('data-itemid'),
        "skuId"			: 'skuId',
        "skuMap"		: '',
        "sku_data"		: getProductSKUs(),
        "qty"			: document.getElementById('product-total-qty').getAttribute('data-total'),
        "image"			: document.getElementById('ali-selected-img').src,
    };
    let data = {
        'action'			: 'ttp_add_to_cart_v2',
        'txt'				: '',
        'version'			: '2.0.0',
        'product_data'		: p_data,
        'product_data_raw'	: JSON.parse(localStorage.getItem('ali_product')),
    };
    if( Product.getAttribute('data-x').trim().length ) {
    } else {
        addToLocalCart(data);
    }
    console.log('product-item',data);
}
function addToLocalCart(data) {
    let newCart = {
        skus: {},
        product_data_raw: {}
    };
    let cart = JSON.parse( localStorage.getItem('ali_cart') );
    if( cart ) {
        cart = addItemToCart(data,cart);
    } else {
        cart = addItemToCart(data,newCart);
    }
    localStorage.setItem('ali_cart', JSON.stringify(cart));
}
function addItemToCart(data,cart) {
    Object.keys(data.product_data.sku_data).forEach(function(key) {
        if( cart.skus.hasOwnProperty(key) ) {
            let qty = parseInt( cart.skus[key]['qty'] );
            let more_qty = parseInt( data.product_data.sku_data[key]['qty'] );
            cart.skus[key]['qty'] = qty + more_qty;
        } else {
            cart.skus[key] = data.product_data.sku_data[key];
        }
        if( ! cart.product_data_raw.hasOwnProperty( data.product_data.product_id ) ) {
            cart.product_data_raw[data.product_data.product_id] = data.product_data_raw;
        }
    });
    jsUpdateMiniCart(cart);
    return cart;
}
function jsUpdateMiniCart(cart) {
    let h = '';
    if( cart.skus.length ) {
        for (let i = 0; i < cart.skus.length; i++) {
            h += '<div>' + cart.skus[i].skuMap + '</div>';
        }
    }
    let el_MiniCart = document.getElementsByClassName('shopcart-description');
    for(let i = 0; i < el_MiniCart.length; i++) {
        el_MiniCart[i].innerText = h;
    }
}
async function AliAddToCartAjax(data) {
    console.log('Start Add to cart! Ajax');
    const form = new FormData();
    form.append('action', 'ttp_add_to_cart_v2');//v.1 => 'ttp_add_to_card'
    form.append('version', '1.0.0');
    form.append('product_data', p_data);
    const params = new URLSearchParams(form);
    const response = await fetch(serpSingleV2.ajaxurl,{
        method: 'POST',
        credentials: 'same-origin',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
            'Cache-Control': 'no-cache'
        },
        body: params
    });
    console.log('go');
    if (response.ok) {
        let json = await response.json();
        console.log(json);
        localStorage.setItem('ali_product', JSON.stringify(json.template));
        genTemplateSingleProduct1688(json.template);
    } else {
        console.log("HTTP-Error: " + response.status);
    }
}
function ali_xx() {
    const els = document.querySelectorAll('.qty-edit button');
    for (var i = 0; i < els.length; i++) {
        els[i].addEventListener('click', function (e) {
            e.preventDefault();
            let skuStock = parseInt( e.target.closest(".line-add-qty").querySelector('.e-instock').getAttribute('data-instock') );
            let target;
            let target_input = e.target.closest(".qty-edit").querySelector('.sku_qty');
            let target_input_val = parseInt( target_input.value );
            let new_value = 0;
            let action;
            if( e.target.classList.contains('plus') || e.target.classList.contains('fa-plus') ) {
                action = 'plus';
                target = e.target;
                if( ! e.target.classList.contains('plus') ) {
                    target = e.target.closest(".plus");
                }
            } else if ( e.target.classList.contains('minute') || e.target.classList.contains('fa-minus') ) {
                action = 'minus';
                target = e.target;
                if( ! e.target.classList.contains('minute') ) {
                    target = e.target.closest(".minute");
                }
            }
            if( action ) {
                if( action == 'plus' ) {
                    new_value = target_input_val + 1;
                } else if( action == 'minus' ) {
                    new_value = target_input_val - 1;
                }
                if( new_value < 0 ) new_value = 0 ;
                if( new_value > skuStock ) new_value = skuStock;
            }
            target_input.value = new_value;
            console.log('click btn',target_input_val,new_value,skuStock);
            AliUpdateTotal();
        });
    }
    const sku_qty_input = document.querySelectorAll('.sku_qty');
    for (var i = 0; i < sku_qty_input.length; i++) {
        sku_qty_input[i].oninput = doCheckQtyValue;
    }
}
function doCheckQtyValue(e) {
    if( e.target.value < 0 || ! e.target.value.trim().length ) {
        e.target.value = 0;
    } else {
        e.target.value = parseInt( e.target.value );
    }
    let skuStock = parseInt( e.target.closest(".line-add-qty").querySelector('.e-instock').getAttribute('data-instock') );
    if( e.target.value > skuStock ) {
        e.target.value = skuStock;
    }
    console.log('set new value',e.target.value,skuStock);
    AliUpdateTotal();
}
function AliUpdateTotal(){
    const arr = document.querySelectorAll('.sku_qty');
    let total_Qty=0;
    for(let i=0;i<arr.length;i++){
        if( parseInt( arr[i].value ) ) {
            total_Qty += parseInt( arr[i].value );
        }
    }
    const elmTotalQty = document.getElementById('product-total-qty');
    elmTotalQty.innerHTML = total_Qty.toLocaleString();
    elmTotalQty.setAttribute('data-total', total_Qty );
    let priceRangForQty = g_PriceSteps(total_Qty);
    const allSkuPrice = document.querySelectorAll('.sku-price-rang');
	for (var i = 0; i < allSkuPrice.length; i++) {
        allSkuPrice[i].innerHTML = csCleanNum( priceRangForQty, 2 );
    }
    const allPriceDisplay = document.querySelectorAll('.final-price');
	for (var i = 0; i < allPriceDisplay.length; i++) {
        allPriceDisplay[i].classList.remove('active');
        if( allPriceDisplay[i].getAttribute('data-final-price') == priceRangForQty ) {
            allPriceDisplay[i].classList.add('active');
        }
    }
    const elmTotalAmount = document.getElementById('product-list-total');
    elmTotalAmount.innerHTML = csCleanNum( priceRangForQty*total_Qty, 2 ).toLocaleString();
    elmTotalAmount.setAttribute('data-total', priceRangForQty*total_Qty );
}
function updateDynamicAttr(sku,d) {
    if(sku) {
        console.log('has sku:',sku );
        const skuMap = Object.entries(d.sku_map);
        let elm = {};
        let twinSku;
        skuMap.forEach(function(item, i, allsku) {
            twinSku = item[0].split("&gt;");
            if( sku == twinSku[0] ) {
                elm[ twinSku[1] ] = item[1];
                document.querySelectorAll('[data-2nd-sku="' + twinSku[1] + '"]').forEach(function(e) {
                    e.innerHTML = item[1].canBookCount;
                    e.setAttribute('data-instock', item[1].canBookCount);
                });
                document.querySelectorAll('[data-sku-line="' + twinSku[1] + '"]').forEach(function(e) {
                    e.setAttribute('data-sku-id', item[1].skuId);
                    e.setAttribute('data-sku-map', item[0]);
                });
            }
        });
        const sku_qty_input = document.querySelectorAll('.sku_qty');
        for (var i = 0; i < sku_qty_input.length; i++) {
            sku_qty_input[i].value = 0;
        }
        let elmTotalAmount = document.getElementById('product-list-total');
        elmTotalAmount.innerHTML = 0;
        elmTotalAmount.setAttribute( 'data-total', 0 );
        const elmTotalQty = document.getElementById('product-total-qty');
        elmTotalQty.innerHTML = 0;
        elmTotalQty.setAttribute( 'data-total', 0 );
    }
}
async function ttpAliGetSingle(data) {
    const form = new FormData();
    form.append('action', 'serp_get_single');
    form.append('provider', data.provider);
    form.append('product_id', data.product_id);
    const params = new URLSearchParams(form);
console.log('get single data');
    const response = await fetch(serpSingleV2.ajaxurl,{
        method: 'POST',
        credentials: 'same-origin',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
            'Cache-Control': 'no-cache'
        },
        body: params
    });
    console.log('go');
    if (response.ok) {
        let json = await response.json();
        console.log(json);
        localStorage.setItem('ali_product', JSON.stringify(json.template));
        genTemplateSingleProduct1688(json.template);
    } else {
        console.log("HTTP-Error: " + response.status);
    }
}
function genTemplateSingleProduct1688(d) {
    let h = '';
    if(d) {
        h += '<h1 class="title f18 fw4">' + d.title + '</h1>';
        h += '<div class="top rt">';
            h += '<div class="gally">';
                h += '<div id="selected-img" class="x71x ab">';
                    h += '<a id="ali-selected-a" href="' + d.images[0] + '" data-featherlight="' + d.images[0] + '">';
                        h += '<img id="ali-selected-img" src="' + d.images[0] + '" data-original-img="' + d.images[0] + '">';
                    h += '</a>';
                h += '</div>';
                h += ali_slider_image(d);
                h += ali_slider_thumbnail(d);
            h += '</div>';
            h += '<div class="info">';
                h += '<style>.p-ads-top {background:#fc7823}</style>';
                h += '<div class="p-ads-top">text ads</div>';
                h += '<div class="info-price p-1688">';
                    h += '<div class="line l-price py-05">';
                        h += '<span class="label i-block pl-1">Shop:</span>';
                        h += '<span class="shop">' + d.seller_name + '</span>';
                    h += '</div>';
                    h += '<div id="price-steps" class="line l-price p-steps d-flex">';
                        h += '<div class="label flex-col">';
                            h += '<div class="item"><span>Price</span></div>';
                            h += '<div class="item ptop"><span>Min.</span></div>';
                        h += '</div>';
                        h += '<div class="step flex-row flex-wrap c ">';
                            h += g_PriceStepsHtml(d);
                            h += '<div class="porlor">';
                                h += '<div class="qty-in-cart">Qty in cart: ';
                                    h += '<span id="qty-in-cart" data-qty-in-cart="0">0</span>';
                                    h += '<input type="hidden" id="qty-in-cart-hd" name="qty-in-cart" value="0">';
                                h += '</div>';
                            h += '</div>';
                        h += '</div>';
                    h += '</div>';
                h += '</div>';
                h += '<hr class="sep">';
                h += g_SkuGroups(d);
                h += '<div id="product-sum" class="product-sum">';
                    h += '<div class="row">';
                        h += '<div class="col-lg-3">Amout</div>';
                        h += '<div class="col-lg-3"></div>';
                        h += '<div class="list-total col-lg-3">';
                        h += '<span class="sym f1x">&#165;</span> ';
                        h += '<span id="product-list-total" data-total="">0</span>';
                        h += '</div>';
                        h += '<div class="total-qty col-lg-3 text-center">';
                        h += '<span id="product-total-qty" data-total="0">0</span>';
                        h += '</div>';
                    h += '</div>';
                h += '</div>';
                h += '<div class="w-atc">';
                h += '<a id="add-to-cart-v2" class="add-to-cart-v2 c" href="">Add to cart</a>';
                h += '</div>';
            h += '</div>';
        h += '</div>';
        h += '<div id="p-content" class="p-c text-center">'
            h += '<div id="attr-data" class="row">';
            h += g_Attributes(d);
            h += '</div>';
            h += d.desc;
        h += '</div>';
        document.getElementById('ttp-product-v2').innerHTML = h;
        document.querySelector('.item-parent input.sku-item').checked = true;
        updateDynamicAttr( document.querySelector('.parent-sku').getAttribute('data-sku'), d );
        var csslider2 = tns({
            container: '.ttp-slider',
            items: 1,
            slideBy: 1,
            mouseDrag: true,
            lazyload: true,
            speed: 400,
            controls: false,
            //autoplay: true,
            autoplayPosition: 'bottom',
            autoplayButtonOutput: false,
            nav: true,
            navContainer: '.ttp-thumbnails',
            navAsThumbnails: true,
            lazyloadSelector: 'ttp-lazy-img',
            //viewportMax: true,
            autoplayHoverPause: true,
        });
        ali_xx();
        AliOnAddToCart();
    }
}
function g_SkuGroups(d) {
    let h = '';
    if(d.sku_props) {
        d.sku_props.forEach(function(item, i, skus) {
            let group_no = (i+1);
            let group_tag = '<div class="group" data-sku-group-type="parent" data-attr-group="'+group_no+'">';
            let label = '<div class="label txt-label v2">' + item.prop + '</div>';
            h += '<div id="sku-group">';
            if( i == 0 ) {
                    h += group_tag;
                        h += label;
                        h += '<div class="attr flex f-wrap">';
                            let i_type = '';
                            let i_img;
                            let i_label;
                            item.value.forEach(function(item, i, v) {
                                i_img = '';
                                i_label = '';
                                if(item.imageUrl) {
                                    i_type = 'parent';
                                    i_img = item.imageUrl;
                                    i_label = '<label for="sku-'+item.name+'" data-image="'+item.imageUrl+'">';
                                    i_label += '<img class="parent-sku" data-sku="'+item.name+'" src="'+item.imageUrl+'_40x40.jpg" data-src="'+item.imageUrl+'">';
                                    i_label += '</label>';
                                } else {
                                    i_type = 'child d-block';
                                    i_label = '<label class="txt parent-sku" for="sku-'+item.name+'">'+item.name+'</label>';
                                }
                                h += '<div class="item-'+i_type+'">';
                                h += '<input id="sku-'+item.name+'" type="radio" name="sku-'+group_no+'" class="sku-item" data-sku="'+item.name+'" data-label="'+item.name+'" data-image="'+i_img+'" data-sku-type="'+i_type+'" data-total-child="" data-sku-id="" data-sku-map="">';
                                h += i_label;
                                h += '</div>';
                            });
                        h += '</div>';
                    h += '</div>';
            } else {
                h += '<hr class="sep">';
                h += group_tag;
                    h += label;
                    h += '<div class="attr width-100 f12">';
                    item.value.forEach(function(item, i, v) {
                        h += '<div class="row line-add-qty c2">';
                            h += '<div class="e-col col-xs-3 fw6">'+item.name+'</div>';
                            h += '<div class="e-col col-xs-3"><span class="sym f10-5">&#165;</span> <div class="d-inline-block sku-price-rang">' + csCleanNum( d.show_price_ranges[0].price, 2 )+ '</div></div>';
                            h += '<div class="e-col col-xs-3 text-left">';
                                h += '<span class="ca">In Stock:</span> ';
                                h += '<div class="e-instock d-inline-block" data-2nd-sku="'+item.name+'" data-instock="">' + htmlLoading('normal') + '</div>';
                            h += '</div>';
                            h += '<div class="e-col col-xs-3 ip">';
                                h += '<div class="flex f-wrap rt qty-edit">';
                                    h += '<button class="minute"><i class="fa fa-minus" aria-hidden="true"></i></button>';
                                    h += '<input type="number" name="qty" id="qty" class="sku_qty" min="" value="0" data-sku-line="'+item.name+'" data-instock="" data-sku-id="" data-alert="">';
                                    h += '<button class="plus"><i class="fa fa-plus" aria-hidden="true"></i></button>';
                                h += '</div>';
                            h += '</div>';
                        h += '</div>';
                    });
                    h += '</div>';
                h += '</div>';
            }
            h += '</div>';
        });
    }
    return h;
}
function g_Attributes(d) {
    let v = '';
    if(d.attributes) {
        d.attributes.forEach(function(item, i, attr) {
            v += '<div class="col-md-6">' + item + '</div>';
        });
    }
    return v;
}
function g_PriceSteps(qty) {
    let v = 0;
    const product = JSON.parse(localStorage.getItem('ali_product'));
    if(product.show_price_ranges && qty) {
        product.show_price_ranges.forEach(function(item, i, step) {
            if( i == 0 ) {
                v = item['price'];
            } else if( qty >= item['startAmount'] ) {
                v = item['price'];
            }
        });
    }
    return v;
}
function g_PriceStepsHtml(d) {
    let h = '';
    let rang = '';
    if(d.show_price_ranges) {
        d.show_price_ranges.forEach(function(item, i, step) {
            if ( step[ (i+1) ] ) {
                rang = item['startAmount'] + ' - ' + (d.show_price_ranges[ (i+1) ]['startAmount'] - 1);
            } else {
                rang = '&#8805;' + item['startAmount'];
            }
            h += '<div class="p-group t--f--single" data-step="' + i + '" data-provider="1688" data-price-type="steps">';
            h += '<div class="e-price f30 flex-row flex-c st-66" data-price="' + item.price + '">';
                    h += '<div class="dp z--1">';
                        h += '<span class="sym f18">&#165;</span>';
                        h += '<span class="final-price" data-final-price="' + item.price + '" data-promo-price="' + item.price + '">' + item.price + '</span>';
                        h += '<div class="price-thb f12 c8">(THB ' + csCleanNum( item.price * TTPcargo.exchange_rate_yuan, 2 ) + ')</div>';
                        h += '<div class="e-begin f12" data-min-qty="' + d.begin_amount + '">(' + rang + ')</div>';
                    h +='</div>';
                h +='</div>';
            h +='</div>';
        });
    }
    return h;
}



document.addEventListener("DOMContentLoaded", function () {

    function cleanDuplicatePriceGroups() {

        const groups = document.querySelectorAll(".p-group");
        if (!groups.length) return;

        const seen = new Set();

        groups.forEach(group => {
            const finalPriceEl = group.querySelector(".final-price");

            // ถ้าไม่มีราคา → ลบ
            if (!finalPriceEl) {
                group.remove();
                return;
            }

            const price = parseFloat(finalPriceEl.getAttribute("data-final-price"));

            // ถ้าซ้ำ → ลบ p-group ทั้งอัน
            if (seen.has(price)) {
                group.remove();
                return;
            }

            // ถ้ายังไม่ซ้ำ → จำไว้
            seen.add(price);
        });

        // จัด active: ถ้าเหลืออันเดียว → ให้ active
        const groupsLeft = document.querySelectorAll(".p-group");
        if (groupsLeft.length === 1) {
            groupsLeft[0].classList.add("active");
        }
    }

    // รอจนกว่าระบบจะ render p-group เสร็จ
    const timer = setInterval(() => {
        const groups = document.querySelectorAll(".p-group");
        if (groups.length > 0) {
            clearInterval(timer);
            cleanDuplicatePriceGroups();
        }
    }, 50);

});





function csCleanNum(n, digits) {
    var negative = false;
    if (digits === undefined) {
        digits = 0;
    }
    if( n < 0) {
        negative = true;
        n = n * -1;
    }
    var multiplicator = Math.pow(10, digits);
    n = parseFloat((n * multiplicator).toFixed(11));
    n = (Math.round(n) / multiplicator).toFixed(2);
    if( negative ) {    
        n = (n * -1).toFixed(2);
    }
    return Number(n);
}
function ali_slider_image(data) {
    let v = '';
    if( data.images ) {
        v += '<div class="ttp-slider">';
        data.images.forEach(function(img_url, i, imgs) {
            v += '<div><a href="' + img_url + '"><img class="ttp-lazy-img" width="380" data-src="' + img_url + '" data-featherlight="' + img_url + '"></a></div>';
        });
        v += '</div>';
    }
    return v;
}
function ali_slider_thumbnail(data){
    let v = '';
    v += '<ul class="ttp-thumbnails thumbnails">';
    data.images.forEach(function(img_url, i, imgs) {
        v += '<li><img class="single-product-thumbnail-img ttp-lazy-img" width="50" src="' + img_url + '_50x50.jpg"></li>';
    });
    v += '</ul>';
    return v;
}
function serpLoading(target,style) {
    let s = 'padding: 64px 0 32px 0';
    if( style ) {
        s = style;
    }
    let html = '';
    html += '<div class="text-center" style="' + s + '">';
    html += '<div class="spinner2">';
    html += '<div class="bounce1"></div>';
    html += '<div class="bounce2"></div>';
    html += '<div class="bounce3"></div>';
    html += '</div>';
    html += '</div>';
    target.innerHTML = html;
}
function htmlLoading(size) {
    let s = '';
    if(size) s = ' ' + size;
    h = '';
    h += '<div class="spinner2' + s + '">';
    h += '<div class="bounce1"></div>';
    h += '<div class="bounce2"></div>';
    h += '<div class="bounce3"></div>';
    h += '</div>';
    return h;
}
function ali_on(eventType, targetClass, callback) {
    document.body.addEventListener(eventType, function (event) {
        if (event.target.classList.contains(targetClass)) {
            callback(event);
        }
    });
}