jQuery(function($){
    taobaoGet.start();
});

(function($) {

    var ChokStudio_TTP_taobaoGet;
    ChokStudio_TTP_taobaoGet = {

		start : function () {
			/**
			 * Start
			 */
            //console.log('taobaoGet.start');
		},
	};
	window.taobaoGet = ChokStudio_TTP_taobaoGet;
}(jQuery));