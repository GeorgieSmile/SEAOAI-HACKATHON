jQuery(function ($) {

	// v.0.0.1
	var dev = 'dev: require phone no. 2';
	// console.log( dev );
	//console.log('stt-thb',$('#stt-thb').data('stt-thb'));

	var UploadSlip = $('#bacs_upload_slip');
	var checkoutButton = '.checkout-button';

	// Global wallet_balance
	sessionStorage.setItem('wallet_balance', $('[data-wallet-balance]').data('wallet-balance'));

	// Global sub_total
	//if( window.sessionStorage.getItem('sub_total') == undefined ) {
	//sessionStorage.setItem( 'sub_total', $('#stt-thb').data('sub-total') );
	sessionStorage.setItem('sub_total', $('#stt-thb').data('stt-thb'));
	//}

	// Global payment_type
	if (window.sessionStorage.getItem('payment_type') == undefined) {
		sessionStorage.setItem('payment_type', 'bacs');
	}

	// Global img_slip_data
	if (window.sessionStorage.getItem('img_slip_data') == undefined) {
		sessionStorage.setItem('img_slip_data', '');
	}

	/**
	 * Set Payment & Trsportation selected
	 */
	csAli.setTransporttation();
	csAli.setTax_invoice();
	csAli.setPayment(sessionStorage.getItem('wallet_balance'), sessionStorage.getItem('sub_total'));

	/**
	 * Checkout detail
	 */
	var checkout_arg = {
		payment_type: sessionStorage.getItem('payment_type'),
		transportation: '',
		customer_note: $('#ttp-transportation-remark').val(),
		img_slip_data: '',
		phone: '',
	};

	/**
	 * Payment Change
	 */
	/*if( localStorage['payment'] ) {
		$('#' + localStorage['payment']).prop('checked',true);
	} else {
		$('#bacs').prop('checked',true);
	}*/
	$(document).on('change', '#ttp_payment_section input', function (e) {
		e.preventDefault();

		let pt;

		if (this.checked) {
			if ($(this).val() == 'bacs') {
				pt = 'bacs';
			} else {
				pt = 'wallet';
			}
			sessionStorage.setItem('payment_type', pt);
		}
		csAli.setPayment(sessionStorage.getItem('wallet_balance'), sessionStorage.getItem('sub_total'));
	});

	/**
	 * Transportation Change
	 */
	$(document).on('change', '#ttp-transportation input[name="transportation"]', function (e) {
		e.preventDefault();
		if (this.checked) {
			sessionStorage.setItem('transportation', $(this).val());
		}
	});
	
	$(document).on('change', '#ttp-transportation input[name="tax_invoice"]', async function(e) {
		e.preventDefault();
		if (this.checked) {
			sessionStorage.setItem('tax_invoice', $(this).val());
			await update_tax_invoice($(this).val())
			cso.reloadSubTotal();
		}
	});

	$(document).on('change', '#upload-file', function () {
		let hasProduct = $('.mc-line').length > 0;

		if (this.files.length && hasProduct) {
			$('i.iclear').css('display', 'inline-block');
			oPlaceOrder();
		} else {
			xPlaceOrder();
		}
		handleFiles(this.files);
	});

	$(document).on('click', '.destination-wrap .iclear', function () {
		$(this).hide();
		$('#destination').html('');
		$('#upload-file').val('');
		UploadSlip.val('');
		xPlaceOrder();
		ScrollTo('#ttp_payment_section');
	});

	$(document).on('click', 'label[for="wallet"]', function () {
		if (!$('#wallet').is(':checked') && !$('#wallet').prop('disabled')) {
			ScrollTo('#ttp-payment');
		}
	});

	$(document).on('click', checkoutButton, function (e) {

		e.preventDefault();

		// console.log(sessionStorage.getItem('tax_invoice') == "tax_invoice_true")

		// if( ! $(this).hasClass('disabled') && $('#checkout-phone-no').val().length > 0 ) {
		if (!$(this).hasClass('disabled') && ($('#addr_id').text().length > 0 && parseInt($('#addr_id').text()) > 0)) {

			
			checkout_arg['tax_invoice_addr_id'] = '0';
			if($('input[name="tax_invoice"]:checked').length > 0 && $('input[name="tax_invoice"]:checked').val() == "tax_invoice_true"){
				if($('#tax_invoice_addr_id').text().length == 0 || parseInt($('#tax_invoice_addr_id').text()) == 0){
					alert("กรุณาเลือกที่อยู่ออกใบกำกับภาษี");
					$('.checkout-button').removeClass('do-checkout');
					return;
				}else{
					checkout_arg['tax_invoice_addr_id'] = $('#tax_invoice_addr_id').text();
				}
			}
			
			if($(this).hasClass('do-checkout')){
				alert("กำลังส่งคำสั่งซื้อกรุณารอสักครู่...");
				return;
			}
			
			$(this).addClass('do-checkout');
			
			checkout_arg['tax_invoice_addr_id'] = $('#tax_invoice_addr_id').text();

			// if($("input#tax_invoice_true"))

			// Transportation
			checkout_arg['transportation'] = sessionStorage.getItem('transportation');
			checkout_arg['tax_invoice'] = ($('input[name="tax_invoice"]:checked').length > 0 ? $('input[name="tax_invoice"]:checked').val() : "tax_invoice_none");

			// Payment
			checkout_arg['payment_type'] = sessionStorage.getItem('payment_type');

			// Customer note
			// let cus_phone_txt =  "\n" + 'Tel.: ' + $('#checkout-phone-no').val();
			let cus_phone_txt = "\n" + 'Tel.: ' + $('#addr_phone').text().replace('โทรศัพท์ ', '');
			//let cus_phone_txt = '..';
			// checkout_arg['phone'] = $('#checkout-phone-no').val();
			checkout_arg['phone'] = $('#addr_phone').text().replace('โทรศัพท์ ', '');


			// เพิ่มมาใหม่ตอนให้เลือกที่อยู่ 2022/08/13
			checkout_arg['addr_id'] = $('#addr_id').text();

			checkout_arg['customer_note'] = $('#ttp-transportation-remark').val() + cus_phone_txt;

			// $('#tax_invoice_addr_id').text()
            checkout_arg['version'] = '2';
            checkout_arg['tax_invoice_bill_taxId'] = $('#tax_invoice_bill_taxId').text()
            checkout_arg['tax_invoice_bill_first_name'] = $('#tax_invoice_bill_first_name').text()
            checkout_arg['tax_invoice_bill_contact_first_name'] = $('#tax_invoice_bill_contact_first_name').text()
            checkout_arg['tax_invoice_bill_contact_lastname'] = $('#tax_invoice_bill_contact_lastname').text()
            checkout_arg['tax_invoice_bill_lastname'] = $('#tax_invoice_bill_lastname').text()
			checkout_arg['tax_invoice_full_name'] = $('#tax_invoice_full_name_com').text()
            checkout_arg['tax_invoice_bill_company'] = $('#tax_invoice_bill_company').text()
            checkout_arg['tax_invoice_bill_type'] = $('#tax_invoice_bill_type').text()
            checkout_arg['tax_invoice_bill_country'] = $('#tax_invoice_bill_country').text()
            checkout_arg['tax_invoice_bill_branch'] = $('#tax_invoice_bill_branch').text()
            checkout_arg['tax_invoice_bill_branchNum'] = $('#tax_invoice_bill_branchNum').text()
            checkout_arg['tax_invoice_bill_address'] = $('#tax_invoice_bill_address').text()
            checkout_arg['tax_invoice_bill_address2'] = $('#tax_invoice_bill_address2').text()
            checkout_arg['tax_invoice_bill_district'] = $('#tax_invoice_bill_district').text()
            checkout_arg['tax_invoice_bill_city'] = $('#tax_invoice_bill_city').text()
            checkout_arg['tax_invoice_bill_state_name'] = $('#tax_invoice_bill_state_name').text()
            checkout_arg['tax_invoice_bill_state'] = $('#tax_invoice_bill_state').text()
            checkout_arg['tax_invoice_bill_postcode'] = $('#tax_invoice_bill_postcode').text()
            checkout_arg['tax_invoice_bill_tell'] = $('#tax_invoice_bill_tell').text()
            checkout_arg['tax_invoice_bill_email'] = $('#tax_invoice_bill_email').text()


			if (sessionStorage.getItem('payment_type') == 'bacs') {
				checkout_arg['img_slip_data'] = sessionStorage.getItem('img_slip_data');
			}

			console.log(checkout_arg)

			// Create Order
			createOrder(checkout_arg);

			$(this).addClass('spinner relative checkout-processing').text($(this).data('processing'));
		} else {
			// if( $('#checkout-phone-no').val().length == 0 ) {
			// 	alert( $('#checkout-phone-no').data('alert-empty') );
			// } else {
			// 	alert( $('#cs-upload-slip').data('alert') );
			// }
			// console.log($('#addr_id').text().length);
			if ($('#addr_id').text().length == 0 || parseInt($('#addr_id').text()) == 0) {
				alert("กรุณาเลือกที่อยู่ในการจัดส่ง");
			} else {
				alert($('#cs-upload-slip').data('alert'));
			}
		}
	});

	$(document).on('click', '.button-go-to-checkout', function(e) {

		e.preventDefault();

		$(".button-go-to-checkout").prop("disabled", true);

		let skuIdData = [];

		for (let idx = 0; idx < $(".cart-checklist-product").length; idx++) {
			if($(".cart-checklist-product")[idx].checked){
				const skuId = $(".cart-checklist-product")[idx].dataset.skuId;
				skuIdData.push(skuId)
			}
		}

		if(skuIdData.length > 0){
			console.log(skuIdData)
			createCheckoutCart(skuIdData)
		}


		setTimeout(() => {
			$(".button-go-to-checkout").prop("disabled", false);
		}, 3000);
	});

	// .header-control.shopcart-description
	if ($('div').hasClass('ttp-full-cart')) {
		$('.header-control .shopcart-description').addClass('d-none');
		$('body').addClass('cart-page');
	}
	/*$(document).on('mouseover', '.block-minicart.kuteshop-mini-cart', function(e) {
		e.preventDefault();
		console.log('M hover!');
	});*/

	/* ---------------------------------------------- Function ---------------------------------------------- */

	/**
	 * Create Order
	 */
	function createOrder(checkout_arg) {

		let data = {
			'action': 'chokapi_create_order',
			'chokapi_create_order_text': ChokAPIcreateOD.co,
			'payment_method': checkout_arg.payment_type,
			'transportation': checkout_arg.transportation,
			'tax_invoice': checkout_arg.tax_invoice,
			'customer_note': checkout_arg.customer_note,
			'img_slip_data': checkout_arg.img_slip_data,
			'phone': checkout_arg.phone,
			'addr_id': checkout_arg.addr_id,
			'tax_invoice_addr_id': checkout_arg.tax_invoice_addr_id,
			'version': checkout_arg.version,
            'tax_invoice_bill_taxId': checkout_arg.tax_invoice_bill_taxId,
            'tax_invoice_bill_first_name': checkout_arg.tax_invoice_bill_first_name,
            'tax_invoice_bill_contact_first_name': checkout_arg.tax_invoice_bill_contact_first_name,
            'tax_invoice_bill_contact_lastname': checkout_arg.tax_invoice_bill_contact_lastname,
            'tax_invoice_bill_lastname': checkout_arg.tax_invoice_bill_lastname,
			'tax_invoice_full_name': checkout_arg.tax_invoice_full_name_com,
            'tax_invoice_bill_company': checkout_arg.tax_invoice_bill_company,
            'tax_invoice_bill_type': checkout_arg.tax_invoice_bill_type,
            'tax_invoice_bill_country': checkout_arg.tax_invoice_bill_country,
            'tax_invoice_bill_branch': checkout_arg.tax_invoice_bill_branch,
            'tax_invoice_bill_branchNum': checkout_arg.tax_invoice_bill_branchNum,
            'tax_invoice_bill_address': checkout_arg.tax_invoice_bill_address,
            'tax_invoice_bill_address2': checkout_arg.tax_invoice_bill_address2,
            'tax_invoice_bill_district': checkout_arg.tax_invoice_bill_district,
            'tax_invoice_bill_city': checkout_arg.tax_invoice_bill_city,
            'tax_invoice_bill_state_name': checkout_arg.tax_invoice_bill_state_name,
            'tax_invoice_bill_state': checkout_arg.tax_invoice_bill_state,
            'tax_invoice_bill_postcode': checkout_arg.tax_invoice_bill_postcode,
            'tax_invoice_bill_tell': checkout_arg.tax_invoice_bill_tell,
            'tax_invoice_bill_email': checkout_arg.tax_invoice_bill_email,
		};
		console.log('data checkout', data);

		let jqxhr = $.post(ChokAPIcreateOD.ajax_url, data, function (response) { })
			//.done(function( response ) {})
			.fail(function (response) { })
			.always(function (response) { });

		jqxhr.always(function (response) {


			$('.checkout-button').removeClass('do-checkout');

			// Clear Cart
			cso.clearCart();
			cso.setQty2text();
			csAli.clearSession();

			// Remove sections
			$('#ttp-transportation, #ttp-payment, button.del-btn').remove();

			ScrollTo('h2.page-title');

			let ds = $('.checkout-processing').data('success');
			let dt = $('.checkout-processing').data('txt');
			$('.checkout-processing').removeClass('spinner relative').text(ds).trigger('blur');

			setTimeout(function () {
				$('.checkout-button,#ttp-payment-method').fadeOut(270);
				//$('.checkout-processing').text(dt).removeClass('checkout-processing');
				if ($('.page-title').length) {
					$('.page-title span').text(TTPcargo.text_thank_you);
					$('.page-title').after(response);
				}
			}, 800);

			//TEST
			//$('#ss8').before(response);
		});

	}


	async function update_tax_invoice(value) {

		let data = {
			'action': 'update_tax_invoice',
			'tax_invoice': value,
		};
		console.log('data checkout', data);

		let jqxhr = await $.post(ChokAPIcreateOD.ajax_url, data, function (response) { });

	}

	

	function createCheckoutCart( skuIdData ){

		let data = {
			'action': 'ttpcargo_create_checkout',
			'ttpcargo_create_checkout_text': ChokAPIcreateOD.co,
			'skuIdData': skuIdData,
		};

		console.log('data checkout', data);

		let jqxhr = $.post( ChokAPIcreateOD.ajax_url, data, function(response) {})
		  //.done(function( response ) {})
		  .fail(function( response ) {})
		  .always(function( response ) {});

		jqxhr.always(function(response) {
			if (response == "1" && response == true){
				window.location = "/check-out-cart";
			}
		});

	}

	function getFileSizeFromBase64(base64String) {
		// เอาส่วนที่เป็น prefix ของ data URL ออก ("data:image/jpeg;base64,")
		var base64Data = base64String.split(',')[1];

		// คำนวณขนาดของ Base64 string (โดยใช้สูตร)
		var padding = (base64Data.charAt(base64Data.length - 2) === '=') ? 2 : (base64Data.charAt(base64Data.length - 1) === '=') ? 1 : 0;
		var fileSizeInBytes = (base64Data.length * 3 / 4) - padding;

		// แปลงจาก bytes เป็น KB
		var fileSizeInKB = fileSizeInBytes / 1024;

		return fileSizeInKB.toFixed(2); // คืนค่าขนาดเป็น KB พร้อมแสดงทศนิยม 2 ตำแหน่ง
	}

	function base64ToBlob(base64, mime) {
		var byteString = atob(base64.split(',')[1]);
		var ab = new ArrayBuffer(byteString.length);
		var ia = new Uint8Array(ab);
		for (var i = 0; i < byteString.length; i++) {
			ia[i] = byteString.charCodeAt(i);
		}
		return new Blob([ab], { type: mime });
	}

	function handleFiles(files) {
		if (!files.length) {
			destination.innerHTML = "<p>No files selected!</p>";
		} else {
			destination.innerHTML = '';
			var list = document.createElement('ul');
			destination.appendChild(list);

			for (var i = 0; i < files.length; i++) {

				var file = files[i];
				var reader = new FileReader();

				// if (file.name.includes('eiei123')) {
					reader.onload = function (e) {

						var img = new Image();
						img.src = e.target.result;

						img.onload = function () {

							var canvas = document.createElement('canvas');
							var ctx = canvas.getContext('2d');

							canvas.width = img.width;
							canvas.height = img.height;

							var quality = 1.0;
							// console.log(file.size)
							// console.log(700 * 1024)
							// if (file.size > 700 * 1024) {
								quality = 0.2;
							// }

							ctx.drawImage(img, 0, 0, img.width, img.height);

							var compressedDataUrl = canvas.toDataURL('image/jpeg', quality);
							var fileSize = getFileSizeFromBase64(compressedDataUrl);

							var blob = base64ToBlob(compressedDataUrl, 'image/jpeg');

							var newReader = new FileReader();
							newReader.onload = function (e) {
								sessionStorage.setItem('img_slip_data', e.target.result);
								document.getElementById('bacs_upload_slip').value = sessionStorage.getItem('img_slip_data');
							};
							newReader.readAsDataURL(blob);

							var li = document.createElement('li');
							list.appendChild(li);

							var imgElement = document.createElement('img');
							imgElement.src = window.URL.createObjectURL(blob);
							imgElement.className = 'payment-slip';
							imgElement.onload = function () {
								window.URL.revokeObjectURL(this.src);
							};
							li.appendChild(imgElement);

							var info = document.createElement('div');
							info.className = 'file-info';
							info.innerHTML = file.name + ': ' + blob.size + ' bytes';
							li.appendChild(info);
						};
					};

					reader.readAsDataURL(file);
				// } else {
				// 	reader.onload = function (e) {
				// 		sessionStorage.setItem('img_slip_data', e.target.result);
				// 		document.getElementById('bacs_upload_slip').value = sessionStorage.getItem('img_slip_data');
				// 		//document.getElementById('bacs_upload_slip').value=e.target.result;
				// 	};

				// 	reader.readAsDataURL(files[i]);

				// 	var li = document.createElement('li');
				// 	list.appendChild(li);

				// 	var img = document.createElement('img');
				// 	img.src = window.URL.createObjectURL(files[i]);
				// 	img.className = 'payment-slip';
				// 	img.onload = function () {
				// 		window.URL.revokeObjectURL(this.src);
				// 	};
				// 	li.appendChild(img);

				// 	var info = document.createElement('div');
				// 	info.className = 'file-info';
				// 	info.innerHTML = files[i].name + ': ' + files[i].size + ' bytes';
				// 	li.appendChild(info);
				// }

			}
		}
	}

	function xPlaceOrder() {
		$('.checkout-button').addClass('disabled');
	}
	function oPlaceOrder() {
		$('.checkout-button').removeClass('disabled');
		$('.upload-wrap').removeClass('e-alert');
	}

	function ScrollTo(xID) {
		$([document.documentElement, document.body]).animate({
			scrollTop: $(xID).offset().top - 100
		}, 800);
	}
});

(function ($) {

	var ChokStudio_Ali;
	ChokStudio_Ali = {

		setTransporttation: function () {
			/**
			 * Transportation
			 */
			if (window.sessionStorage.getItem('transportation')) {
				$('#' + sessionStorage.getItem('transportation')).prop('checked', true);
				sessionStorage.setItem('transportation', sessionStorage.getItem('transportation'));
			} else {
				$('#truck').prop('checked', true);
				sessionStorage.setItem('transportation', 'truck');
			}
		},
		setTax_invoice: function () {
			/**
			 * Tax_invoice
			 */
			if (window.sessionStorage.getItem('tax_invoice')) {
				// $('#' + sessionStorage.getItem('tax_invoice')).prop('checked', true);
				// $('.alert_tax_invoice').addClass("d-none");
				// $('#wallet-detail').removeClass("payment-blur");
				
				sessionStorage.setItem('tax_invoice', sessionStorage.getItem('tax_invoice'));
			} else {
				// $('#wallet-detail').addClass("payment-blur");
				sessionStorage.setItem('tax_invoice', '');
			}
		},
		setPayment: function (wallet_balance, sub_total) {
			// console.log('w',wallet_balance,'stt',sub_total);
			let w = parseInt(wallet_balance);
			let s = parseInt(sub_total);

			$('.checkout-button').addClass('disabled');

			/**
			 * Payment
			 */
			if (sessionStorage.getItem('payment_type') == 'wallet') {
				// Wallet
				if (w >= s) {
					$('#wallet').prop('checked', true).attr('disabled', false);
					$('.checkout-button').removeClass('disabled');
				} else {
					// BACS
					// Force BACS
					sessionStorage.setItem('payment_type', 'bacs');
					$('#wallet').prop('checked', false).attr('disabled', true);
					$('#bacs').prop('checked', true);
				}
			} else {
				// BACS
				$('#bacs').prop('checked', true);

				// Wallet
				$('#wallet').prop('checked', false);

				if (w < s) {
					$('#wallet').attr('disabled', true);
				} else {
					$('#wallet').attr('disabled', false);
				}
			}
		},
		clearSession: function () {
			sessionStorage.removeItem('transportation');
			sessionStorage.removeItem('tax_invoice');
			sessionStorage.removeItem('wallet_balance');
			sessionStorage.removeItem('sub_total');
			sessionStorage.removeItem('payment_type');
			sessionStorage.removeItem('img_slip_data');
			
			let data = {
				'action': 'update_tax_invoice',
				'tax_invoice': null,
			};

			let jqxhr = $.post(ChokAPIcreateOD.ajax_url, data, function (response) { });
		}
	};
	window.csAli = ChokStudio_Ali;
}(jQuery));





$(document).on('click', '.search-img-link', function (e) {
    e.preventDefault();

    var page = $(this).data('page');

    console.group("📸 Image Search Click");
    console.log("Page :", page);
    console.log("currentImgs :", currentImgs);
    console.log("ajaxurl :", ajaxurl);
    console.groupEnd();

    loadProducts(page, currentImgs);
});

function loadProducts(page, currentImgs) {

    console.group("🚀 ttp_search_imgs2");

    console.log("POST URL :", ajaxurl);
    console.log("Page :", page);
    console.log("Imgs :", currentImgs);

    $('.spinner2').show();

    $.ajax({
        url: ajaxurl,
        type: 'POST',
        dataType: 'html',
        data: {
            action: 'ttp_search_imgs2',
            page: page,
            imgs: currentImgs
        },

        beforeSend: function () {
            console.log("⏳ Sending AJAX...");
        },

        success: function (response, status, xhr) {

            console.log("✅ AJAX Success");
            console.log("Status :", status);
            console.log("HTTP :", xhr.status);
            console.log("Response Length :", response.length);
            console.log("Response :", response);

            $('.product-container').html(response);
            $('.spinner2').hide();

            console.groupEnd();
        },

        error: function (xhr, status, error) {

            console.error("❌ AJAX Error");
            console.log("Status :", status);
            console.log("HTTP :", xhr.status);
            console.log("Error :", error);
            console.log("Response :", xhr.responseText);

            $('.spinner2').hide();

            console.groupEnd();
        }
    });
}


