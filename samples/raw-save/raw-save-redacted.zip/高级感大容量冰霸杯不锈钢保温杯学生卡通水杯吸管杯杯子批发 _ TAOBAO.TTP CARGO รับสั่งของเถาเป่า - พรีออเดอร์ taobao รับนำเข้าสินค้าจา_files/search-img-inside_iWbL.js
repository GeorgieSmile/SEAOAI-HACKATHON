(function ($) {

  function updateSearchLayout() {
    var viewportWidth = $(window).width();

    var $serp       = $('#serp');
    var $serpSearch = $('#serp-search');
    var $imgSearch  = $('#imgsearch');
    var $searchc    = $('#searchc');

    if (!$serp.length || !$serpSearch.length || !$imgSearch.length || !$searchc.length) {
      return;
    }

    // ✅ Force opacity:1 like inline style="opacity:1;"
    $imgSearch.css('opacity', 1);

    // ✅ Desktop / wider screens: put camera inside input area
    if (viewportWidth >= 451) {

      // If not already wrapped, wrap the input
      if (!$serpSearch.parent().hasClass('search-wrapper')) {
        var $wrapper = $('<div/>', { 'class': 'search-wrapper' });

        // Put wrapper inside form, before the input
        $serpSearch.before($wrapper);
        $wrapper.append($serpSearch);
      }

      var $wrapper = $serpSearch.parent('.search-wrapper');

      // Ensure imgsearch is inside wrapper too
      if (!$imgSearch.parent().is($wrapper)) {
        $wrapper.append($imgSearch);
      }

    } else {
      // 📱 Mobile / narrow screens: restore original structure

      var $wrapper = $serpSearch.parent('.search-wrapper');

      if ($wrapper.length) {
        // Move input back out of wrapper into form
        $wrapper.before($serpSearch);

        // Move imgsearch back below the form (like original HTML)
        $imgSearch.insertAfter($serp);

        // Remove wrapper if empty
        if ($wrapper.is(':empty')) {
          $wrapper.remove();
        }
      }
    }
  }

  $(function () {
    // Run once on page load
    updateSearchLayout();

    // Run again on every resize
    $(window).on('resize', function () {
      updateSearchLayout();
    });
  });

})(jQuery);
