jQuery(function($){

	/**
	 * Set Cookie
	 */
	/*if ( cgt.getCookie('cgt-lang').length < 1 ){
		cgt.setCookie( 'cgt-lang',$('.lang.default').data('lang'), 365 );
	} else {
		$('.cgt .lang').removeClass('default');
		$('[data-lang="' + cgt.getCookie('cgt-lang') + '"]').addClass('default');
	}*/

	/**
	 * Prepare Translate
	 */
	//cgt.prepareTranslate( $('meta[name=chokstudio-translate]').attr('content') );
/*
	$('body').on('DOMNodeInserted', '#ttp-product', function(e) {
		if ($(e.target).attr('class') === 'product-single') {

			var target = '.product-actions-single td.label, .product-single-info h2';

			$(target).each(function( index ) {
				$(this).attr('data-cgt',index);
				$(this).attr('data-original',$(this).text());
			});

			if( $('.lang.source.default').length ){
				$(this).text( $(this).data('original') );
			} else {
				/**
				 * Translate
				 */
				/*cgt.translateList( cgt.getCookie('cgt-lang') ); // th
			}
		}
	});*/

	cgt.translate();
});

(function($) {

    var ChokStudio_Google_Translate;
    ChokStudio_Google_Translate = {

		prepareTranslate : function ( clss ) {
			/**
			 * Prepare text
			 * clss '.c1, .c2, .c8, .s7'
			 */
			$(clss).each(function( index ) {

				if( typeof $(this).data('original') === 'undefined' ){
					var t = $(this).text().trim();
					if( t.length ){
						$(this).attr('data-cgt',index);
						$(this).attr('data-original', t );
						$(this).attr('data-length', t.length);
					}
				}
			});
		},
		translate : function () {
			$(document).on('click', '[data-lang]', function(){

				var clickedLang = $(this).data('lang');

				/**
				 * Reset Cookie
				 */
				cgt.setCookie( 'cgt-lang','', -1 );

				/**
				 * Update default to current lang
				 */
				$('[data-lang]').removeClass('default');
				$(this).addClass('default');

				if( clickedLang == $('.lang.source').data('lang') ){

					if( $('[data-original]').length ){

						$('[data-original]').each(function( index ) {
							$(this).text( $(this).data('original') );
						});
					}
				} else if( $('[data-' + clickedLang + ']').length ) {
					/**
					 * if stored
					 */
					$('[data-' + clickedLang + ']').each(function( index ) {
						$(this).text( $(this).data(clickedLang) );
					});
				} else {
					/**
					 * Translate
					 */
					cgt.translateList( clickedLang ); // th
				}
			});
		},
		translateText : function ( lang ) {
			$('[data-cgt]').each(function( index ) {
				var inx = $(this).data('cgt');
				var data = {
					'action': 'cgt_translate_text',
					'cgt_target': lang,
					'cgt_text': $(this).data('original'),
					'cgt_source': $('.lang.source').data('lang'),
				};
				var jqxhr = $.post( ajax_object_cgt.ajax_url, data, function(response) {})
				  //.done(function( response ) {})
				  .fail(function( response ) {})
				  .always(function( response ) {});

				jqxhr.always(function(response) {
					var t = JSON.parse(response);
					$('[data-cgt="'+inx+'"]').text( t.data.translations[0].translatedText );
				});
			});
		},
		translateList : function ( lang ) {
			/**
			 * Prepare Translate
			 */
			cgt.prepareTranslate( $('meta[name=chokstudio-translate]').attr('content') );

			var list = [];
			var txtLength = 0;

			$('[data-cgt]:not(.done)').each(function( index ) {

				txtLength += $(this).data('length');
				if( txtLength < 1000 ){
					list.push( $(this).data('original') );
					$(this).removeClass('next').addClass('wait');
				}
			});

			var data = {
				'action': 'cgt_translate',
				'cgt_target': lang,
				'cgt_list': list,
				'cgt_source': $('.lang.source').data('lang'),
			};

			var jqxhr = $.post( ajax_object_cgt.ajax_url, data, function(response) {})
			  //.done(function( response ) {})
			  .fail(function( response ) {})
			  .always(function( response ) {});

			jqxhr.always(function(response) {

				var t = JSON.parse(response);

				$('[data-cgt].wait').each(function( index ) {
					var inx = $(this).data('cgt');
					console.log(t.data)
					var ts = t.data.translations[index].translatedText;
					$(this).text( ts );
					$(this).attr( 'data-' + lang, ts );
					$(this).removeClass('wait').addClass('done');
				});

				$('[data-cgt]:not(.wait,.done)').each(function( index ) {
					$(this).addClass('next');
				});

				if( $('[data-cgt].next').length ){
					console.log('Next='+$('[data-cgt].next').length);
					cgt.translateList( lang ); // th
				} else {
					//console.log('finisH');
				}
			});
		},
		setCookie : function (cname, cvalue, exdays) {
			var d = new Date();
			d.setTime(d.getTime() + (exdays*24*60*60*1000));
			var expires = "expires="+ d.toUTCString();
			document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
		},
		getCookie : function (cname) {
			var name = cname + "=";
			var decodedCookie = decodeURIComponent(document.cookie);
			var ca = decodedCookie.split(';');
			for(var i = 0; i <ca.length; i++) {
				var c = ca[i];
				while (c.charAt(0) == ' ') {
					c = c.substring(1);
				}
				if (c.indexOf(name) == 0) {
					return c.substring(name.length, c.length);
				}
			}
			return "";
		}
	};
	window.cgt = ChokStudio_Google_Translate;

}(jQuery));