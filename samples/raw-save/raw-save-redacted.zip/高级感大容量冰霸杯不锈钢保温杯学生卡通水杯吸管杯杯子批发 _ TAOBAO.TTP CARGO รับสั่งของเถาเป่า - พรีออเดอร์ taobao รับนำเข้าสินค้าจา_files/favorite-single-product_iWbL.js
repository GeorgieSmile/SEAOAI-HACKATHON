
jQuery(function($){

    const urlAPI    = "https://ttpcargo.com";
    // console.log('Favorite V1');

    // $('body').on('ready', '#btn-favorite', function(){
    //     console.log('load btn-favorite');
    // });


    $('body').on('click', '#btn-favorite', function (){

        var old_button  = $('#btn-favorite').html();
        var old_class   = $('#btn-favorite').attr('class');

        $('#btn-favorite span').text("");
        $('#btn-favorite i').attr('class',"fa fa-spinner fa-spin");
        $('#btn-favorite').prop('disabled', true);
        var dataProvider    = $('#ttp-product').data('provider');
        var dataSellerName    = $('#ttp-product .shop').text();
        var dataItemId      = $('#ttp-product').data('itemid');
        var dataImg         = typeof($('#tns1-item0 a').attr('href')) != 'undefined' ? $('#tns1-item0 a').attr('href') : "https://taobao.ttpcargo.com/wp-content/uploads/2022/06/TAOBAO.TTP_.png";
        var dataTitle      = $('#ttp-product .title.f18.fw4').text();
        var dataUserId    = $('#btn-favorite').data('user');
        if(ttp_price_steps['price'].length > 1){
            var dataDisplayPrice      = "¥"+ttp_price_steps['price'][0]['price']+"-¥"+ttp_price_steps['price'][1]['price'];
        }else{
            var dataDisplayPrice      = "¥"+ttp_price_steps['price'][0]['price'];
        }

        let dataFavorite    = {
            'product_type': dataProvider,
            'seller_name': dataSellerName,
            'item_id': dataItemId,
            'img': dataImg,
            'title': dataTitle,
            'display_price': dataDisplayPrice,
            'rate': "",
            'user_id': dataUserId
        };

        // console.log(dataFavorite);
        
        jQuery.ajax({
            url: urlAPI+"/api/favorite_add.php",
            global: false,
            type: 'post',
            cache: false,
            dataType: 'json',
            data: JSON.stringify(dataFavorite),
            success: function(response) {
                // console.log(response);
                if(response.status == true){
                    if(response.mes == "success"){
                        setTimeout(function() {
                            $('#btn-favorite').attr('class', "atc rt btn-favorite liked");
                            $('#btn-favorite span').text("ถูกใจ");
                            $('#btn-favorite i').attr('class',"fa fa-heart");
                            $('#btn-favorite').prop('disabled', false);
                        },1000);
                    }else{
                        setTimeout(function() {
                            $('#btn-favorite').attr('class', "atc rt btn-favorite");
                            $('#btn-favorite span').text("ถูกใจ");
                            $('#btn-favorite i').attr('class',"fa fa-heart-o");
                            $('#btn-favorite').prop('disabled', false);
                        },1000);
                    }
                    
                    $('.favorite-cout').text(response.count);
                }else{
                    setTimeout(function() {
                        $('#btn-favorite').attr('class', old_class);
                        $('#btn-favorite').html(old_button);
                    },1000);
                    // console.log(response.mes);
                }
            },
            error: function(jqXHR, textStatus, errorThrown) {
                console.log(jqXHR, textStatus, errorThrown);
                setTimeout(function() {
                    $('#btn-favorite').attr('class', old_class);
                    $('#btn-favorite').html(old_button);
                },1000);
            }
            
        });
    });

    $(document).ready(function (){
        var onBtnFavoriteCreated = setInterval(function() {
            let btnFaveorite = $('.atc').text();
            // console.log(typeof(btnFaveorite), btnFaveorite);
            if(typeof(btnFaveorite) != 'undefined' && btnFaveorite.trim() != "") {
                clearInterval(onBtnFavoriteCreated);

                var dataItemId      = $('#ttp-product').data('itemid');
                var dataUserId    = $('#btn-favorite').data('user');

                jQuery.ajax({
                    url: urlAPI+"/api/user_favorite.php",
                    global: false,
                    type: 'post',
                    cache: false,
                    dataType: 'json',
                    data: {
                        user_id: dataUserId,
                        itemId: dataItemId
                    },
                    success: function(response) {
                        // console.log(response);
                        if(response.result == 1){
                            $('#btn-favorite').attr('class', "atc rt btn-favorite liked");
                            $('#btn-favorite i').attr('class',"fa fa-heart");
                        }else{
                            $('#btn-favorite').attr('class', "atc rt btn-favorite");
                            $('#btn-favorite i').attr('class',"fa fa-heart-o");
                        }
                    },
                    error: function(jqXHR, textStatus, errorThrown) {
                        console.log(jqXHR, textStatus, errorThrown);
                        $('#btn-favorite').attr('class', "atc rt btn-favorite");
                        $('#btn-favorite i').attr('class',"fa fa-heart-o");
                        
                    }
                });
            }
        }, 100);
    });

});

