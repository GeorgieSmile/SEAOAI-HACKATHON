jQuery(function($){

	// v.0.0.1
	var dev = 'v.55';
	//console.log( dev );

	var wrapIp = '.pd-url-wrap';
	var ProductID = '';

	$( wrapIp ).on( 'focusout', '.pd-url', function ( e ) {

		if( $( this ).hasClass( 'ip-alert' ) ) {
			$( this ).removeClass( 'ip-alert' ).val( '' );
		}
    });

	$( wrapIp ).on('paste', '.pd-url', function ( e ) {

			var pasteData = e.originalEvent.clipboardData.getData( 'text' );
			var hostname = $('<a>').prop('href', pasteData).prop('hostname');

			var secDomain = hostname.substring( hostname.indexOf( 'aliexpress.com' ) );

			if( secDomain == 'aliexpress.com' ) {

					$( '.pd-loading' ).fadeIn( 200 );
					$( '.pd-url' ).css({
						'background-color'	: '#f1f1f1',
						'color'				: '#ccc',
						'cursor'			: 'no-drop',
					});
					$( '.p-data, pre' ).fadeOut( 200 );

				var parts = pasteData.split('/');
				var result = parts[parts.length - 1];
				var ProductID = result.split('.html')[0];

				var data = {
					'action': 'ali_content',
					//'p_id': aliApiSettings.ss,
					'p_id': ProductID,
				};

				// Assign handlers immediately after making the request,
				// and remember the jqxhr object for this request
				//$.ajaxSetup({async: false});
				var jqxhr = $.post( aliApiSettings.ajaxurl, data, function(response) {
					
					console.log( "success 1" );
					
					//$( '.pd-loading' ).fadeIn( 200 );
					$('html, body').animate({
						scrollTop: $( '#cs-get-id' ).offset().top - 90
					}, 600);
				})
				  /*.done(function( response ) {
					console.log( ".done success" );
				  })*/
				  .fail(function( response ) {
					
					$( '#cs-get-id' ).append( response );
					$( '.csui .pd-url' ).val( '' );
					$( '.pd-url' ).removeAttr( 'style' );
					$( '.pd-loading' ).fadeOut();
					console.log( 'Fail' )
					console.log( response );
				  })
				  .always(function( response ) {
					console.log( '.always finished' );
				  });
				 
				// Perform other work here ...
				 
				// Set another completion function for the request above
				jqxhr.always(function(response) {
					console.log( 'jqxhr.always finished' );
					//console.log( response );
					//$( '.p-data, pre' ).remove();
					$( '#cs-get-id' ).append( response );
					$( '.csui .pd-url' ).val( '' );
					$( '.pd-url' ).removeAttr( 'style' );
					$( '.pd-loading' ).fadeOut();
				});
			} else {
				$( this ).addClass( 'ip-alert' ).val('Please add Aliexpress URL').trigger( 'change' );
				e.preventDefault();
			}
			//console.log( ProductID );
	});
});