jQuery(function($){
/**
 * Version 1
 * 2018/12/18 21:20
 */
console.log('SERP - Search v.1');

    var availableTags = [
        "กระโปรง",
		"ชุดเดรส",
		"ชุดลายดอกไม้",
		"ชุดชีฟอง",
		"ชุดผ้าฝ้าย",
		"ชุดเปิดไหล่",
		"ชุดลูกไม้",
		"ชุดสายเดี่ยว",
		"กางเกงขาสั้น",
		"กางเกงใส่เที่ยว",
		"กางเกงยีนส์",
		"กางเกงยีนส์ขาสั้น",
		"เสื้อเชิ้ต",
		"เสื้อยืด",
		"เสือยืดหลวมๆ",
		"เสือยืดสลิมฟิต",
		"ชุดสำหรับออกงาน",
		"ชุดแนะนำร้านคุณภาพ",
		"ชุดเที่ยวสำหรับปีใหม่",
		"เสื้อขนสัตว์",
		"ชุดนอน",
		"กางเกงใน",
		"ยกทรง",
		"ชุดชั้นใน",
		"เสื้อผ้าผู้ชาย",
		"เสื้อยืดผู้ชาย",
		"ชุดกันหนาว",
		"เสื้อกันหนาว",
		"แจ็คเก็ต",
		"เสื้อโปโล",
		"ชุดชั้นในชาย",
		"ชุดวอร์ม",
		"ชุดนอนชาย",
		"กางเกงลำลอง",
		"รองเท้า",
		"รองเท้าแตะ",
		"รองเท้าส้นสูง",
		"รองเท้าผ้าใบ",
		"รองเท้าลำลองผู้ชาย",
		"รองเท้าสำหรับใส่ทำงาน",
		"กระเป๋า",
		"กระเป๋าถือ",
		"กระเป๋าสะพาย",
		"กระเป๋า Messenger",
		"ถุงผ้า",
		"กระเป๋าสตางค์",
		"กระเป๋าวินเทจ",
		"กระเป๋าเป้",
		"กระเป๋าผู้ชาย",
		"กระเป๋าใส่ Notebook",
		"กระเป๋ากีฬา",
		"กระเป๋าเดินทาง",
		"กระเป๋าเดินทางมีล้อ",
		"เครื่องประดับ",
		"สร้อยคอ",
		"สร้อยข้อมือ",
		"ต่างหู",
		"แหวน",
		"กำไล",
		"เข็มกลัด",
		"กล่องใส่เครื่องประดับ",
		"หมวก",
		"ผ้าพันคอ",
		"หมวกชายหาด",
		"ผ้าขนสัตว์",
		"ผ้าคลุมไหล่",
		"นาฬิกา",
		"นาฬิกาสำหรับผู้หญิง",
		"นาฬิกาสำหรับผู้ชาย",
		"Smart Watch",
		"แว่นตา",
		"แว่นตาสำหรับผู้ชาย",
		"แว่นตาสำหรับผู้หญิง",
		"แว่นกันแดด",
		"แว่นตากันรังสี",
		"กล่องใส่แว่นตา",
		"ชุดสำหรับออกกำลังกาย",
		"รองเท้ากีฬา",
		"รองเท้าวิ่ง",
		"รองเท้าเดินป่า",
		"รองเท้าบาสเกตบอล",
		"เสื้อผ้าโยคะ",
		"อุปกรณ์กลางแจ้ง",
		"ไฟฉาย",
		"ถุงนอน",
		"อุปกรณ์เดินป่า",
		"อุปกรณ์ตกปลา",
		"เหยื่อตกปลา",
		"ชุดว่ายน้ำ",
		"ชุดว่ายน้ำสำหรับผู้ชาย",
		"ชุดว่ายน้ำสำหรับผู้หญิง",
		"สระว่ายน้ำ",
		"หมวกว่ายน้ำ",
		"ชุดบีกินี่",
		"ชุดว่ายน้ำเด็ก",
		"อุปกรณ์ไฟฟ้า",
		"ลู่วิ่งไฟฟ้า",
		"สกู๊ตเตอร์ไฟฟ้า",
		"จักรยานไฟฟ้า",
		"ดัมเบล",
		"เครื่องซิทอัพ",
		"เครื่องออกกำลังกาย",
		"ชุดดำน้ำ",
		"เฟอร์นิเจอร์",
		"ผ้าม่าน",
		"ผ้าห่ม",
		"ผ้าคลุมเตียง",
		"แผ่นรองพื้น",
		"หมอน",
		"พรม",
		"โซฟา",
		"ผ้าปูโต๊ะ",
		"อุปกรณ์จัดเก็บ",
		"กล่อง",
		"กล่องเครื่องประดับ",
		"ถุงขยะ",
		"ไม้แขวนเสื้อ",
		"ตะขอแขวน",
		"ของแต่งบ้าน",
		"ร่ม",
		"ผ้าขนหนู",
		"รองเท้าสำหรับใส่ในบ้าน",
		"กรอบรูป",
		"สติ๊กเกอร์ติดผนัง",
		"ลูกโป่ง",
		"แก้วน้ำ",
		"จาน",
		"ชาม",
		"ถ้วย",
		"กระบอกน้ำ",
		"แม่พิมพ์เค้ก",
		"บรรจุภัณฑ์",
		"ชั้นวางในห้องครัว",
		"โต๊ะ",
		"ตู้",
		"ตู้เสื้อผ้า",
		"ตู้รองเท้า",
		"เก้าอี้",
		"เตียง",
		"อุปกรณ์เกี่ยวกับเตียง",
		"โต๊ะกาแฟ",
		"ที่นอน",
		"กระจก",
		"โคมไฟ",
		"ไฟเพดาน",
		"หลอดไฟ",
		"โคมระย้า",
		"พัดลมโคมไฟ",
		"สปอร์ตไลท์",
		"สวิตซ์ไฟ",
		"ไฟ LED",
		"รีโมทคอนโทรล",
		"ปลั๊ก",
		"ช็อกเก็ต",
		"วัสดุตกแต่ง",
		"สี",
		"สายฉีดน้ำ",
		"วัสดุฉนวน",
		"วัสดุกันน้ำ",
		"กระเบื้อง",
		"หินอ่อนตามธรรมชาติ",
		"หินอ่อนเทียม",
		"ผนัง",
		"บอร์ดยิปซั่ม",
		"เครื่องใช้ในบ้าน",
		"โทรศัพท์บ้าน",
		"เครื่องปรับอากาศ",
		"ตู้เย็น",
		"เครื่องซักผ้า",
		"เครื่องดูดควัน",
		"เครื่องทำน้ำอุ่น",
		"ตู้แช่เย็น",
		"เครื่องอบผ้า",
		"เลเซอร์",
		"เครื่องไฟฟ้าในบ้าน",
		"อุปกรณ์เสริมโทรศัพท์",
		"สายชาร์จ",
		"หัวชาร์จ",
		"ที่ยึดมือถือ",
		"อุปกรณ์สำหรับเลนส์มือถือ",
		"อุปกรณ์เสริมสำหรับไอโฟน",
		"อุปกรณ์ ดิจิตอล",
		"อุปกรณ์สำหรับกล้อง",
		"USB คอมพิวเตอร์",
		"อุปกรณ์จัดเก็บข้อมูล",
		"อุปกรณ์เสริม คอมพิวเตอร์",
		"ไฟสตูดิโอ",
		"หูฟัง",
		"หูฟังบลูทูธ",
		"ลำโพง",
		"ไมโครโฟน",
		"เครื่องเล่น",
		"อุปกรณ์ขยายเสียง",
		"Drone",
		"VR & AR",
		"สินค้าแม่และเด็ก",
		"ของเล่นเด็ก",
		"รถบังคับ",
		"ของเล่นเสริมทักษะ",
		"ตุ๊กตา",
		"ของเล่นทายปริศนา",
		"ของเล่นกลางแจ้ง",
		"จักรยานเด็กเล่น",
		"รถไฟฟ้าเด็ก",
		"สระว่ายน้ำ",
		"เครื่องดนตรี",
		"เครื่องเขียนสำหรับเด็ก",
		"อุปกรณ์สำหรับเด็ก",
		"รองเท้าเด็ก",
		"กางเกงเด็ก",
		"ชุดสูทเด็ก",
		"ชุดน่ารักๆ สำหรับเด็ก",
		"เสื้อยืดเด็ก",
		"แจ็คเก็ต สำหรับเด็ก",
		"เสื้อสำหรับเด็ก",
		"สายรัดเสื้อ",
		"ชุดชั้นในสำหรับเด็ก",
		"อุปกรณ์เสริมสำหรับเด็ก",
		"บ้านที่นอนสำหรับเด็ก",
		"พื้นกันกระแทกสำหรับเด็ก",
		"เปลสำหรับเด็ก",
		"ผ้าคลุมเตียงเด็ก",
		"เก้าอี้เด็ก",
		"ผ้าอ้อม",
		"ผลิตภัณฑ์สำหรับอาบน้ำเด็ก",
		"อุปกรณ์ป้องกันสำหรับเด็ก",
		"อุปกณ์แรกคลอด",
		"กางเกงคนท้อง",
		"ชุดนอนคนท้อง",
		"ปั้มนม",
		"อุปกรณ์จัดงาน",
		"ปากกา",
		"คริสต์มาส",
		"ซองจดหมาย",
		"ปากกาเจล",
		"กล่องใส่ดินสอ",
		"ดินสอ",
		"โพสต์อิท",
		"ยางลบ",
		"สมุดจดบันทึก",
		"เครื่องเขียน",
		"ตลับหมึก",
		"ผงหมึก",
		"หมึกพิมพ์",
		"เครื่องพิมพ์",
		"เครื่องสแกนเนอร์",
		"เครื่องฉาย",
		"กระดาษสำนักงาน",
		"กระดาษก็อปปี้",
		"กระดาษพิมพ์งาน",
		"ของที่ระลึกงานฝีมือ",
		"งานฝีมือไม้",
		"งานหัตถกรรมโลหะ",
		"พวงกุญแจ",
		"งานฝีมือเรซิน",
		"ของที่ระลึก",
		"เครื่องประดับสไตล์ยุโรป",
		"เครื่องประดับจีน",
		"ของขวัญ",
		"หยก",
		"บรรจุภัณฑ์กระดาษ",
		"กล่อง",
		"ถุง",
		"ซอง",
		"กระดาษ",
		"กล่องกระดาษ",
		"ถุงใส่เสื้อผ้า",
		"บรรจุภัณฑ์ดอกไม้",
		"กระดาษคราฟท์",
		"กระดาษลูกฟูก",
		"กระดาษแข็ง",
		"กระดาษฟอยล์",
		"งานพิมพ์",
		"กราฟฟิค",
		"ปฎิทินตั้งโต๊ะ",
		"โปสเตอร์",
		"กระดานประชาสัมพันธ์",
		"กระดาษหนังสือพิมพ์",
		"หนังสือ",
		"กระดาษเคลือบ",
		"ฮาร์ดแวร์",
		"ลูกกลิ้ง",
		"อุปกรณ์ช่าง",
		"เครื่องมือล้างรถ",
		"เครื่องมือนิวเมติก",
		"เครื่องมือช่าง",
		"เครื่องมือช่างไฟฟ้า",
		"เครื่องจักร CNC",
		"ปั้มลม",
		"ปั้มน้ำ",
		"เครื่องฉีดพลาสติก",
		"วาล์ว",
		"จักรเย็บผ้า",
		"น็อต",
		"เกียร์",
		"สายไฟ",
		"ดอกสว่าน",
		"หมุดย้ำ",
		"อุปกรณ์เซฟตี้",
		"หน้ากากเซฟตี้",
		"รองเท้าเซฟตี้",
		"ถุงมือเซฟตี้",
		"ชุดเซฟตี้",
		"หมวกเซฟตี้",
		"ที่อุดหู",
		"อุปกรณ์ตกแต่งรถยนต์",
		"น้ำหอมรถยนต์",
		"สติ๊กเกอร์ติดรถ",
		"ม่านบังแดด",
		"หมอนอิงศีรษะ",
		"เบลท์สำหรับรถยนต์",
		"กล่องสำหรับใช้ในรถ",
		"เบาะนั่ง",
		"เบาะรถยนต์",
		"เบาะหนัง",
		"พรมในรถ",
		"สินค้าอิเล็กทรอนิกส์ในรถยนต์",
		"กล้องบันทึกหน้ารถ",
		"เครื่องนำทาง",
		"อุปกรณ์ชาร์จไฟในรถ",
		"เครื่องดูดฝุ่นในรถยนต์",
		"ยางรถยนต์",
		"ฟิล์มติดรถยนต์",
		"รถจักรยานไฟฟ้า",
		"เครื่องตรวจแรงดันลมยาง",
		"กระถาง",
    ];
	if($('#serp-search').length) {
		$('#serp-search').autocomplete({
			source: availableTags,
		});
	}

	var elmHeader = $('header#header');
	var TTpSearch = $('#serp');
	var BlockSearch = $('div.block-search ');
	var elmContent = $('#content');
	var SerpBtn = $('#serp-btn');
	var SerpCon = '';
	var SerpHere = '';
	var Filter = $('.sp-filter');
	var importerCols = $('meta[name=importer-cols]').attr('content');
	if( TTpSearch.length && BlockSearch.length ) {
		var eTTpSearch = TTpSearch.detach();
		BlockSearch.html(eTTpSearch).addClass('inline-block');
		TTpSearch.css('display','flex');
	}
	if( elmHeader.length ) {

		elmHeader.after('<div id="serp-con" class="container serp-con" style="display:none;"><div id="serp-here" class="row">SERP Here!</div></div>');
		SerpCon = $('#serp-con');
		SerpHere = $('#serp-here');
	}
	var elmSearch = $('#serp-search');
	if( elmSearch.length ) {
		$(document).on('click', '#serp-btn:not(.disabled)', function(e) {
			e.preventDefault();
			var keyWord = elmSearch.val();
			if ("taobao" == $("#serp-provider").val()){
				Filter.show(6);
				SerpBtn.prop('disabled', true);
				// SerpBtn.addClass('spinner disabled');
				// $('html, body').animate({
				// 	scrollTop: elmSearch.offset().top - 20
				// }, 600);
				$('.block-nav-category.has-vertical-menu').removeClass('alway-open');
				// SerpCon.fadeIn(280);
				// SerpHere.html('').addClass('c spinner');
				if(  ( elmSearch.val().trim() ).length > 0 ){
					console.log($.trim( elmSearch.val() ))
					if( elmSearch.val().indexOf('.com') !== -1 ){
						var ali = ctsp.get_provider_n_id( $.trim( elmSearch.val() ) );
						cso.goSingleProduct( ali.provider, ali.id );
					}else if(elmSearch.val().indexOf('e.tb.cn') !== -1){
						var ali = ctsp.get_provider_n_id( $.trim( elmSearch.val() ) );
						cso.goSingleProduct( ali.provider, ali.id );
					}
					// else {
					// 	TTPSearch_v3(elmSearch.val(),'normal');
					// }
				} else {
					// alert('Please add Keyword.');
					// SerpBtn.removeClass('spinner disabled');
					SerpBtn.prop('disabled', false);
					Filter.hide(6);
				}
			}
			$(".main-content").before('<style style="display:none">.page-main-content h2{display:none}.main-content .page-title{margin-bottom:36px}</style>');
		});

		$(document).on('click', '#serp-btn.disabled', function(e) {
			e.preventDefault();
		});
	}
	var TTpSearch = $('#ttp-search');
	if( TTpSearch.length ) {
		var Serp1			= $('.page-main-content');
		var daTaKeyword		= TTpSearch.data('keyword');
		var daTaProvider	= TTpSearch.data('provider');
		var daPage			= TTpSearch.data('page');
		
		
		
          ajaxGetSerp(daTaKeyword,daTaProvider);
		$('.main-content').before('<style style="display:none">.page-main-content h2{display:none}.main-content .page-title{margin-bottom:36px}</style>');
	}
	function ajaxGetSerp( daTaKeyword, provider ){
		localStorage.removeItem('search_order');
		localStorage.removeItem('start_price');
		localStorage.removeItem('end_price');
		localStorage.removeItem('min_qty');
		localStorage.removeItem('sort_paged');
        if ( provider == 'taobao') {
            TTPSearch_v3(daTaKeyword);
        }
        if(provider == '1688'){
            TTPSearch_v2(daTaKeyword);
        }
        $(".main-content").before('<style style="display:none">.page-main-content h2{display:none}.main-content .page-title{margin-bottom:36px}</style>');
    }
	function prepare_link_data( selectors ) {
		$( selectors ).each( function( index ) {
			$(this).addClass('ttp-product idx-'+index);
			var hef = $(this).attr('href');
			var itemID = hef.split('&itemId=').pop();
			var source = '1688';
			if(hef.indexOf('taobao') >= 0){
				source = 'taobao';
			}
			$(this).attr('data-product', source+'-'+itemID);
			$(this).attr('target', '_blank');
			var ttpHomeURL = window.location.protocol + '//' + window.location.host + '/';
			$(this).attr( 'href', ttpHomeURL + 'search?provider=' + encodeURIComponent(source) + 'itemId=' + encodeURIComponent(itemID) );
		});
	}
	function prepare_pagination_link_data( selectors, keyword, provider, page ) {
		$( selectors ).each( function( index ) {
			var hef = $(this).attr('href');
			var pageN = hef.split('&page=').pop();
			if( provider === undefined ) provider = 'taobao';
			if( page === undefined ) page = 1;
			if( page == pageN ){
				$(this).addClass('current-page');
			}
			var ttpHomeURL = window.location.protocol + '//' + window.location.host + '/';
			$(this).attr('href', ttpHomeURL + 'search?keyword=' + encodeURIComponent(keyword) + '&provider=' + encodeURIComponent(provider) + '&gopage=' + pageN);
		});
	}
	function unwrap_row(wrapper) {
		$(wrapper).find('div.row > div.product:first-child').each( function( index ) {
			$(this).unwrap();
		});
		$(wrapper).find('div.row > div.product').each( function( index ) {
			$(this).removeClass().addClass(importerCols + ' product');
		});
		$(wrapper).find('h2').wrap('<div class="container"></div>');
	}
});
on3('click', 'sort-bar-btn2', function(e){
    if( ! e.srcElement.classList.contains('active') ) {
        let keyword = localStorage.getItem('search_keyword');
        if( keyword.length ) {
            TTPSearch_v3( keyword, e.srcElement.getAttribute('data-order') );
        }
    }
});
on3('click', 'sort-go2', function(e) {
    let keyword = localStorage.getItem('search_keyword');
    if( keyword.length ) {
        TTPSearch_v3( keyword );
    }
});
on3('click', 'paged-item2', function(e) {
    e.preventDefault();
    e.srcElement.classList.add("mystyle-5566");
    let keyword = localStorage.getItem('search_keyword');
    if( keyword.length ) {
        TTPSearch_v3( keyword, null, e.srcElement.getAttribute('data-page') );
        document.querySelector('#header').scrollIntoView({
            behavior: 'smooth'
        });
    }
});
function getSearchKeyword3() {
    return localStorage.getItem('search_keyword');
}
function getSearchProvider3(wanted) {
    let e = document.getElementById('serp-provider');
    if( wanted == 'text' ) {
        return e.options[e.selectedIndex].text;
    }
    return e.options[e.selectedIndex].value;
}
function hideSearch_Old3() {
    document.getElementById('serp-con').style.display='none';
}
function TTPSearch_v3( keyword, order, paged, reset ) {
	var userText = $('header#header>.header-top>.container>span').text();
	var user_id = userText.substring(userText.indexOf(' ') + 1).replace('ttp',"");

	save_history_search(keyword, 'taobao', paged, user_id);
	
    hideSearch_Old3();
    let searchData = {};
    searchData.keyword = keyword;
    searchData.order = '';
    searchData.start_price = '';
    searchData.end_price = '';
    searchData.min_qty = '';
    searchData.sort_paged = '';
    if( ! reset ) {
        if( order ) {
            searchData.order = order;
        } else if( document.querySelector('.sort-bar-btn2.active') ) {
            searchData.order = document.querySelector('.sort-bar-btn2.active').getAttribute('data-order');
        } else if( localStorage.getItem('search_order') ) {
            searchData.order = localStorage.getItem('search_order');
        } else {
            searchData.order = 'normal';
        }
        if( paged ) {
            searchData.sort_paged = paged;
        } else if( getSearchValue3('sort-paged').length ) {
            searchData.sort_paged = getSearchValue3('sort-paged');
        } else if( localStorage.getItem('sort_paged') ) {
            searchData.sort_paged = localStorage.getItem('sort_paged');
        }
        if( getSearchValue3('start-price').length ) {
            searchData.start_price = getSearchValue3('start-price');
        } else if( localStorage.getItem('start_price') ) {
            searchData.start_price = localStorage.getItem('start_price');
        }
        if( getSearchValue3('end-price').length ) {
            searchData.end_price = getSearchValue3('end-price');
        } else if( localStorage.getItem('end_price') ) {
            searchData.end_price = localStorage.getItem('end_price');
        }
        if( getSearchValue3('min-qty').length ) {
            searchData.min_qty = getSearchValue3('min-qty');
        } else if( localStorage.getItem('min_qty') ) {
            searchData.min_qty = localStorage.getItem('min_qty');
        }
    }
    localStorage.setItem('search_order', searchData.order);
    localStorage.setItem('start_price', searchData.start_price);
    localStorage.setItem('end_price', searchData.end_price);
    localStorage.setItem('min_qty', searchData.min_qty);
    localStorage.setItem('sort_paged', searchData.sort_paged);
    searchLoading3( keyword );
    asyncGetSearch3( searchData );
}
function getSearchValue3( class_name ) {
    let t = document.getElementsByClassName( class_name );
    if( t[0] ) {
        return t[0].value.trim();
    } else {
        return '';
    }
}
async function asyncGetSearch3( searchData ) {
    const form = new FormData();
    form.append('action', 'ttp_search_v3');
    form.append('keyword', searchData.keyword);
    form.append('order', searchData.order);
    form.append('start_price', searchData.start_price);
    form.append('end_price', searchData.end_price);
    form.append('quantity_begin', searchData.min_qty);
    form.append('paged', searchData.sort_paged);
    form.append('start', ttpGetTime3());
    const params = new URLSearchParams(form);
    const response = await fetch(ttp2.ajaxurl,{
        method: 'POST',
        credentials: 'same-origin',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
            'Cache-Control': 'no-cache'
        },
        body: params
    });


    if (response.ok) { 
        let opt = {
            keyword: searchData.keyword,
            order: searchData.order,
            start_price: searchData.start_price,
            end_price: searchData.end_price,
            quantity_begin: searchData.min_qty,
            paged: searchData.sort_paged
        };
        let json = await response.json();
		
        generateSearchTemplate3(json.data, opt);
        localStorage.setItem('search_keyword', searchData.keyword);
    } else {
        console.log("HTTP-Error: " + response.status);
    }
}
function generateSearchTemplate3(data, opt) {
    let html = '';
    if( data && data.length ) {
        html += ' <i class="fa fa-close" onclick="filter_close2()" style="font-size:36px;display:none"></i>';
        html += '<div class="f-rung">';
        html += '<i class="fa fa-filter" onclick="filter_click2()"></i>';
        html += '</div>';
        html += '<div id="ttp-sort-bar2" class="sort-bar sort-bar-taobao sort-bar-provider-2">';
            html += '<span>' + ttp2.translate.sort_by + '</span>';
            let active = '';
            if( opt.order == 'normal' ) active = ' active';
            html += '<button type="button" class="btn btn-default sort-bar-btn2' + active + '" data-order="normal">' + ttp2.translate.related + '</button>';
            active = '';
            if( opt.order == 'va_rmdarkgmv30rt' ) active = ' active';
            html += '<button type="button" class="btn btn-default sort-bar-btn2' + active + '" data-order="va_rmdarkgmv30rt">' + ttp2.translate.turnover + '</button>';
            active = '';
            if( opt.order == 'price-asc' ) active = ' active';
            html += '<button type="button" class="btn btn-default sort-bar-btn2' + active + '" data-order="price-asc">' + ttp2.translate.price_asc + '</button>';
            active = '';
            if( opt.order == 'price-desc' ) active = ' active';
            html += '<button type="button" class="btn btn-default sort-bar-btn2' + active + '" data-order="price-desc">' + ttp2.translate.price_desc + '</button>';
            html += '<div class="group-field ml-1"><span>ช่วงราคา </span>';
            html += '<input type="number" class="x-price start-price text-center" placeholder="น้อยสุด" value="' + localStorage.getItem('start_price') + '">';
            html += ' <strong>-</strong> ';
            html += '<input type="number" class="x-price end-price text-center" placeholder="มากสุด" value="' + localStorage.getItem('end_price') + '">';
            html += '<button type="button" class="sort-go2 btn btn-default" data-type="x-price">ตกลง</button>';
            html += '</div>';
            html += '<div class="group-field ml-1"><span>จำนวนสินค้า </span>';
            html += '<input type="number" class="min-qty text-center" placeholder="น้อยสุด" value="' + localStorage.getItem('min_qty') + '">';
            html += '<button type="button" class="sort-go2 btn btn-default" data-type="min-qty">ตกลง</button>';
            html += '</div>';
            html += '<div class="group-field float-r">';
            html += '<span>หน้า </span> ';
            html += '<input type="number" class="sort-paged text-center" placeholder="" value="' + localStorage.getItem('sort_paged') + '">';
            html += '<button type="button" class="sort-go2 btn btn-default" data-type="paged">ตกลง</button>';
            html += '</div>';
        html += '</div>';
        html += '<div class="row" style="margin-top:16px;">';
        let i = 0;
		// console.log(data);
        data.forEach(function (product, index) {
            i++;
            if(i <= 42){
				
                // console.log(i);
            html += '<section class="item col-xs-6 col-sm-4 col-lg-2">';
            html += '<a href="'+window.location.origin+'/product?provider=taobao&itemId=' + product.id + '" target="_blank">';
            html += '<div class="product">';
            html += '<div class="p-top">';
            let imageUrl = product.imageUrls;

			imageUrl = imageUrl.replace(/\.(jpg|png|webp).*$/, '.$1');
			imageUrl += '_270x270xzq60.jpg';

			html += '<img src="' + imageUrl + '" alt="">';

            html += '<div class="txt-view-product text-center">' + ttp2.translate.view_product + '</div>';
            html += '</div>';
            html += '<div class="price-rang">';
                if( product.prices.length ) {
                    product.prices.forEach(function (price, index) {
                        html += '<div class="price-item">';
                            html += '<div class="price f14 fw4"><span class="f11 clr-7">&#165;</span>' + price.price.replace(/\.00/g, '') + '</div>';
                            html += '<div class="rang f11">' + price.price_rang + '</div>';
                        html += '</div>';
                    });
                } else {
                    html += '<div class="price-item">' + product.price + '</div>';
                }
            html += '</div>';
            html += '<h2 class="search-title px-2 pb-0 my-2">' + product.title + '</h2>';
			html += '<div class="shop-name p-2 pt-0 pb-0 f10">' + (product.seller == null || product.seller == "null")? '': product.seller; + '</div>';
            html += '<div class="price-con p-2 pt-0">';
            html += '<span class="f11 clr-7">&#165;</span> ';
            html += '<span class="">' + (product.price.toString()).replace(/\.00/g, '') + '</span>';
            html += '</div>';
            html += '</div>';
            html += '</a>';
            html += '</section>';
        }
        });
        html += '</div>';
        html += htmlPaged3(opt, data);
    } else {
		html += '<div class="text-center" style="padding:60px 0;">';
			html += '<p class="kwnotfound"><img src="'+window.location.origin+'/wp-content/uploads/2022/04/keywordnotfound.png" width="40%"></p>';
			html += '<p>ขณะนี้มีผู้เข้าชมหน้านี้จำนวนมาก กรุณาลองค้นหาใหม่อีกครั้ง</p>';
			html += '<a href="'+window.location.origin+'/search?provider=taobao&keyword=' + opt.keyword + '" class="btn_or">ค้นหาอีกครั้งด้วย taobao</a>';
			html += '<a href="'+window.location.origin+'/search?provider=1688&keyword=' + opt.keyword + '" class="btn_or">ค้นหาอีกครั้งด้วย 1688</a>';
		html += "</div>";
		recommend(20);
    }
    document.getElementById('search-list-container').innerHTML = html;
	setSearchPageTitle(opt?.keyword || localStorage.getItem("search_keyword") || "", (getSearchProvider3?.() || "taobao"));
    document.querySelector('#serp-btn').classList.remove('spinner', 'processing');
}

// function setSearchPageTitle(keyword, provider = 'taobao') {
//   const elTitle = document.querySelector('title');
//   const nowTitle = elTitle?.textContent || document.title || '';

//   const sp = nowTitle.split(' | ').map(s => s.trim()).filter(Boolean);
//   const suffix = sp.length > 1 ? sp.slice(1).join(' | ') : (nowTitle.trim() || 'TTPCARGO');

//   const kw = (keyword || '').trim();
//   const left = kw ? `Search ${provider.toUpperCase()}: ${kw}` : `Search ${provider.toUpperCase()}`;

//   const newTitle = suffix ? `${left} | ${suffix}` : left;

//   if (elTitle) elTitle.textContent = newTitle;
//   document.title = newTitle;
// }


function htmlPaged3(opt) {
    let html = '<nav class="pagination-con" aria-label="Page navigation">';
    html += '<ul class="pagination ttp_paged text-center">';

    let pageNum = (opt.paged === "" || opt.paged === undefined) ? 1 : parseInt(opt.paged);
    let maxPage = 99; // ตันสุด 99

    // รอบ ๆ หน้า current ±9
    let minNum = (pageNum - 5 < 1) ? 1 : pageNum - 5;
    let maxNum = (pageNum + 5 > maxPage) ? maxPage : pageNum + 5;

    // แสดงหน้าแรกถ้าจำเป็น
    if (minNum > 1) {
        html += '<li><a href="#" class="paged-item2 testlo" data-page="1">1</a></li>';
        // ถ้าเลข 1 ไม่ติด minNum ให้มี ...
        if (minNum > 2) {
            html += '<li><a class="at-item">...</a></li>';
        }
    }

    // แสดงหน้ากลาง
    for (let i = minNum; i <= maxNum; i++) {
        let active = '';
        let link = '<a href="#" class="paged-item2 testlo" data-page="' + i + '">' + i + '</a>';
        if (pageNum === i) {
            active = ' class="active"';
            link = '<span class="at-item">' + i + '</span>';
        }
        html += '<li' + active + '>' + link + '</li>';
    }

    // แสดง ... ถ้าช่วงสุดท้ายไม่ติดกับ maxPage
    if (maxNum < maxPage - 1) {
        html += '<li><a class="at-item">...</a></li>';
    }

    // แสดงหน้าสุดท้ายถ้าจำเป็น
    if (maxNum < maxPage) {
        html += '<li><a href="#" class="paged-item2 testlo" data-page="' + maxPage + '">' + maxPage + '</a></li>';
    }

    html += '</ul>';
    html += '</nav>';
    return html;
}



function on3(eventType, targetClass, callback) {
    jQuery(document).ready(eventType, function (event)  {
        if (event.target.classList.contains(targetClass)) {
            callback(event);
        }
    });
}
function searchLoading3( keyword ) {
    let html = '';
        html += '<div class="text-center" style="padding: 64px 0 32px 0">';
        html += '<div id="do-search-v3x" class="do-search-v3x" data-keyword="' + keyword + '">';
        html += '<span>กำลังค้นหา</span> ';
        html += '<span style="font-weight:600;">' + keyword + '</span> '
        html += '</div>';
        html += '<div class="spinner2">';
        html += '<div class="loadicon"></div>';
        html += '</div>';
        html += '</div>';
    let searchCon = document.getElementById('search-list-container');
    searchCon.classList.remove('d-none');
    searchCon.innerHTML = html;
}
function setSearchContainer3(id) {
    let target = document.getElementById('header');
    let searchElm = document.createElement('div');    
    let searchElm2 = document.createElement('div');   

	searchElm2.id= "recommend-list-container";
    searchElm2.className= "container";
    target.parentNode.insertBefore(searchElm2, target.nextSibling);

	searchElm.id= "search-list-container";
    searchElm.className= "search-v3 product-container container d-none";
    target.parentNode.insertBefore(searchElm, target.nextSibling);
}
async function asyncGetJSON_P3(endpoint) {
    let user = {
        apikey: '',
        keyword: 'shirt'
      };
      let url = endpoint;
      let response = await fetch(url, {
        method: 'GET',
        credentials: 'include',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        }
      });
    if (response.ok) {
        let json = await response.json();
    } else {
        console.log("HTTP-Error: " + response.status);
    }
}
async function asyncGetJSON3( type, x_url ) {
        const url = '-';
        const response = await fetch(url,{
            method: 'POST',
            mode: 'cors',
            credentials: 'omit',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'Cache-Control': 'no-cache'
            }
        });
        if (response.ok) {
            let json = await response.json();
        } else {
            console.log("HTTP-Error: ");
        }
}
function loadJSON3(callback) {   
    let url = '-';
    var xobj = new XMLHttpRequest();
    xobj.open('GET', url, true);
    xobj.setOption(2, 13056);
    xobj.setRequestHeader( 'Content-Type', 'application/x-www-form-urlencoded; charset=UTF-8' );
    xobj.overrideMimeType( 'application/json' );
    xobj.responseType = 'json';
    xobj.onreadystatechange = function () {
          if (xobj.readyState == 4 && xobj.status == "200") {
            callback(xobj.responseText);
          }
    };
    let params = 'apikey=55&keyword=shirt';
    params = '';
    xobj.send(params);
 }
function TTPSearch_v4( opt ) {
    var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            console.log(this.response);
        }
    };
    xhr.ontimeout = function (e) {
        console.log('Timeout');
    };
    xhr.open( 'POST', ttp2.ajaxurl, true);
    xhr.timeout = 20000;
    xhr.setRequestHeader( 'Content-Type', 'application/x-www-form-urlencoded; charset=UTF-8' );
    xhr.overrideMimeType( 'application/json' );
    xhr.responseType = 'json';
    xhr.onerror = function() {
        console.log(this.response);
    };
    let start = 'v3 ' + ttpGetTime3();
    let keyword = encodeURIComponent( opt.keyword );
    let params = 'action=ttp_search_v3&keyword=' + opt.keyword;
    xhr.send(params);
}
function ttpGetTime3() {
    let d = new Date();
    return d.getHours() + ':' + d.getMinutes() + ':' + d.getSeconds();
}
function ttpActiveMiniCart3() {
    let cart = JSON.parse( localStorage.getItem('ali_cart') );
    if(cart) {
        console.log('has cart');
    } else {
        console.log('empty cart');
    }
}
function ttpUpdateMiniCart3(cart) {
    let h = '';
    if( cart.skus.length ) {
        for (let i = 0; i < cart.skus.length; i++) {
            h += '<div>' + cart.skus[i].skuMap + '</div>';
        }
    }
    let el_MiniCart = document.getElementsByClassName('shopcart-description');
    for(let i = 0; i < el_MiniCart.length; i++) {
        el_MiniCart[i].innerText = h;
    }
}
(function($) {
    var ChokStudio_TTP_SERP;
    ChokStudio_TTP_SERP = {
		get_provider_n_id : async function (data) {
            // console.log(data);
			var out = {};
			var a = document.createElement('a');
			a.href = data;
			var nameSplit = a.hostname.split('.');
            if( nameSplit.length > 3 ){
                out['provider'] = nameSplit[2];
            }
			else if( nameSplit.length > 2 ){
				out['provider'] = nameSplit[1];
			} else {
				out['provider'] = nameSplit[0];
			}

			if( data.includes('qr.1688.com')){
				console.log(data.includes('qr.1688.com'), data);
				if(data.includes('：')){
					let textD = data.split("qr.1688.com");
					let textD1 = textD[0].split("：");
					let textD2 = textD[1].split(" ");
					let textUrl = textD1[textD1.length-1]+'qr.1688.com'+textD2[0]
					data = textUrl;
				}
                out['provider'] = '1688';

                let split_url = 'https://qr.1688.com/'+ data.split('qr.1688.com/')[1].split(' ')[0];
				// console.log('qr split_url : ', split_url, 'provider : ', out['provider']);

                out['id'] = await getIdFromShortLink(split_url, '1688');
				console.log(out['id']);
                
			}else if( data.includes('e.tb.cn')){
 
                 out['provider'] = 'taobao';
 
                 let split_url = 'https://e.tb.cn'+ data.split('e.tb.cn')[1].split(' ')[0];
                 console.log('taobao split_url : ', split_url, 'provider : ', out['provider']);
 
                 out['id'] = await getIdFromShortLink(split_url, 'taobao');
                 
            }else if( data.includes('m.tb.cn')){
 
                 out['provider'] = 'taobao';
 
                 let split_url = 'https://m.tb.cn/'+ data.split('m.tb.cn/')[1].split(' ')[0];
                 console.log('taobao split_url : ', split_url, 'provider : ', out['provider']);
 
                 out['id'] = await getIdFromShortLink(split_url, 'taobao');
                 
            }

             else if( out['provider'] == 'taobao'){
				var pvid;
				pvid = data.includes('&id=');
				console.log(data)
				if(pvid == false){
					if(data.includes("itemIds")){
						out['id'] = data.split('itemIds=')[1].split('&')[0];
					}else{
						out['id'] = data.split('id=')[1].split('&')[0];
					}
      			}
      			else{
        			out['id'] = data.split('&id=')[1].split('&')[0];
      				}
			 }
			 else if (out['provider'] == 'tmall') {
				if(data.includes("&id=")){
					let idArray = data.split('&id=');
					out['id'] = idArray[1].split('&')[0];
				}else if(data.includes(".htm?id=")){
					let idArray = data.split('.htm?id=');
					out['id'] = idArray[1].split('&')[0];
				}else{
					let idArray = data.split('id=');
					if (idArray.length > 2) {
						out['id'] = idArray[3].split('&')[0];
					} else {
						out['id'] = idArray[1].split('&')[0];
					}
				}
			}			
			//  else if( out['provider'] == 'tmall' ){
			// 	 out['id'] = data.split('id=')[1].split('&')[0];
			//  }
			  else if( out['provider'] == '1688' ){if (data.includes('offerId=')) {
				out['id'] = data.split('offerId=')[1].split('&')[0];
			} else {
				out['id'] = data.split('.com/offer/')[1].split('.html')[0];
			}
			 } else {
				 out['id'] = '';
			 }
			return out;
		}
	};
	window.ctsp = ChokStudio_TTP_SERP;
}(jQuery));
function filter_click2() {
        jQuery('div#ttp-sort-bar2').addClass("rung-menu");
        jQuery('.body-overlay').css({"opacity" : '555',"visibility":'inherit'});
        jQuery('div#ttp-sort-bar2.rung-menu').animate({"margin-right": '+=400'});
        jQuery('.sort-bar').css({"display" : 'table'});
        jQuery('i.fa.fa-close').css({"display" : ''});
        jQuery('.group-field').css({"position" : 'initial'});
        jQuery('.sort-bar .group-field').attr("style", "display: inline-table  !important");
 jQuery('button.btn.btn-default').click(function() {
       jQuery('.body-overlay').css({"opacity" : '777',"visibility":'hidden'});
 });
}
function filter_close2() { 
    jQuery('div#ttp-sort-bar2.rung-menu').animate({"margin-right": '-=400'});
    jQuery('i.fa.fa-close').css({"display" : 'none'});
    jQuery('.group-field').css({"position" : 'absolute'});
    jQuery('.body-overlay').css({"opacity" : '777',"visibility":'hidden'});
    jQuery('.sort-bar .group-field').attr("style", "display: none  !important");
    setTimeout(function() {
    jQuery('.sort-bar').css({"display" : 'flex'},500);  
    jQuery('div#ttp-sort-bar2').removeClass("rung-menu");
    },400);
}

function recommend(limit) {
    var urlAPI = window.location.origin;
    $.ajax({
        url: urlAPI+"/api/recommend_product.php",
        global: false,
        type: 'get',
        cache: false,
        dataType: 'json',
        data: {
            limit: limit,
        },
        success: function(response) {
            let d = '';
            if(response.status == true){
                d += '<h3 class="b-custom-headding"><span class="b-title">สินค้าที่คุณอาจถูกใจ</span></h3>';
                d += '<ul class="wp-block-gallery columns-5 q-'+limit+'">';
                    $.each(response.recommend, function (key, value){
                        d += '<li class="blocks-gallery-item">';
                            d += '<a href="'+urlAPI+'/product?provider='+value["provider"]+'&itemId='+value["product_id"]+'" target="_blank">';
                                d += '<figure class="">';
                                    d += '<img alt="" data-id="'+value["object_id"]+'" class="wp-image-'+value["object_id"]+' lazy" src="'+value["img_medium"]+'" style="display: block;">';
                                d += '</figure>';
                                d += '<h4 class="ali-title">'+value["post_title"]+'</h4>';
                                d += '<div class="group-price">';
                                    d += '<span class="price ttp-price ttp-list-price">฿ '+value["price"]+'</span>';
                                d += '</div>';
                            d += '</a>';
                        d += '</li>';
                    });
                d += '</ul>';
            }
            $('#recommend-list-container').html(d);
        },
        error: function(jqXHR, textStatus, errorThrown) {
            // console.log(jqXHR, textStatus, errorThrown);
        }
    });
}

function save_history_search(keyword, provider, page = 1, user_id) {
    var urlAPI = window.location.origin;

    $.ajax({
        url: urlAPI+"/api/save_search_history.php",
        global: false,
        type: 'post',
        cache: false,
        dataType: 'json',
        data: {
            keyword: keyword,
            provider: provider,
			page: page,
            user_id: user_id,
        }
    });
}

async function getIdFromShortLink(data_url, provider) {
    
    let url_curl = 'https://taobao.ttpcargo.com/api/call_curl.php';
    let itemId = '';
    await jQuery.ajax({
        url: url_curl,
        global: false,
        type: 'post',
        cache: false,
        data: {
            url: data_url,
            provider: provider
        },
        success: function(response) {
            console.log("data response : ", response);
            itemId = response;
        },
        error: function(jqXHR, textStatus, errorThrown) {
            console.log(jqXHR, textStatus, errorThrown);
        }
    });

    return itemId;
}
jQuery(function ($) {
    const params = new URLSearchParams(window.location.search);
    const img = params.get("urlimg") || params.get("urlimgurl") || params.get("urlimgcode");
    const page = params.get("page") || 1;

    const ajaxUrl =
        (typeof ttp !== "undefined" && ttp.ajaxurl)
            ? ttp.ajaxurl
            : "/wp-admin/admin-ajax.php";

    let $box = $("#search-results");

    if (!$box.length) {
        $box = $(".product-container").first();
    }

    function renderLoading() {
        $box
            .removeClass("d-none")
            .addClass("search-v3 container")
            .html('<div class="text-center" style="padding:60px 0;">กำลังค้นหารูป...</div>');
    }

    function sendImageSearch(formData) {
        renderLoading();

        $.ajax({
            url: ajaxUrl,
            type: "POST",
            data: formData,
            processData: false,
            contentType: false,
            success: function (response) {
                console.log("IMG RESPONSE", response);

                $box
                    .removeClass("d-none")
                    .addClass("search-v3 container")
                    .html(response);

                $(".spinner2").hide();
            },
            error: function (xhr) {
                console.log("IMG AJAX ERROR", xhr.responseText);

                $box.html('<p class="text-center">โหลดผลการค้นหาไม่สำเร็จ กรุณาลองใหม่</p>');
                $(".spinner2").hide();
            }
        });
    }

    if (img) {
        console.log("IMG SEARCH FROM URL", img);

        let formData = new FormData();
        formData.append("action", "ttp_search_imgs2");
        formData.append("page", page);
        formData.append("imgs_url", img);

        sendImageSearch(formData);
    }

    $(document).on("change", 'input[type="file"][name="imgs"], #imgs', function () {
        const file = this.files && this.files[0];

        if (!file) return;

        console.log("IMG SEARCH FROM FILE", file.name, file.size, file.type);

        let formData = new FormData();
        formData.append("action", "ttp_search_imgs2");
        formData.append("page", 1);
        formData.append("imgs", file);

        sendImageSearch(formData);
    });
});
