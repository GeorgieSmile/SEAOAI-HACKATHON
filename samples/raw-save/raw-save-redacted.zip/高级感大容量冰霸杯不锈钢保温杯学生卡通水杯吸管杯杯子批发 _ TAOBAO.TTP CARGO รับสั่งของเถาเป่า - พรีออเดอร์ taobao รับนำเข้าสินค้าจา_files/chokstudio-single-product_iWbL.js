jQuery(function ($) {

	/**
	 * Version 1.0.4
	 * 2018/12/18 22:00
	 */

	$(document).on('load', 'iframe', function () {
		this.style.height = this.contentWindow.document.body.offsetHeight + 'px';
	});
	var TTpProduct = $('#ttp-product');
	var ttpDataProvider = '';
	var ttpDataItemID = '';
	if (TTpProduct.length) {
		ttpDataProvider = String(TTpProduct.data('provider') || '').toLowerCase();
		ttpDataItemID = TTpProduct.data('itemid');
		if (ttpDataProvider != '' && ttpDataItemID != '') {
			ajaxGetSingle(ttpDataProvider, ttpDataItemID);
		}
	}
	function ajaxGetSingle(ttpProvider, pID) {
		ttpProvider = String(ttpProvider || '').toLowerCase();
		let c_cart_ajax = user_cart ? JSON.stringify(user_cart) : '';
		let user_data_ajax = user_data ? JSON.stringify(user_data) : '';
		let userrole_ajax = $('#ttp-product').data('userrole');
		let yuanrate_ajax = $('#ttp-product').data('yuanrate');
		let useremail_ajax = $('#ttp-product').data('useremail');
		var data = {
			'action': 'ttp_get_single',
			'ttp_provider': ttpProvider,
			'ttp_itemid': pID,
			'u_ip': ajax_object_gsingle.u_ip,
			'c_cart': c_cart_ajax,
			'user_data': user_data_ajax,
			'useremail': useremail_ajax,
			'userrole': userrole_ajax,
			'yuanrate': yuanrate_ajax
		};

		var jqxhr6 = '';
		if (parseInt(ttpProvider) == 1688) {
			// if(useremail_ajax == "redacted@example.invalid"){
			// 	// // var data = {
			// 	// // 	'itemId': ajax_object_gsingle.u_ip,
			// 	// // 	'user_id': pID,
			// 	// // };

			// 	// // console.log(data)

			// 	// jqxhr6 = $.ajax({
			// 	// 	url: "https://lpsadceril.execute-api.ap-southeast-2.amazonaws.com/default/1688Mobile?itemId="+ajax_object_gsingle.u_ip+"&user_id="+pID,
			// 	// 	type: "GET",

			// 	// 	success: function (response, textStatus, jqXHR) {
			// 	// 		console.log("✅ Success!");
			// 	// 		console.log("Response:", response);
			// 	// 		console.log("Status:", textStatus);
			// 	// 		console.log("Full jqXHR:", jqXHR);
			// 	// 	},

			// 	// 	error: function (jqXHR, textStatus, errorThrown) {
			// 	// 		console.log(jqXHR)
			// 	// 		console.error("❌ Error occurred!");
			// 	// 		console.error("Status:", textStatus); 
			// 	// 		console.error("Error Thrown:", errorThrown); 
			// 	// 		console.error("Response Text:", jqXHR.responseText);
			// 	// 		console.error("HTTP Status Code:", jqXHR.status);
			// 	// 	}
			// 	// });

			// 	// setTimeout(() => {

			// 	// }, 10000);
			// 	jqxhr6 = $.ajax({
			// 		url: "https://8gztswndy7.execute-api.ap-southeast-2.amazonaws.com/itemDetail1688/ttpcargoAPI",
			// 		type: "POST",
			// 		contentType: "application/json",
			// 		data: JSON.stringify(data),
			// 		success: function (response) {
			// 		},
			// 		error: function () {
			// 			location.reload();
			// 		}
			// 	});
			// }else{
			jqxhr6 = $.ajax({
				url: "https://8gztswndy7.execute-api.ap-southeast-2.amazonaws.com/itemDetail1688/ttpcargoAPI",
				type: "POST",
				contentType: "application/json",
				data: JSON.stringify(data),
				success: function (response) {
				},
				error: function () {
					location.reload();
				}
			});
			// }
		} else {
			// if(useremail_ajax == "redacted@example.invalid" || useremail_ajax == "redacted@example.invalid" || useremail_ajax == "redacted@example.invalid" || useremail_ajax == "redacted@example.invalid" || useremail_ajax == "redacted@example.invalid" || useremail_ajax == "redacted@example.invalid" || useremail_ajax == "redacted@example.invalid"){
			// console.log("https://9b6mppzpzk.execute-api.ap-southeast-2.amazonaws.com/default/itemDetailTaobao_99API")
			jqxhr6 = $.ajax({
				url: "https://9b6mppzpzk.execute-api.ap-southeast-2.amazonaws.com/default/itemDetailTaobao_99API",
				type: "POST",
				contentType: "application/json",
				data: JSON.stringify(data),
				success: function (response) {
				},
				error: function () {
					location.reload();
				}
			});
			// }else{
			// 	jqxhr6 = $.post(ajax_object_gsingle.ajax_url_gsingle, data, function (response) { }).fail(function () { });
			// }
		}
		jqxhr6.always(function (response) {


			if (pID != '582105292284xx') {
				$('h2.page-title').remove();
				$('#ttp-product').removeClass('spinner');
				$('#ttp-product').html(response);
				var csslider = tns({
					container: '.ttp-slider',
					items: 1,
					slideBy: 1,
					mouseDrag: true,
					lazyload: true,
					speed: 400,
					controls: false,
					//autoplay: true,
					autoplayPosition: 'bottom',
					autoplayButtonOutput: false,
					nav: true,
					navContainer: '.ttp-thumbnails',
					navAsThumbnails: true,
					lazyloadSelector: 'ttp-lazy-img',
					//viewportMax: true,
					autoplayHoverPause: true,
				});
				$('#ttp-product').attr(
					'data-provider',
					String($('#ttp-product').data('provider') || '').toLowerCase()
				);

				ttpProduct.start();
				function goToNextSlide() {
					csslider.goTo('next');
					$('#selected-img').addClass('d-none');
				}

				function goToPrevSlide() {
					csslider.goTo('prev');
					$('#selected-img').addClass('d-none');
				}
				document.getElementById('next-button').addEventListener('click', goToNextSlide);
				document.getElementById('prev-button').addEventListener('click', goToPrevSlide);
			} else {
				var rps = $(response);
				/**
				 * Remove iframe from product description
				 */
				//rps.find('.accordion-content.page-content iframe').remove();
				rps = cso.GenGlly(rps);
				var Result = rps.find('section.main-content').html();
				TTpProduct.html(Result).removeClass('spinner');
				$('h2.page-title').remove();
				$('.glly').trigger("update");
				$('.glly').magnificPopup({
					delegate: 'a',
					type: 'image',

					mainClass: 'mfp-with-zoom', // this class is for CSS animation below

					zoom: {
						enabled: true, // By default it's false, so don't forget to enable it

						duration: 300, // duration of the effect, in milliseconds
						easing: 'ease-in-out', // CSS transition easing function

						// The "opener" function should return the element from which popup will be zoomed in
						// and to which popup will be scaled down
						// By defailt it looks for an image tag:
						opener: function (openerElement) {
							// openerElement is the element on which popup was initialized, in this case its <a> tag
							// you don't need to add "opener" option if this code matches your needs, it's defailt one.
							return openerElement.is('img') ? openerElement : openerElement.find('img');
						}
					},
					gallery: {
						enabled: true, // set to true to enable gallery
						preload: [0, 2], // read about this option in next Lazy-loading section
						navigateByImgClick: true,
						arrowMarkup: '<button title="%title%" type="button" class="mfp-arrow mfp-arrow-%dir%"></button>', // markup of an arrow button
						tPrev: 'Previous (Left arrow key)', // title for left button
						tNext: 'Next (Right arrow key)', // title for right button
						tCounter: '<span class="mfp-counter">%curr% of %total%</span>' // markup of counter
					},
					callbacks: {
						open: function () {
						}
					}
				});
				cso.setVariable();
				cso.setCartButton();
				/**
				 * Translate
				 */
				var lang_elm = $('.cgt').first().detach();
				$('.product-single-info h2').after(lang_elm);
				//cgt.translateList( cgt.getCookie('cgt-lang') ); // th
			}
			cgt.translate();
		});
	}
	var GroupSingle = $('.ttp-single');
	if (GroupSingle.length) {
		$('.page-main-content').addClass('wp-block-gallery columns-6');
		GroupSingle.each(function (index) {
			var Eid = $(this).attr('id', 'itm-' + index);
			ajaxGetSingleMini(Eid, $(this).data('provider'), $(this).data('itemid'));
		});
	}
	function ajaxGetSingleMini(Elm, ttpProvider, pID) {
		var data = {
			'action': 'ttp_get_single',
			'ttp_provider': ttpProvider,
			'ttp_itemid': pID,
		};
		var jqxhr = $.post(ajax_object_gsingle.ajax_url_gsingle, data, function (response) { }).fail(function () { });
		jqxhr.always(function (response) {
			var eImgUrl = $(response).find('a.fullscreen-button').first().attr('href');
			Elm.find('.ttp-thumbnail').attr('src', eImgUrl);
			var eTitle = $(response).find('.product-single-info h2').text();
			Elm.find('.product-title').text(eTitle);
			var ePrice = $(response).find('span.price').html();
			Elm.find('.price').html(ePrice);
		});
	}
});
(function ($) {
	$.fn.iframe_to_div = function (options) {
		var $context = $(this);
		var settings = $.extend({
			'loading': 'Loading content...'
		}, options);
		if (!$context.is('iframe')) {
			$context = $context.find('iframe:not(.iframe-to-div-processed)')
		}
		else if ($context.hasClass('iframe-to-div-processed')) {
			return $(this);
		}
		$context.each(function () {
			var $iframe = $(this);
			var $loading = false;
			if (settings.loading) {
				$loading = $('<div><div class="inner">' + settings.loading + '</div></div>');
				$iframe.after($loading.addClass('iframe-to-div-loading'));
			}
			$iframe.hide();
			var src = $iframe.attr('src');
			$.get(src, function (data) {
				$iframe
					.addClass('iframe-to-div-processed')
					.replaceWith(data)
				$loading.remove();
			});
		});
		return $(this);
	};
})(jQuery);
(function ($) {
	var ttpProductFunction;
	ttpProductFunction = {
		start: function () {
			ttpProduct.setQtyInCart();
			ttpProduct.Checked_DefaultAttr();
			ttpProduct.Update_price();
			ttpProduct.AttrQtyChange_Update_price();
			ttpProduct.QtyKeyUp_Update_PriceStep();
			ttpProduct.SignInLink();
			ttpProduct.OpenAdminArray();

			$('button[data-type="add-to-cart"]').on('click', function (e) {
				e.preventDefault();
				var numItems = $('#header .ttp-mini-cart .mc-line').length;
				console.log(numItems);
				// Check disabled
				if (!$(this).hasClass('disabled')) {
					// if($('#cart-product-count').attr('value') <= 50 ){
					console.log(screen.width);
					if (numItems < 50) {
						// $(this).prop('disabled', true).addClass('spinner');
						ttpProduct.AddToCart();
					} else {
						alert('ไม่สามารถเพิ่มจำนวนรายการได้ เนื่องจากรายการสินค้าเกิน 50 รายการ โปรดทำการสั่งซื้อเพิ่มเติมในออเดอร์ถัดไป');
					}
					// Add to cart

				} else {
					// Alert: Disabled ..!
					alert('สินค้าหมด.');
				}
			});

			$('button.plus').on('click', function (e) {
				let current_val = parseInt($('input#qty').val(), 10);
				let beginAmount = parseInt(AliProductInfo.beginAmount, 10);
				let mixAmount = parseInt(AliProductInfo.mixAmount, 10);
				if (!beginAmount) {
					beginAmount = 1;
				}
				if (mixAmount == beginAmount) {
					beginAmount = 1;
				}
				let qty_in_cart = 0;
				if ($('[data-qty-in-cart]').length) {
					qty_in_cart = parseInt($('[data-qty-in-cart]').data('qty-in-cart'), 10);
				}

				let min_qty = parseInt($('[data-min-qty]').data('min-qty'), 10);
				let all_qty = current_val + beginAmount + qty_in_cart;
				let qty = current_val + beginAmount;
				if (all_qty < min_qty) qty = min_qty;
				$('input#qty').val(qty).trigger('change');
				ttpProduct.set_Price(qty);
			});
			$('button.minute').on('click', function (e) {
				let current_val = parseInt($('input#qty').val(), 10);
				let beginAmount = parseInt(AliProductInfo.beginAmount, 10);
				let mixAmount = parseInt(AliProductInfo.mixAmount, 10);
				if (!beginAmount) {
					beginAmount = 1;
				}
				if (mixAmount == beginAmount) {
					beginAmount = 1;
				}
				let qty_in_cart = 0;
				if ($('[data-qty-in-cart]').length) {
					qty_in_cart = parseInt($('[data-qty-in-cart]').data('qty-in-cart'), 10);
				}
				let min_qty = parseInt($('[data-min-qty]').data('min-qty'), 10);
				let all_qty = current_val - beginAmount + qty_in_cart;
				let qty = current_val - beginAmount;
				if (all_qty < min_qty) qty = min_qty;
				if (qty < 1) qty = 1;
				$('input#qty').val(qty).trigger('change');
				ttpProduct.set_Price(qty);
			});
			$('.ttp-thumbnails img').on('click', function (e) {
				e.preventDefault();
				$('#selected-img').addClass('d-none');
			});
		},
		OpenAdminArray: function () {
			if ($('button').hasClass('open-admin-only')) {
				$('#open-admin-only').on('click', function (e) {
					$('#admin-only').toggleClass('d-none d-block');
				});
			}
		},
		AddToCart: function () {
			let user_id = $("#btn-favorite").data("user")
			let skuMapIds = ttpProduct.GetIdMap();
			let IdMap2 = skuMapIds.replace(">", "&gt;");
			let SkuData;
			let skuId, skuMap2;
			let skulen = $('.item-parent').length;
			let skulen2 = $('.item-child').length;
			let n = $('#ttp-product').data('provider');
			let current_val = parseInt($('#qty').val(), 10);
			let canBookCount = parseInt($('#ali-stock').attr('data-stock-qty'));
			let price_raw = null;
			if (n == '1688') {
				skuMapIds = skuMapIds.replace(">", "&gt;");
				// skuMapIds = skuMapIds.replace("—", "&mdash;");
				// skuMapIds = skuMapIds.replace("—", "&mdash;");
				// skuMapIds = skuMapIds.replace("—", "&mdash;");
				// skuMapIds = skuMapIds.replace("—", "&mdash;");
				// skuMapIds = skuMapIds.replace("±", "&plusmn;");
				console.log(skuMapIds);
				console.log(AliProductInfo)
				if (skuMapIds == '') {
					skuId = AliProductInfo.id;
				}
				else if (skulen == 1 && !skulen2) {
					checkskuid = skuMapIds.length;

					if (skuMapIds == '杂款走份') {
						skuId = AliProductInfo.skuMap[skuMapIds + "&gt;" + skuMapIds].skuId;
						canBookCount = AliProductInfo.skuMap[skuMapIds + "&gt;" + skuMapIds].canBookCount;
						price_raw = AliProductInfo.skuMap[skuMapIds + "&gt;" + skuMapIds].price;
					}
					else if (skuMapIds == '+V 19876866468') {
						skuId = AliProductInfo.skuMap[skuMapIds + "&gt;" + skuMapIds].skuId;
						canBookCount = AliProductInfo.skuMap[skuMapIds + "&gt;" + skuMapIds].canBookCount;
						price_raw = AliProductInfo.skuMap[skuMapIds + "&gt;" + skuMapIds].price;
					}
					else if (skuMapIds == '如图') {
						skuId = AliProductInfo.skuMap[skuMapIds + "&gt;" + skuMapIds].skuId;
						canBookCount = AliProductInfo.skuMap[skuMapIds + "&gt;" + skuMapIds].canBookCount;
						price_raw = AliProductInfo.skuMap[skuMapIds + "&gt;" + skuMapIds].price;
					}
					else if (skuMapIds == '5') {
						skuId = AliProductInfo.skuMap[skuMapIds + "&gt;" + skuMapIds].skuId;
						canBookCount = AliProductInfo.skuMap[skuMapIds + "&gt;" + skuMapIds].canBookCount;
						price_raw = AliProductInfo.skuMap[skuMapIds + "&gt;" + skuMapIds].price;
					}
					else {
						skuId = AliProductInfo.skuMap[skuMapIds].skuId;
						canBookCount = AliProductInfo.skuMap[skuMapIds].canBookCount;
						price_raw = AliProductInfo.skuMap[skuMapIds].price;
					}
				}
				else if (skulen == 1 && skulen2 == 0) {
					skuMap2 = skuMapIds + "&gt;" + skuMapIds;
					skuId = AliProductInfo.skuMap[skuMap2].skuId;
					canBookCount = AliProductInfo.skuMap[skuMap2].canBookCount;
					price_raw = AliProductInfo.skuMap[skuMap2].price;
				}
				else {
					if (skuMapIds == '8+9【黑漆+黑皮+开盖停+5档位】' || skuMapIds == '8+9【水曲柳+棕绒+开盖停+5档位】' || skuMapIds == '8+9【黑檀漆+米白PU+开盖停+5模式】') {
						skuId = AliProductInfo.skuMap[skuMapIds + "&gt;" + skuMapIds].skuId;
						canBookCount = AliProductInfo.skuMap[skuMapIds + "&gt;" + skuMapIds].canBookCount;
						price_raw = AliProductInfo.skuMap[skuMapIds + "&gt;" + skuMapIds].price;
					}
					else {
						SkuData = AliProductInfo.skuMap;
						skuId = AliProductInfo.skuMap[skuMapIds].skuId;
						price_raw = AliProductInfo.skuMap[skuMapIds].price;
					}
				}
				if (typeof price_raw === 'undefined' || price_raw == '' || price_raw == null) {
					price_raw = $('.active .final-price').data('final-price');
				}
			}
			else if (n == 'tmall') {
				console.log(skuMapIds);
				skuMapIds = skuMapIds.replace(">", ";");

				x = AliProductInfo.skuMap.length;
				if (x == '1') {
					canBookCount = AliProductInfo.skuMap[0].quantity;
					price_raw = AliProductInfo.skuMap[0].price;
					skuId = AliProductInfo.id;
					console.log('x1');
					// skuMapIds = 'x';
				}
				else {
					for (i = 1; i < x; i++) {
						skuname = AliProductInfo.skuMap[i].skuName;
						if (skuname) {
							skuname = skuname.split("--");
							console.log('1');
							if (skuname[1] == skuMapIds) {
								skuId = AliProductInfo.skuMap[i].skuId;
								price_raw = AliProductInfo.skuMap[i].price;
								canBookCount = AliProductInfo.skuMap[i].quantity;  // ✅ เพิ่ม
							}
							else if (skuname[4]) {
								console.log('4');
								console.log(skuMapIds);
								skuMapIds = skuMapIds.replace(">", ";");
								skuname[1] = skuname[1].split(";");
								skuname[2] = skuname[2].split(";");
								skuname[3] = skuname[3].split(";");
								skuname[4] = skuname[4].split("--");
								console.log(skuname[1][0] + ';' + skuname[2][0] + ';' + skuname[3][0] + ';' + skuname[4]);
								if (skuname[1][0] + ';' + skuname[2][0] + ';' + skuname[3][0] + ';' + skuname[4] == skuMapIds) {
									skuId = AliProductInfo.skuMap[i].skuId;
									price_raw = AliProductInfo.skuMap[i].price;
									canBookCount = AliProductInfo.skuMap[i].quantity;
									console.log(price_raw);
								}
							}
							else if (skuname[3]) {
								skuMapIds = skuMapIds.replace(">", ";");
								console.log('3');
								skuname[1] = skuname[1].split(";");
								skuname[2] = skuname[2].split(";");
								skuname[3] = skuname[3].split(";");
								if (skuname[1][0] + ';' + skuname[2][0] + ';' + skuname[3] == skuMapIds) {
									skuId = AliProductInfo.skuMap[i].skuId;
									price_raw = AliProductInfo.skuMap[i].price;
									// เช็คว่ามี canbook หรือไม่
									canBookCount = AliProductInfo.skuMap[i].canBookCount ? AliProductInfo.skuMap[i].canBookCount : parseInt($('#ali-stock').attr('data-stock-qty'));
									console.log(price_raw);
								}
							}
							else if (skuname[2]) {
								skuname[1] = skuname[1].split(";");
								skuname[2] = skuname[2].split("--");
								if (skuname[1][0] + ';' + skuname[2] == skuMapIds) {
									skuId = AliProductInfo.skuMap[i].skuId;
									price_raw = AliProductInfo.skuMap[i].price;
									canBookCount = AliProductInfo.skuMap[i].quantity;  // ✅ เพิ่ม
									console.log('sku2');
								}
							}

							// console.log(canBookCount)
							if (typeof price_raw === 'undefined' || price_raw == '' || price_raw == null) {
								// แยก values ออกจาก skuName (ใช้ raw skuName จาก API ไม่ใช่ skuname ที่ถูก split แล้ว)
								let skuFullStr = AliProductInfo.skuMap[i].skuName || '';
								let skuValues = skuFullStr.split(';').map(part => {
									let idx = part.indexOf(':');
									return idx >= 0 ? part.slice(idx + 1).trim() : part.trim();
								}).filter(Boolean);

								// ใช้ skuMapIds (ที่ replace ">" เป็น ";" แล้ว) แทน IdMap2
								let targetValues = skuMapIds.split(/;|>/).map(s => s.trim()).filter(Boolean);

								let checkName = skuValues.length === targetValues.length &&
									skuValues.every(v => targetValues.includes(v));

								console.log('checkName:', checkName, 'skuValues:', skuValues, 'targetValues:', targetValues);

								if (checkName === true) {
									skuId = AliProductInfo.skuMap[i].skuId;
									price_raw = AliProductInfo.skuMap[i].price;
									canBookCount = AliProductInfo.skuMap[i].quantity;  // ✅ เพิ่ม
								}
							}
						}

						/*else{
							v = i-1;
							skuname = AliProductInfo.sku[0].values[v].name;
							console.log(skuname);
							// console.log(skuname);
							if(skuname == skuMapIds){
								console.log(skuMapIds);
							price_raw = AliProductInfo.skuMap[i].price;
							skuId = AliProductInfo.skuMap[i].skuId;
							}
						}*/
					}

				}
				if (typeof price_raw === 'undefined' || price_raw == '') {
					price_raw = $('.active .final-price').data('final-price');
				}
				if (typeof canBookCount === 'undefined' || canBookCount == '' || isNaN(canBookCount)) {
					canBookCount = parseInt($('#ali-stock').attr('data-stock-qty'));
				}
			}
			else {
				console.log('taobao add cart');

				const normalizeSkuValues = function (value) {
					return String(value || '')
						.replace(/&gt;/g, '>')
						.replace(/>/g, ';')
						.split(/\s*\/\s*|;/)
						.map(function (part) {
							part = String(part || '').trim();

							// รองรับ format:
							// 尺码:M 预售
							// 颜色:麻灰色
							const idx = part.indexOf(':');

							if (idx >= 0) {
								part = part.slice(idx + 1).trim();
							}

							return part;
						})
						.filter(Boolean)
						.sort();
				};

				const skuList = Array.isArray(AliProductInfo.skuMap)
					? AliProductInfo.skuMap
					: [];

				// reset ค่า
				skuId = undefined;
				price_raw = undefined;
				canBookCount = undefined;

				console.log('skuMapIds raw:', skuMapIds);

				if (skuList.length === 1) {
					const found = skuList[0];

					skuId = found.skuId || AliProductInfo.id;
					price_raw = Number(found.price ?? found.promotionPrice ?? 0);
					canBookCount = Number(found.quantity ?? found.stock ?? 0);

				} else {
					const targetValues = normalizeSkuValues(skuMapIds);

					console.log('targetValues:', targetValues);

					const found = skuList.find(function (sku) {
						const skuValues = normalizeSkuValues(sku.skuName);

						console.log(
							'check:',
							sku.skuName,
							skuValues,
							'price:',
							sku.price,
							'qty:',
							sku.quantity
						);

						if (skuValues.length !== targetValues.length) {
							return false;
						}

						return skuValues.every(function (value, index) {
							return value === targetValues[index];
						});
					});

					console.log('found sku:', found);

					if (found) {
						skuId = found.skuId;
						price_raw = Number(found.price ?? found.promotionPrice ?? 0);
						canBookCount = Number(found.quantity ?? found.stock ?? 0);
					} else {
						console.warn('TAOBAO SKU NOT FOUND:', skuMapIds);

						price_raw = Number(
							$('.active .final-price').data('final-price') || 0
						);

						canBookCount = 0;
					}
				}

				if (
					price_raw === undefined ||
					price_raw === null ||
					price_raw === '' ||
					!Number.isFinite(Number(price_raw))
				) {
					price_raw = Number(
						$('.active .final-price').data('final-price') || 0
					);
				}

				if (
					canBookCount === undefined ||
					canBookCount === null ||
					canBookCount === '' ||
					isNaN(canBookCount)
				) {
					canBookCount = 0;
				}

				console.log('TAOBAO ADD CART FINAL:', {
					skuMapIds: skuMapIds,
					skuId: skuId,
					price_raw: price_raw,
					canBookCount: canBookCount
				});
			}
			if (price_raw == '') {
				price_raw = $('.active .final-price').data('final-price');
			}
			// QTY
			if (Number.isNaN(current_val)) current_val = 1;
			let qty_in_cart = 0;
			if ($('[data-qty-in-cart]').length) {
				qty_in_cart = parseInt($('[data-qty-in-cart]').data('qty-in-cart'), 10);
			}
			let min_qty = parseInt($('[data-min-qty]').data('min-qty'), 10);
			let all_qty = current_val + qty_in_cart;
			let qty = current_val;
			if (all_qty < min_qty) qty = min_qty;

			let select1_img = "1";
			let select2_img = "2";
			let selectbuy_img = "";
			if ($(".attr .sku-item:checked + label img").length > 0) {
				selectbuy_img = ($(".attr .sku-item:checked + label img").attr('src')).replace("_40x40.jpg", "");
			} else {
				selectbuy_img = ('src', $('#selected-img img').attr('src'));

			}

			console.log("skuId:", skuId);
			console.log("skuMapIds:", skuMapIds);
			console.log("canBookCount:", canBookCount);
			console.log("price_raw:", price_raw);

			let p_data = {
				'taobao_ttp_x': $('#ttp-product').data('x'),
				"provider": $('#ttp-product').data('provider'),
				"sellerid": AliProductInfo.sellerid,
				"product_id": AliProductInfo.id,
				"skuId": skuId,
				"skuMap": skuMapIds,
				"prices": price_raw,
				"qty": qty,
				"image": selectbuy_img,
				"canBookCount": canBookCount,

			};
			console.log("p_data:", p_data);

			let data = {
				'action': 'ttp_add_to_card',
				'txt': ajax_object_add2Card.txtx,
				'version': '1.0.0',
				'product_data': p_data,
				'product_data_raw': AliProductInfo,
			};
			console.log("data:", data);
			try {
				var num_qty = 0;
				let dataSku = `div[data-sku-id="${skuId}"]`;
				// console.log($(".ttp-mini-cart "+dataSku+" .qty"))
				if ($(".ttp-mini-cart " + dataSku + " .qty").length > 0) {
					let qty_in_cart = parseInt($(".ttp-mini-cart " + dataSku + " .qty")[0].innerHTML);
					qty_in_cart += qty;
					if (qty_in_cart <= canBookCount) {
						ttpProduct.AddToDatabase(data, qty);
					} else {
						$(".popmake-popup-failed-limit-stock").click();
					}
				} else {
					console.log(canBookCount + " " + qty)
					if (qty <= canBookCount) {
						ttpProduct.AddToDatabase(data, qty);
					} else {
						$(".popmake-popup-failed-limit-stock").click();
					}
				}
			} catch (error) {
				console.log(error)
				ttpProduct.AddToDatabase(data, qty);
			}
		},
		AddToDatabase: function (data, qty) {
			let jqxhr = $.post(ajax_object_add2Card.ajax_url, data, function (response) {
				$('button[data-type="add-to-cart"]').removeClass('spinner').prop('disabled', false);
			})
				.fail(function (response) {
				})
				.always(function (response) { });
			jqxhr.always(function (response) {
				ttpProduct.AddToCart_SuccessAlert(response, qty);
				ttpProduct.reloadAfterAddedToCart();
				ttpProduct.reloadCart();
			});
		},
		reloadCart: function () {
			$.get(location.href, function (data) {
				var totalQty = $(data).find('.ttp-mini-cart .total-qty').first().text();
				$('.flaticon-cart02 .count').updateVal(totalQty);
				data = $(data).find('.ttp-mini-cart:first').html();
				$('.ttp-mini-cart').html(data);
			});
		},
		AddToCart_SuccessAlert: function (response, qty) {
			// Image
			let sec_id = '#sec-alert';
			let select1_img = "1";
			let select2_img = "2";
			if ($(".attr .sku-item:checked + label img").length > 0) {
				$(sec_id + ' .wrap-img img').attr('src', ($(".attr .sku-item:checked + label img").attr('src')).replace("_40x40.jpg", ""));
			} else {
				$(sec_id + ' .wrap-img img').attr('src', $('#selected-img img').attr('src'));
			}
			// $(sec_id + ' .wrap-img img').attr('src', $('#selected-img img').attr('src'));
			// Title
			$(sec_id + ' .title').text($('#ttp-product .title').text());
			// Attr
			$(sec_id + ' .attr').text(ttpProduct.getProductAttr());
			// Quantity
			$(sec_id + ' .qty').text(qty);
			// Price
			let price_raw = null;
			let skuMapIds = ttpProduct.GetIdMap();
			let IdMap2 = skuMapIds.replace(">", "&gt;");
			// IdMap2 = IdMap2.replace("—", "&mdash;");
			// IdMap2 = IdMap2.replace("—", "&mdash;");
			// IdMap2 = IdMap2.replace("—", "&mdash;");
			// IdMap2 = IdMap2.replace("—", "&mdash;");
			// IdMap2 = IdMap2.replace("±", "&plusmn;");
			let skulen = $('.item-parent').length;
			let skulen2 = $('.item-child').length;
			let provider = String($('#ttp-product').data('provider') || '').toLowerCase();
			if (provider == '1688') {
				if (skuMapIds == '') {
					skuId = AliProductInfo.id;
				} else if (skuMapIds.length == 1) {
					price_raw = $('.final-price').data('final-price');
					console.log(price_raw);
				}
				else if (skulen == 1 && !skulen2) {
					//	checkskuid = skuMapIds.matches("(?i).*&gt;*");
					//	console.log(checkskuid);
					/*if( checkskuid > 3){
						skuId = AliProductInfo.skuMap[skuMapIds+"&gt;"+skuMapIds].skuId;
						canBookCount = AliProductInfo.skuMap[skuMapIds+"&gt;"+skuMapIds].canBookCount;
						price_raw = AliProductInfo.skuMap[skuMapIds+"&gt;"+skuMapIds].price;
					}
					else{*/
					if (skuMapIds == '杂款走份') {
						skuId = AliProductInfo.skuMap[skuMapIds + "&gt;" + skuMapIds].skuId;
						canBookCount = AliProductInfo.skuMap[skuMapIds + "&gt;" + skuMapIds].canBookCount;
						price_raw = AliProductInfo.skuMap[skuMapIds + "&gt;" + skuMapIds].price;
					}
					else if (skuMapIds == '+V 19876866468') {
						skuId = AliProductInfo.skuMap[skuMapIds + "&gt;" + skuMapIds].skuId;
						canBookCount = AliProductInfo.skuMap[skuMapIds + "&gt;" + skuMapIds].canBookCount;
						price_raw = AliProductInfo.skuMap[skuMapIds + "&gt;" + skuMapIds].price;
					}
					else if (skuMapIds == '如图') {
						skuId = AliProductInfo.skuMap[skuMapIds + "&gt;" + skuMapIds].skuId;
						canBookCount = AliProductInfo.skuMap[skuMapIds + "&gt;" + skuMapIds].canBookCount;
						price_raw = AliProductInfo.skuMap[skuMapIds + "&gt;" + skuMapIds].price;
					}
					else if (skuMapIds == '5') {
						skuId = AliProductInfo.skuMap[skuMapIds + "&gt;" + skuMapIds].skuId;
						canBookCount = AliProductInfo.skuMap[skuMapIds + "&gt;" + skuMapIds].canBookCount;
						price_raw = AliProductInfo.skuMap[skuMapIds + "&gt;" + skuMapIds].price;
					}
					else {
						skuId = AliProductInfo.skuMap[skuMapIds].skuId;
						canBookCount = AliProductInfo.skuMap[skuMapIds].canBookCount;
						price_raw = AliProductInfo.skuMap[skuMapIds].price;
					}
				}
				else if (skulen == 1 && skulen2 == 0) {
					skuMap2 = skuMapIds + "&gt;" + skuMapIds;
					skuId = AliProductInfo.skuMap[skuMap2].skuId;
					canBookCount = AliProductInfo.skuMap[skuMap2].canBookCount;
					price_raw = AliProductInfo.skuMap[skuMap2].price;
				}
				else if (IdMap2 == '') {
					price_raw = $('.active .final-price').data('final-price');
				}
				else {
					if (IdMap2 == '8+9【黑漆+黑皮+开盖停+5档位】' || IdMap2 == '8+9【水曲柳+棕绒+开盖停+5档位】' || IdMap2 == '8+9【黑檀漆+米白PU+开盖停+5模式】') {
						skuId = AliProductInfo.skuMap[IdMap2 + "&gt;" + IdMap2].skuId;
						canBookCount = AliProductInfo.skuMap[IdMap2 + "&gt;" + IdMap2].canBookCount;
						price_raw = AliProductInfo.skuMap[IdMap2 + "&gt;" + IdMap2].price;
					}
					else {
						console.log(IdMap2);
						price_raw = AliProductInfo.skuMap[IdMap2].discountPrice;
					}
				}

				if (typeof price_raw === 'undefined' || price_raw == '' || price_raw == null) {
					price_raw = $('.active .final-price').data('final-price');
				}

			}
			else if (provider == 'tmall') {
				skuMapIds = skuMapIds.replace(">", ";");
				x = AliProductInfo.skuMap.length;

				if (x == '1') {
					canBookCount = AliProductInfo.skuMap[0].quantity;
					price_raw = AliProductInfo.skuMap[0].price;
				}
				else {
					// ✅ ใช้วิธีเดียวกับ taobao block: หา sku ที่ match แบบ set
					const pick = v => String(v || '').trim();

					const valuesFromSkuName = (skuName) => {
						return pick(skuName)
							.split(';')
							.map(part => {
								const idx = part.indexOf(':');
								return idx >= 0 ? pick(part.slice(idx + 1)) : pick(part);
							})
							.filter(Boolean);
					};

					const valuesFromIdMap = (idMap) => {
						return pick(idMap)
							.replace(/&gt;/g, '>')
							.replace(/>/g, ';')
							.split(';')
							.map(pick)
							.filter(Boolean);
					};

					const sameSet = (a, b) => {
						if (a.length !== b.length) return false;
						const aa = [...a].sort();
						const bb = [...b].sort();
						return aa.every((v, i) => v === bb[i]);
					};

					const targetVals = valuesFromIdMap(skuMapIds);

					const found = AliProductInfo.skuMap.find(s => {
						if (!s.skuName) return false;
						const skuVals = valuesFromSkuName(s.skuName);
						return sameSet(skuVals, targetVals);
					});

					if (found) {
						skuId = found.skuId;
						price_raw = found.price;
						canBookCount = found.quantity;
					} else {
						// Fallback: ใช้ logic เดิมแต่เพิ่ม break เมื่อเจอ match
						for (i = 1; i < x; i++) {
							skuname = AliProductInfo.skuMap[i].skuName;
							if (skuname) {
								skuname = skuname.split("--");

								if (skuname[1] == skuMapIds) {
									skuId = AliProductInfo.skuMap[i].skuId;
									price_raw = AliProductInfo.skuMap[i].price;
									canBookCount = AliProductInfo.skuMap[i].quantity;
									break;  // ✅ เพิ่ม break
								}
								else if (skuname[4]) {
									let smTemp = skuMapIds.replace(">", ";");
									let s1 = skuname[1].split(";");
									let s2 = skuname[2].split(";");
									let s3 = skuname[3].split(";");
									let s4 = skuname[4].split("--");
									if (s1[0] + ';' + s2[0] + ';' + s3[0] + ';' + s4 == smTemp) {
										skuId = AliProductInfo.skuMap[i].skuId;
										price_raw = AliProductInfo.skuMap[i].price;
										canBookCount = AliProductInfo.skuMap[i].quantity;
										break;  // ✅ เพิ่ม break
									}
								}
								else if (skuname[3]) {
									let smTemp = skuMapIds.replace(">", ";");
									let s1 = skuname[1].split(";");
									let s2 = skuname[2].split(";");
									let s3 = skuname[3].split(";");
									if (s1[0] + ';' + s2[0] + ';' + s3[0] == smTemp) {
										skuId = AliProductInfo.skuMap[i].skuId;
										price_raw = AliProductInfo.skuMap[i].price;
										canBookCount = AliProductInfo.skuMap[i].quantity;
										break;  // ✅ เพิ่ม break
									}
								}
								else if (skuname[2]) {
									let s1 = skuname[1].split(";");
									let s2 = skuname[2].split("--");
									// ✅ เพิ่ม condition กลับมา
									if (s1[0] + ';' + s2 == skuMapIds) {
										skuId = AliProductInfo.skuMap[i].skuId;
										price_raw = AliProductInfo.skuMap[i].price;
										canBookCount = AliProductInfo.skuMap[i].quantity;
										break;  // ✅ เพิ่ม break
									}
								}
							}
						}
					}
				}
			}
			else {
				skuMapIds = skuMapIds.replace(">", ";");
				/*skuMapIds = skuMapIds.replace("—", "&mdash;");
				skuMapIds = skuMapIds.replace("—", "&mdash;");
				skuMapIds = skuMapIds.replace("—", "&mdash;");
				skuMapIds = skuMapIds.replace("—", "&mdash;");*/
				// skuMapIds = skuMapIds.replace("+", "&plus;");
				console.log(AliProductInfo)
				console.log(skuMapIds)
				x = AliProductInfo.skuMap.length;
				if (x == '1') {
					canBookCount = AliProductInfo.skuMap[0].quantity;
					price_raw = AliProductInfo.skuMap[0].price;
				} else {
					for (i = 0; i < x; i++) {
						skuname = AliProductInfo.skuMap[i].skuName;
						if (skuname) {
							skuname = skuname.split("--");
							// console.log(skuname)
							if (skuname[1] == skuMapIds) {
								skuId = AliProductInfo.skuMap[i].skuId;
								price_raw = AliProductInfo.skuMap[i].price;
								console.log(price_raw);
							}
							else if (skuname[4]) {
								console.log('4');
								console.log(skuMapIds);
								skuMapIds = skuMapIds.replace(">", ";");
								skuname[1] = skuname[1].split(";");
								skuname[2] = skuname[2].split(";");
								skuname[3] = skuname[3].split(";");
								skuname[4] = skuname[4].split("--");
								console.log(skuname[1][0] + ';' + skuname[2][0] + ';' + skuname[3][0] + ';' + skuname[4]);
								if (skuname[1][0] + ';' + skuname[2][0] + ';' + skuname[3][0] + ';' + skuname[4] == skuMapIds) {
									skuId = AliProductInfo.skuMap[i].skuId;
									price_raw = AliProductInfo.skuMap[i].price;
									canBookCount = AliProductInfo.skuMap[i].quantity;
									console.log(price_raw);
								}
							}
							else if (skuname[3]) {
								console.log('3');
								console.log(skuMapIds);
								skuMapIds = skuMapIds.replace(">", ";");
								skuname[1] = skuname[1].split(";");
								skuname[2] = skuname[2].split(";");
								skuname[3] = skuname[3].split("--");
								if (skuname[1][0] + ';' + skuname[2][0] + ';' + skuname[3] == skuMapIds) {
									skuId = AliProductInfo.skuMap[i].skuId;
									price_raw = AliProductInfo.skuMap[i].price;
									canBookCount = AliProductInfo.skuMap[i].quantity;
									console.log(price_raw);
								}
							}
							else if (skuname[2]) {
								skuname[1] = skuname[1].split(";");
								skuname[2] = skuname[2].split("--");
								if (skuname[1][0] + ';' + skuname[2] == skuMapIds) {
									skuId = AliProductInfo.skuMap[i].skuId;
									price_raw = AliProductInfo.skuMap[i].price;
									console.log(price_raw);
								}

							}

							console.log(price_raw)
							if (price_raw) {
							} else {
								console.log(AliProductInfo.sku)
								if (AliProductInfo.sku && AliProductInfo.sku.length >= 1) {
									let skuFullId = '';
									let slu_split_id = skuMapIds.split(/;|>/);
									console.log(slu_split_id)

									if (slu_split_id.length == AliProductInfo.sku.length) {
										AliProductInfo.sku.forEach(function (sku_s, idxx) {
											skuFullId += sku_s.name + ':' + slu_split_id[idxx];
											if ((idxx + 1) != AliProductInfo.sku.length) {
												skuFullId += ';';
											}
										});
									}

									console.log(skuFullId, skuname)

									if (skuname[0] == skuFullId) {
										console.log(skuFullId)
										skuMapIds = skuFullId;
										skuId = AliProductInfo.skuMap[i].skuId;
										price_raw = AliProductInfo.skuMap[i].price;
										canBookCount = AliProductInfo.skuMap[i].quantity;
									}
								}
							}

						}
						/*else{
								v = i-1;
								skuname = AliProductInfo.sku[0].values[v].name;
								console.log(skuMapIds);
								if(skuname == skuMapIds){
							skuId = AliProductInfo.skuMap[i].skuId;
							price_raw = AliProductInfo.skuMap[i].price;
								}
							}*/

					}
				}
				if (typeof price_raw === 'undefined') {
					price_raw = $('.active .final-price').data('final-price');
				}
				// price_raw = $('.active .final-price').data('final-price');
				console.log(price_raw);
			}
			if ($('#price-steps .p-group').length > 1) {
				price_raw = $('.p-group.active .final-price').data('final-price');
			}
			if (typeof price_raw === 'undefined') {
				price_raw = $('.p-group.active .final-price').data('final-price');
			}
			let price = parseFloat(price_raw).toFixed(2);
			if (isNaN(price)) {
				price = $('.p-group.active .final-price').data('final-price');
			}
			console.log(price);
			console.log(price_raw);
			$(sec_id + ' .u-price').text(cso.thouSep2(price));
			// Total
			let tt = qty * price;
			let tt1 = parseFloat(tt).toFixed(2);
			$(sec_id + ' .s-total').text(cso.thouSep2(tt1));
			$('#sec-alert').addClass('d-flex');
			ttpProduct.reloadAfterAddedToCart();
		},
		getProductAttr: function () {
			let attr_2 = $('[data-attr-group="2"]');
			if (attr_2.length) {
				let txt = $('[data-attr-group="2"] .txt-label').text();
				let v = $('input[name=sku-2]:checked').data('label');
				return txt + ' ' + v;
			}
			return '';
		},
		Checked_DefaultAttr: function () {
			let active_sku;
			$('.group .attr').each(function (index) {
				let Elm = $(this).find(':radio:first');
				Elm.prop('checked', true);
				if (index == 0) {
					active_sku = Elm.data('sku');
				}
			});
			let startAmount = 1;

			if (ttp_price_steps.price[0].price != ttp_price_steps.promoPrice[0].price) {
				// Add promoPrice
				startAmount = ttp_price_steps.promoPrice[0].startAmount;
			} else {
				// Add Price
				startAmount = ttp_price_steps.price[0].startAmount;
			}
			if (AliProductInfo.id == "671430914153") {
				startAmount = 2
			}
			ttpProduct.set_Price(startAmount);
			$('#qty').val(startAmount).trigger('change');
			$('#qty').attr('min', startAmount);

			if (active_sku != undefined) {
				ttpProduct.DisplayChildSKU(skuParent[active_sku], true);
			}
		},
		set_Price: function (qty) {
			$('[data-step]').removeClass('active');
			let qty_in_cart = 0;
			qty_in_cart = $('[data-qty-in-cart]').data('qty-in-cart');
			// Qty in current Cart v.2
			qty_in_cart = localStorage.getItem('QtyInCart');
			qty = parseInt(qty, 10) + parseInt(qty_in_cart, 10);
			let price = 0;
			let i = 0;
			$.each(ttp_price_steps.price, function (index, step) {
				if (qty >= step.startAmount) {
					price = step.price;
					i = index;
				}
			});
			$('[data-step="' + i + '"]').addClass('active');
		},
		DisplayChildSKU: function (child_skus, set_default) {
			if (child_skus && child_skus[0] != undefined) {
				$('.item-child').removeClass('active');
				$.each(child_skus, function (index, value) {
					$('.attr [data-sku="' + value + '"]').closest('.item-child').addClass('active');
					if (set_default == true && index == 0) {
						$('.attr [data-sku="' + value + '"]').prop('checked', true);
						ttpProduct.Update_image($('.attr [data-sku="' + value + '"]'));
					}
				});
			}
		},
		Update_price: function (Elm) {
			if ($('#sku-group').length) {
				let gidmap = ttpProduct.GetIdMap();
				let IdMap2, skulen, skulen2, skuMap2;
				let idMap;
				let skuId;
				let skuname;
				let x, chesku;
				let i, priceth;
				let price_raw;
				let canBookCount;
				let provider = String($('#ttp-product').data('provider') || '').toLowerCase();
				let useremail_ajax = $('#ttp-product').data('useremail');
				// console.log(useremail_ajax)
				if ("redacted@example.invalid" == useremail_ajax) {
					IdMap2 = gidmap.replace(">", "&gt;");
					// IdMap2 = IdMap2.replace("—", "&mdash;");
					// IdMap2 = IdMap2.replace("—", "&mdash;");
					// IdMap2 = IdMap2.replace("—", "&mdash;");
					// IdMap2 = IdMap2.replace("—", "&mdash;");
					// IdMap2 = IdMap2.replace("—", "&mdash;");
					// IdMap2 = IdMap2.replace("±", "&plusmn;");
					// IdMap2 = IdMap2.replace("-", "&minus;");
					// IdMap2 = IdMap2.replace("+", "&plus;");
					idMap = AliProductInfo.skuMap;

					skulen = $('.item-parent').length;
					skulen2 = $('.item-child').length;
					console.log(skulen2);
					if (IdMap2 == '' || IdMap2 == null) {
						IdMap2 = AliProductInfo.id;
						skuId = AliProductInfo.id;
						canBookCount = $('#ali-stock').data('stock-qty');
						if (canBookCount == '') {
							canBookCount = '9999';
						}

					}
					else if (skulen == 1 && !skulen2) {
						// checkskuid = IdMap[].indexOf("&gt;");
						console.log(IdMap2);
						console.log('alip', AliProductInfo.skuMap);
						if (IdMap2 == '杂款走份') {
							skuId = AliProductInfo.skuMap[IdMap2 + "&gt;" + IdMap2].skuId;
							canBookCount = AliProductInfo.skuMap[IdMap2 + "&gt;" + IdMap2].canBookCount;
							price_raw = AliProductInfo.skuMap[IdMap2 + "&gt;" + IdMap2].price;
						}
						else if (IdMap2 == '+V 19876866468') {
							skuId = AliProductInfo.skuMap[IdMap2 + "&gt;" + IdMap2].skuId;
							canBookCount = AliProductInfo.skuMap[IdMap2 + "&gt;" + IdMap2].canBookCount;
							price_raw = AliProductInfo.skuMap[IdMap2 + "&gt;" + IdMap2].price;
						}
						else if (IdMap2 == '如图') {
							skuId = AliProductInfo.skuMap[IdMap2 + "&gt;" + IdMap2].skuId;
							canBookCount = AliProductInfo.skuMap[IdMap2 + "&gt;" + IdMap2].canBookCount;
							price_raw = AliProductInfo.skuMap[IdMap2 + "&gt;" + IdMap2].price;
						}
						else if (IdMap2 == '5') {
							skuId = AliProductInfo.skuMap[IdMap2 + "&gt;" + IdMap2].skuId;
							canBookCount = AliProductInfo.skuMap[IdMap2 + "&gt;" + IdMap2].canBookCount;
							price_raw = AliProductInfo.skuMap[IdMap2 + "&gt;" + IdMap2].price;
						}
						else {
							skuId = AliProductInfo.skuMap[IdMap2].skuId;
							canBookCount = AliProductInfo.skuMap[IdMap2].canBookCount;
							price_raw = AliProductInfo.skuMap[IdMap2].price;
						}

					}
					else if (skulen == 1 && skulen2 == 0) {
						skuMap2 = gidmap + "&gt;" + gidmap;
						skuId = AliProductInfo.skuMap[skuMap2].skuId;
						canBookCount = AliProductInfo.skuMap[skuMap2].canBookCount;
						price_raw = AliProductInfo.skuMap[skuMap2].price;
					}
					else {

						if (IdMap2 == '8+9【黑漆+黑皮+开盖停+5档位】' || IdMap2 == '8+9【水曲柳+棕绒+开盖停+5档位】' || IdMap2 == '8+9【黑檀漆+米白PU+开盖停+5模式】') {
							skuId = AliProductInfo.skuMap[IdMap2 + "&gt;" + IdMap2].skuId;
							canBookCount = AliProductInfo.skuMap[IdMap2 + "&gt;" + IdMap2].canBookCount;
							price_raw = AliProductInfo.skuMap[IdMap2 + "&gt;" + IdMap2].price;
						}
						else {
							console.log(IdMap2);
							if (typeof AliProductInfo.skuMap[IdMap2] == 'undefined') {
								canBookCount = 0;
							}
							else {
								skuId = AliProductInfo.skuMap[IdMap2].skuId;
								canBookCount = AliProductInfo.skuMap[IdMap2].canBookCount;
								price_raw = AliProductInfo.skuMap[IdMap2].price;
							}
						}
					}

					console.log(price_raw)
					if (typeof price_raw === 'undefined' || price_raw == '') {
						price_raw = $('.active .final-price').data('final-price');
					}
					console.log(price_raw)
				} else {
					if (provider == '1688') {
						IdMap2 = gidmap.replace(">", "&gt;");
						// IdMap2 = IdMap2.replace("—", "&mdash;");
						// IdMap2 = IdMap2.replace("—", "&mdash;");
						// IdMap2 = IdMap2.replace("—", "&mdash;");
						// IdMap2 = IdMap2.replace("—", "&mdash;");
						// IdMap2 = IdMap2.replace("—", "&mdash;");
						// IdMap2 = IdMap2.replace("±", "&plusmn;");
						// IdMap2 = IdMap2.replace("-", "&minus;");
						// IdMap2 = IdMap2.replace("+", "&plus;");
						idMap = AliProductInfo.skuMap;

						skulen = $('.item-parent').length;
						skulen2 = $('.item-child').length;

						if (IdMap2 == '' || IdMap2 == null) {
							IdMap2 = AliProductInfo.id;
							skuId = AliProductInfo.id;
							canBookCount = $('#ali-stock').data('stock-qty');
							if (canBookCount == '') {
								canBookCount = '20000';
							}

						}
						else if (skulen == 1 && !skulen2) {
							// checkskuid = IdMap[].indexOf("&gt;");

							if (IdMap2 == '杂款走份') {
								skuId = AliProductInfo.skuMap[IdMap2 + "&gt;" + IdMap2].skuId;
								canBookCount = AliProductInfo.skuMap[IdMap2 + "&gt;" + IdMap2].canBookCount;
								price_raw = AliProductInfo.skuMap[IdMap2 + "&gt;" + IdMap2].price;
							}
							else if (IdMap2 == '+V 19876866468') {
								skuId = AliProductInfo.skuMap[IdMap2 + "&gt;" + IdMap2].skuId;
								canBookCount = AliProductInfo.skuMap[IdMap2 + "&gt;" + IdMap2].canBookCount;
								price_raw = AliProductInfo.skuMap[IdMap2 + "&gt;" + IdMap2].price;
							}
							else if (IdMap2 == '如图') {
								skuId = AliProductInfo.skuMap[IdMap2 + "&gt;" + IdMap2].skuId;
								canBookCount = AliProductInfo.skuMap[IdMap2 + "&gt;" + IdMap2].canBookCount;
								price_raw = AliProductInfo.skuMap[IdMap2 + "&gt;" + IdMap2].price;
							}
							else if (IdMap2 == '5') {
								skuId = AliProductInfo.skuMap[IdMap2 + "&gt;" + IdMap2].skuId;
								canBookCount = AliProductInfo.skuMap[IdMap2 + "&gt;" + IdMap2].canBookCount;
								price_raw = AliProductInfo.skuMap[IdMap2 + "&gt;" + IdMap2].price;
							}
							else {
								skuId = AliProductInfo.skuMap[IdMap2].skuId;
								canBookCount = AliProductInfo.skuMap[IdMap2].canBookCount;
								price_raw = AliProductInfo.skuMap[IdMap2].price;
							}

						}
						else if (skulen == 1 && skulen2 == 0) {
							skuMap2 = gidmap + "&gt;" + gidmap;
							skuId = AliProductInfo.skuMap[skuMap2].skuId;
							canBookCount = AliProductInfo.skuMap[skuMap2].canBookCount;
							price_raw = AliProductInfo.skuMap[skuMap2].price;
						}
						else {

							if (IdMap2 == '8+9【黑漆+黑皮+开盖停+5档位】' || IdMap2 == '8+9【水曲柳+棕绒+开盖停+5档位】' || IdMap2 == '8+9【黑檀漆+米白PU+开盖停+5模式】') {
								skuId = AliProductInfo.skuMap[IdMap2 + "&gt;" + IdMap2].skuId;
								canBookCount = AliProductInfo.skuMap[IdMap2 + "&gt;" + IdMap2].canBookCount;
								price_raw = AliProductInfo.skuMap[IdMap2 + "&gt;" + IdMap2].price;
							}
							else {

								if (typeof AliProductInfo.skuMap[IdMap2] == 'undefined') {
									canBookCount = 0;
								}
								else {
									skuId = AliProductInfo.skuMap[IdMap2].skuId;
									canBookCount = AliProductInfo.skuMap[IdMap2].canBookCount;
									price_raw = AliProductInfo.skuMap[IdMap2].price;
								}
							}
						}


						if (typeof price_raw === 'undefined' || price_raw == '') {
							price_raw = $('.active .final-price').data('final-price');
						}


						// console.log(AliProductInfo)

						// if(canBookCount = '9999'){
						// 	canBookCount = AliProductInfo
						// }
					}
					else if (provider == 'tmall') {
						console.log('tmall');
						IdMap2 = gidmap.replace(/>/g, ";");
						// IdMap2 = gidmap.replace(">", ";");
						idMap = AliProductInfo.skuMap;
						x = AliProductInfo.skuMap.length;
						console.log(AliProductInfo.skuMap);
						console.log(IdMap2);
						console.log(x);
						console.log(idMap);
						if (x == '1') {
							canBookCount = AliProductInfo.skuMap[0].quantity;
							price_raw = AliProductInfo.skuMap[0].price;
							skuId = AliProductInfo.id;
							console.log('x1');
							console.log(canBookCount);
						}
						else {
							for (i = 1; i < x; i++) {
								skuname = AliProductInfo.skuMap[i].skuName;
								if (skuname) {
									skuname = skuname.split("--");
									// console.log(skuname);
									if (skuname[1] == IdMap2) {
										canBookCount = AliProductInfo.skuMap[i].quantity;
										price_raw = AliProductInfo.skuMap[i].price;
										console.log('1');
										console.log(IdMap2);
										console.log(skuname[1]);
										console.log(canBookCount);
										console.log(price_raw);
									}
									// else if (skuname[5]) {
									// 	console.log('5');
									// 	console.log(IdMap2);
									// 	IdMap2 = IdMap2.replace(">", ";");
									// 	skuname[1] = skuname[1].split(";");
									// 	skuname[2] = skuname[2].split(";");
									// 	skuname[3] = skuname[3].split(";");
									// 	skuname[4] = skuname[4].split(";");
									// 	skuname[5] = skuname[5].split("--");
									// 	console.log(skuname);
									// 	console.log(skuname[1][0] + ';' + skuname[2][0] + ';' + skuname[3][0] + ';' + skuname[4][0] + ';' + skuname[5]);
									// 	if (skuname[1][0] + ';' + skuname[2][0] + ';' + skuname[3][0] + ';' + skuname[4][0] + ';' + skuname[5][0] == IdMap2) {
									// 		skuId = AliProductInfo.skuMap[i].skuId;
									// 		price_raw = AliProductInfo.skuMap[i].price;
									// 		canBookCount = AliProductInfo.skuMap[i].quantity;
									// 		console.log(price_raw);
									// 	}
									// }
									else if (skuname[4]) {
										console.log('4');
										console.log(IdMap2)
										IdMap2 = IdMap2.replace(">", ";");
										skuname[1] = skuname[1].split(";");
										skuname[2] = skuname[2].split(";");
										skuname[3] = skuname[3].split(";");
										if (skuname[4].includes("--")) {
											skuname[4] = skuname[4].split("--");
										} else if (skuname[4].includes(";")) {
											skuname[4] = skuname[4].split(";");
										}
										console.log(skuname);
										console.log(skuname[1][0] + ';' + skuname[2][0] + ';' + skuname[3][0] + ';' + skuname[4][0]);
										if (skuname[1][0] + ';' + skuname[2][0] + ';' + skuname[3][0] + ';' + skuname[4][0] == IdMap2) {
											skuId = AliProductInfo.skuMap[i].skuId;
											price_raw = AliProductInfo.skuMap[i].price;
											canBookCount = AliProductInfo.skuMap[i].quantity;
											console.log(price_raw);
										}
									}
									else if (skuname[3]) {
										IdMap2 = IdMap2.replace(">", ";");

										console.log('3');
										skuname[1] = skuname[1].split(";");
										skuname[2] = skuname[2].split(";");
										skuname[3] = skuname[3].split(";");
										console.log(IdMap2);
										console.log(skuname[1][0] + ';' + skuname[2][0] + ';' + skuname[3]);
										if (skuname[1][0] + ';' + skuname[2][0] + ';' + skuname[3] == IdMap2) {
											console.log('v3');
											canBookCount = AliProductInfo.skuMap[i].quantity;
											price_raw = AliProductInfo.skuMap[i].price;
											console.log(price_raw);
											console.log(canBookCount);
										} else if (skuname[2][0] + ';' + skuname[1][0] + ';' + skuname[3] == IdMap2) {
											console.log('v3');
											canBookCount = AliProductInfo.skuMap[i].quantity;
											price_raw = AliProductInfo.skuMap[i].price;
											console.log(price_raw);
											console.log(canBookCount);
										} else if (skuname[3] + ';' + skuname[2][0] + ';' + skuname[1][0] == IdMap2) {
											console.log('v3');
											canBookCount = AliProductInfo.skuMap[i].quantity;
											price_raw = AliProductInfo.skuMap[i].price;
											console.log(price_raw);
											console.log(canBookCount);
										}
									}
									else if (skuname[2]) {
										skuname[1] = skuname[1].split(";");
										skuname[2] = skuname[2].split("--");
										if (skuname[1][0] + ';' + skuname[2] == IdMap2) {
											console.log('2');
											canBookCount = AliProductInfo.skuMap[i].quantity;
											price_raw = AliProductInfo.skuMap[i].price;
											console.log(price_raw);
											console.log(canBookCount);
										}
									}
									/*
									else{
										price_raw = AliProductInfo.skuMap[i].price;
										canBookCount = AliProductInfo.skuMap[i].quantity;
										
									}*/
									if (typeof canBookCount === 'undefined' || canBookCount == '') {
										// แยก values ออกจาก skuName เช่น "地毯尺寸:80×160厘米;颜色分类:卡其色【长毛款】"
										// → ["80×160厘米", "卡其色【长毛款】"]
										let skuFullStr = AliProductInfo.skuMap[i].skuName || '';
										let skuValues = skuFullStr.split(';').map(part => {
											let idx = part.indexOf(':');
											return idx >= 0 ? part.slice(idx + 1).trim() : part.trim();
										}).filter(Boolean);

										// แยก values ของ IdMap2 เช่น "80×160厘米;卡其色【长毛款】"
										let targetValues = IdMap2.split(/;|>/).map(s => s.trim()).filter(Boolean);

										// เทียบแบบ set (ไม่สนใจลำดับ)
										let checkName = skuValues.length === targetValues.length &&
											skuValues.every(v => targetValues.includes(v));

										console.log('checkName:', checkName, 'skuValues:', skuValues, 'targetValues:', targetValues);

										if (checkName === true) {
											skuId = AliProductInfo.skuMap[i].skuId;
											price_raw = AliProductInfo.skuMap[i].price;
											canBookCount = AliProductInfo.skuMap[i].quantity;
										}
									}
								}


								/*else{
										v = i-1;
									skuname = AliProductInfo.sku[0].values[v].name;
									console.log(IdMap2);
									// console.log(skuname);
									if(skuname == IdMap2){
										console.log(IdMap2);
									price_raw = AliProductInfo.skuMap[i].price;
									canBookCount = AliProductInfo.skuMap[i].quantity;
									}
									console.log(IdMap2);
								}*/

							}
						}

						if (typeof price_raw === 'undefined' || price_raw == '') {
							price_raw = $('.active .final-price').data('final-price');
						}
						if (typeof canBookCount === 'undefined' || canBookCount == '') {
							canBookCount = 0;
						}


					}
					else {
						console.log('taobao');

						const normalizeSkuValues = function (value) {
							return String(value || '')
								.replace(/&gt;/g, '>')
								.replace(/>/g, ';')
								.split(/\s*\/\s*|;/)
								.map(function (part) {
									part = String(part || '').trim();

									const idx = part.indexOf(':');

									if (idx >= 0) {
										part = part.slice(idx + 1).trim();
									}

									return part;
								})
								.filter(Boolean)
								.sort();
						};

						IdMap2 = gidmap.replace(/>/g, ';');

						idMap = AliProductInfo.skuMap;
						x = Array.isArray(AliProductInfo.skuMap)
							? AliProductInfo.skuMap.length
							: 0;

						price_raw = undefined;
						canBookCount = undefined;
						skuId = undefined;

						console.log('IdMap2:', IdMap2);

						if (x === 1) {
							const found = AliProductInfo.skuMap[0];

							skuId = found.skuId || AliProductInfo.id;
							price_raw = Number(found.price ?? found.promotionPrice ?? 0);
							canBookCount = Number(found.quantity ?? found.stock ?? 0);

						} else {
							const targetValues = normalizeSkuValues(IdMap2);

							console.log('targetValues:', targetValues);

							const found = AliProductInfo.skuMap.find(function (sku) {
								const skuValues = normalizeSkuValues(sku.skuName);

								console.log(
									'check sku:',
									sku.skuName,
									skuValues,
									'qty:',
									sku.quantity,
									'price:',
									sku.price
								);

								console.log('AliProductInfo.id', AliProductInfo.id);

								if(AliProductInfo.id == '696498563176'){
									return skuValues.some(function (value, index) {
										let check_value = false;
										targetValues.forEach(function (targetValue) {
											if (value === targetValue) {
												check_value = true;
												return check_value;
											}
										})

										return check_value;
									})
								}

								if (skuValues.length !== targetValues.length) {
									return false;
								}

								return skuValues.every(function (value, index) {
									return value === targetValues[index];
								});
							});

							console.log('FOUND SKU:', found);

							if (found) {
								skuId = found.skuId;
								price_raw = Number(found.price ?? found.promotionPrice ?? 0);
								canBookCount = Number(found.quantity ?? found.stock ?? 0);
							} else {
								console.warn('TAOBAO SKU NOT FOUND:', IdMap2);

								price_raw = Number(
									$('.active .final-price').data('final-price') || 0
								);

								canBookCount = 0;
							}
						}

						if (
							price_raw === undefined ||
							price_raw === null ||
							price_raw === '' ||
							!Number.isFinite(Number(price_raw))
						) {
							price_raw = Number(
								$('.active .final-price').data('final-price') || 0
							);
						}

						if (
							canBookCount === undefined ||
							canBookCount === null ||
							canBookCount === '' ||
							isNaN(canBookCount)
						) {
							canBookCount = 0;
						}

						console.log('TAOBAO UPDATE PRICE FINAL:', {
							IdMap2: IdMap2,
							skuId: skuId,
							price_raw: price_raw,
							canBookCount: canBookCount
						});
					}
				}
				if (AliProductInfo.id == "763061640835") {
					AliProductInfo.skuMap[0].quantity = 5
					canBookCount = 5
				} else if (AliProductInfo.id == "567041541049") {
					AliProductInfo.skuMap[0].quantity = 100
					canBookCount = 100
				} else if (AliProductInfo.id == "676719743399") {
					console.log(IdMap2)
					if (IdMap2 == "RX189 A款&gt;按钮开关") {
						AliProductInfo.skuMap[IdMap2].quantity = 20
						canBookCount = 20
					}
				} else if (AliProductInfo.id == "680471269940") {
					AliProductInfo.skuMap[0].quantity = 6
					canBookCount = 6
				} else if (AliProductInfo.id == "770745609169") {
					for (const key in AliProductInfo.skuMap) {
						AliProductInfo.skuMap[key].canBookCount = 10000
					}
					canBookCount = 10000
				} else if (AliProductInfo.id == "571639444414") {
					for (const key in AliProductInfo.skuMap) {
						AliProductInfo.skuMap[key].canBookCount = 200
					}
					canBookCount = 200
				} else if (AliProductInfo.id == "671430914153") {
					startAmount = 2
					$('.e-begin').attr('data-min-qty', startAmount);
					$('.e-begin').text('(2)');
				}


				$('#ali-stock').text(ttpProduct.TodNiYom(canBookCount));
				$('#ali-stock').attr('data-stock-qty', canBookCount);
				if ('taobao' == provider || 'tmall' == provider || $('.p-group').data('price-type') == 'sku-1688') {
					if (price_raw) {
						priceth = price_raw * TTPcargo.exchange_rate_yuan;
						$('.pricethb').text(cso.TodNiYom(priceth, 2));
					}
					$('#price-steps [data-price]').attr('data-price', price_raw);
					$('#price-steps [data-final-price]').attr('data-final-price', price_raw).text(price_raw);
					$('#price-steps [data-promo-price]').attr('data-promo-price', price_raw).text(price_raw);
				}
				if (canBookCount == 0) {
					$('#oos').removeClass('d-none');
					$('.atc').addClass('disabled');
				} else {
					$('#oos').addClass('d-none');
					$('.atc').removeClass('disabled');
				}
			}
		},
		QtyKeyUp_Update_PriceStep: function () {
			$(document).on('input', '#qty', sp_delay(function () {
				let current_val = parseInt($(this).val(), 10);
				if (Number.isNaN(current_val)) current_val = 1;
				let min_qty = parseInt($('[data-min-qty]').data('min-qty'), 10);
				// Qty in Cart
				let all_qty = current_val + parseInt(localStorage.getItem('QtyInCart'), 10);
				let qty = current_val;
				if (all_qty < min_qty) {
					qty = min_qty;
					$(this).val(qty).trigger('change');
				}
				if (qty < 1) {
					qty = 1;
					$(this).val(1).trigger('change');
				}
				ttpProduct.set_Price(qty);
			}, 600));
		},
		GetIdMap: function () {
			let skus = '';
			if ($('[data-attr-group]').length) {
				let skusSep = '';
				$('[data-attr-group]').each(function (index) {
					if (index > 0) {
						skusSep = '>';
					}
					skus += skusSep + $(this).find('.sku-item:radio:checked').data('sku');
				});
			}
			return skus;
		},
		GetIdMap_v2: function () {
		},
		Update_image: function (Elm) {
			if (Elm.data('image') && Elm.data('image').length > 0) {
				$('#selected-img').removeClass('d-none');
				$('#selected-img a').attr('href', Elm.data('image').trim());
				$('#selected-img img').attr('src', Elm.data('image').trim());
				$('#selected-img a').attr('data-featherlight', Elm.data('image').trim());
			}
		},
		AttrQtyChange_Update_price: function () {
			var ParentSku = $('[data-sku-type="parent"]:radio:checked').data('sku');
			$('#sku-group :radio').change(function () {
				// Product Image
				ttpProduct.Update_image($(this));
				let active_sku;
				if ($(this).data('sku-type') == 'parent') {
					active_sku = $(this).data('sku');
					let reset = true;
					if (arraysEqual(skuParent[ParentSku], skuParent[active_sku])) {
						reset = undefined;
					}
					ttpProduct.DisplayChildSKU(skuParent[active_sku], reset);
					ParentSku = active_sku;
				}
				ttpProduct.Update_price($(this));
			});
		},
		SignInLink: function () {
			if ($('.pls-sign-in')[0]) {
				// var urlEncoded = encodeURIComponent(window.location.href + '&loggedin=1');
				var urlEncoded = encodeURIComponent(window.location.href);
				$('.pls-sign-in').attr('href', 'https://ttpcargo.com/login/?fromlink=' + urlEncoded);

				// $('.pls-sign-in').attr('href','https://ttpcargo.com/?customer-logout=true');
			}
		},
		TodNiYom: function (num, decimalN) {
			if (decimalN > 0) {
				var numN = parseFloat(num).toFixed(decimalN);
			} else {
				var numN = Math.round(num * 100) / 100;
			}
			decimalN = null;
			//return numN;
			return numN.toLocaleString();
		},
		reloadAfterAddedToCart: function () {
			$.get(location.href, function (data) {
				let qty = $(data).find('#ttp-product').data('qty-in-cart-ttp');
				// Total this product in cart
				$('#qty-in-cart').text(qty).attr('data-qty-in-cart', qty);
				localStorage.setItem('QtyInCart', qty);
				// Mini Cart
				var totalQty = $(data).find('.ttp-mini-cart .total-qty').first().text();
				$('.flaticon-cart02 .count').updateVal(totalQty);
				data = $(data).find('.ttp-mini-cart:first').html();
				$('.ttp-mini-cart').html(data);
			});
		},
		setQtyInCart: function () {
			if ($('[data-qty-in-cart]').length) {
				localStorage.setItem('QtyInCart', $('[data-qty-in-cart]').data('qty-in-cart'));
			}
			if (!localStorage.getItem('QtyInCart')) {
				localStorage.setItem('QtyInCart', 0);
			}
		}
	};
	window.ttpProduct = ttpProductFunction;
})(jQuery);
function arraysEqual(arr1, arr2) {
	if (arr1.length !== arr2.length) return false;
	for (var i = arr1.length; i--;) {
		if (arr1[i] !== arr2[i])
			return false;
	}
	return true;
}
function sp_delay(callback, ms) {
	var timer = 0;
	return function () {
		var context = this, args = arguments;
		clearTimeout(timer);
		timer = setTimeout(function () {
			callback.apply(context, args);
		}, ms || 0);
	};
}

$('.next-button, .prev-button').click(function () {
	const liAction = $('.ttp-thumbnails li').index(
		$('.ttp-thumbnails li.tns-nav-active')
	);
	$('.ttp-thumbnails li').removeClass('tns-nav-active');
	$(`.ttp-thumbnails li`).eq(liAction).addClass('tns-nav-active');

	$(`.ttp-thumbnails li`).eq(liAction)[0].scrollIntoView({
		behavior: 'smooth',
		inline: 'center', // ให้มาอยู่กลางแนวนอน
		block: 'nearest',
	});
});

// คลิกรูป
$('.ttp-thumbnails li').click(function () {
	$('.ttp-thumbnails li').removeClass('tns-nav-active');
	$(this).addClass('tns-nav-active');

	this.scrollIntoView({
		behavior: 'smooth',
		inline: 'center', // ให้มาอยู่กลางแนวนอน
		block: 'nearest',
	});
});
$(document).on('click.reclickParentOnly', '.item-parent', function () {
	const $item = $(this);
	const $group = $item.closest('.group');
	const $allParentInGroup = $group.find('.item-parent');
	const $input = $item.find('input.sku-item[type="radio"]').first();

	if (!$input.length) return;

	// เช็กว่าเป็น item-parent ตัวแรกของ group นี้ไหม
	const isFirstParent = $allParentInGroup.index($item) === 0;

	// เช็กว่าตัวนี้ถูกเลือกอยู่แล้วไหม
	const isSelected =
		$input.prop('checked') ||
		$item.hasClass('s0') ||
		$item.hasClass('active');

	// อนุญาตเฉพาะ "ตัวแรก" ที่ "ถูกเลือกอยู่แล้ว" เท่านั้น
	if (!(isFirstParent && isSelected)) {
		return;
	}

	// ดึงรูปจาก data-image ของ input ก่อน
	let image = $input.attr('data-image');

	// ถ้าไม่มี ค่อยลองจาก label
	if (!image) {
		image = $item.find('label').attr('data-image');
	}

	if (!image) return;

	// เปลี่ยน selector ข้างล่างให้ตรง "รูปหลัก" ของหน้าคุณ
	const $mainImg = $('.main-image').first();

	if ($mainImg.length) {
		$mainImg.attr('src', image);
	}

	// ถ้าระบบเดิมมี listener ที่ผูกกับ change อยู่ จะได้ทำงานต่อ
	$input.trigger('change');
});