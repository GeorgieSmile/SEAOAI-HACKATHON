
var tC = undefined;
var AJAXurl = ajax_object_add2Card.ajax_url;

jQuery(function($){

	// v.0.0.1
	var dev = 'add-to-cart.js dev.25-66';
	//console.log( dev );

	var tC = '.ttp-cart';
	var TTpCart = $(tC);
	var mC = '.ttp-mini-cart';
	var Mc = $(mC);
	var fCart = '.ttp-full-cart';
	var FullCart = $(fCart);
	var del = '.del-btn';
	var mcLine = '.mc-line';
	var ipQ = '.qty input.quantity';
	var $qty = $(ipQ);
	var CheckOutButton = $('.checkout-button');
	var spinner = '<div class="wrap-spinner"><span class="spinner"></span></div>';

	/**
	 * Update Mini Cart Qty
	 */
	// $(window).load(function() {
	// 	$('.flaticon-cart02 .count').updateVal( ($(mC+' .total-qty').first().text().trim() == '')?'0':$(mC+' .total-qty').first().text() );
	// });

	function tryUpdate() {
		var $qty   = $(mC + ' .total-qty').first();
		var $count = $('.flaticon-cart02 .count');
		if (!$qty.length || !$count.length) return false;

		var val = $.trim($qty.text()) || '0';
		if ($.fn.updateVal) { $count.updateVal(val); }
		else { $count.text(val); } // เผื่อไม่มีปลั๊กอิน updateVal
		return true;
	}

	// ลองอัปเดตทันที ถ้าพร้อมแล้วก็จบเลย
	if (!tryUpdate()){
		// ถ้ายังไม่พร้อม ให้เช็คซ้ำทุก 100ms สูงสุด ~15 วินาที
		var tries = 0, maxTries = 150, interval = 100;
		var timer = setInterval(function () {
			if (tryUpdate() || ++tries >= maxTries) clearInterval(timer);
		}, interval);
	}


	//ปิดเพราะโหลดรูปไม่ทัน
	// $(window).on("scroll", function () {
	// 	let subTotalBottom = $("#sub-total-thb").offset().top + $("#sub-total-thb").outerHeight();
	// 	let screenTop = $(window).scrollTop();

	// 	if (screenTop > subTotalBottom) {
	// 		// เลื่อนเลยจุดต่ำสุดแล้ว
	// 		$("#show_price_fixed").removeClass("d-none").addClass("d-block");

	// 		// console.log("TESTA")
	// 	} else {
	// 		// console.log("TESTB")
	// 		// ยังอยู่เหนือจุดต่ำสุด
	// 		$("#show_price_fixed").removeClass("d-block").addClass("d-none");
	// 	}
	// });

// $( document ).ready(function() {
// 	if (screen.width >= 769){
// $(".quantity[type='number']").keypress(function (evt) {
//     evt.preventDefault();
// });
// 	}
// });

	/**
	 * Display/Hide Delete Button
	 */
	/*if( TTpCart.length ) {

		var McLine = $(mcLine);
		var DelBtn = $(del);

		// Create Mini Cart ID
		TTpCart.each(function( index ) {
			$(this).attr('id','ttp-cart-'+ ( index + 1 ) );
		});
		TTpCart.on('mouseenter', mcLine, function() {
			//do something
			$(this).find('.del-btn').show();
		});
		TTpCart.on('mouseleave', mcLine, function() {
			//do something
			$(this).find('.del-btn').hide();
		});
	}*/

	/**
	 * Update Qty on /cart page.
	 */
	if( $qty.length ) {

		$qty.each(function( index ) {
			$( this ).attr('data-current-val', $(this).val() );
		});
		/*
		$(document).on('change', ipQ, function(){
			$(this).trigger("keyup");
		});*/
		//$(document).on('keyup change', ipQ, delay(function(){
		$(document).on('input', '.ttp-full-cart input.quantity', delay(function(){

			CheckOutButton.addClass('disabled');

			// $(this).on('change', function() {
				let value = $(this).val();
				let min = $(this).attr('min');
				// console.log(this)
				// console.log(value)
				// console.log(min)
				if(min != null && parseFloat(value) < parseFloat(min)){
					$(this).val(min);
				}
			//   });

			if( ! $(this).hasClass('update-qty') ) {
				$(this).addClass('update-qty');

				// Update and return value
				// return sum of {price:0,total:99} of all attr by product id
				let attrVal = cso.calcAllAttrByID($(this));
				cso.ChangeQty( $(this).data('ali-id'), $(this).data('sku-id'), attrVal.price );

				let nv = $(this).val();
				let sku_id = $(this).data('sku-id');
				if( $(this).data('sku-id').length == 0 ) {
					sku_id = $(this).data('ali-id');
				}

				if( nv.length > 0 ) {

					if( nv > 0 && nv != $(this).data('current-val') ) {

						// update
						//cso.updateQty( getProductData( $(this) ) );
						cso.updateQty_v2( sku_id, $(this).val(), attrVal.price );

					} else if( nv == 0 ) {

						$(this).val(1);

						if( $(this).data('current-val') != 1 ) {

							// update
							$(this).val(1);
							//cso.updateQty( getProductData( $(this) ) );
							cso.updateQty_v2( sku_id, $(this).val(), attrVal.price );
						} else {
							$(this).removeClass('update-qty');
						}
					} else {
						$(this).removeClass('update-qty');
					}
				} else {
					$(this).removeClass('update-qty');
				}
			}
		}, 600));

		$(document).on('focusout', ipQ, function(){

			if( $(this).val().length == 0 ) {

				var p = getProductData( $(this) );
				var qty = $(this).attr("min");

				$(this).val(qty);

				if( $(this).data('current-val') != 1 ) {
					// update
					//console.log( 'update - '+p.id,p.v0,p.v1 );
				}
			}
		});
	}

	/**
	 * Remove Item from Cart
	 */
	$(document).on('click', del, function(e) {
		e.preventDefault();
		CheckOutButton.addClass('disabled');

		let product_id = '';

		if (typeof $(this).data('sku-id') !== 'undefined') {
			//console.log($(this).data('sku-id'));
			// $(this).closest('.mc-line').addClass('wait-remove').append(spinner);
			// $('.sub-total').addClass('spinner');
			if (typeof $(this).data('product-id') !== 'undefined') {
				product_id = $(this).data('product-id')
			}
			
			removeItemFromCart_v2( $(this).data('sku-id'), product_id );
		} else {
			let sID = $(this).data('product-id');
			let sVar_0 = $(this).data('var-0');
			let sVar_1 = $(this).data('var-1');
			let SLine = $(del + '[data-product-id="'+sID+'"][data-var-0="'+sVar_0+'"][data-var-1="'+sVar_1+'"]');
	
			// SLine.closest(mcLine).addClass('wait-remove').append(spinner);
			// $('.sub-total').addClass('spinner');
			removeItemFromCart( sID, sVar_0, sVar_1 );
		}
	});

	/* ---------------------------------------------- Function ---------------------------------------------- */

	function delay(callback, ms) {
		var timer = 0;
		return function() {
			var context = this, args = arguments;
			clearTimeout(timer);
			timer = setTimeout(function () {
				callback.apply(context, args);
			}, ms || 0);
		};
	}

	function getProductData(Elm) {

		var da = Elm.closest(mcLine).find(del);
		return {
			id: da.data('product-id'),
			v0: da.data('var-0'),
			v1: da.data('var-1'),
			qty: Elm.val(),
		};
	}

	function updateQty(data) {

		var SLine = $(del + '[data-product-id="'+data.id+'"][data-var-0="'+data.v0+'"][data-var-1="'+data.v1+'"]');
		SLine.closest(mcLine).find(ipQ).prop('disabled', true).parent().addClass('relative');
		
		//console.log(data.id,data.v0,data.v1);
		/**
		* ajax Update Qty
		*/

		setTimeout(function () {
			SLine.closest(mcLine).find(ipQ).prop('disabled', false).removeClass('update-qty');
		}, 600);
	}

	/**
	 * Update Cart
	 */

	/**
	 * Remove Item from Cart
	 */
	function removeItemFromCart( productID, va_0, va_1 ){

		var data = {
			'action': 'ttp_remove_item_from_card',
			'product_id': productID,
			'product_va_0': va_0,
			'product_va_1': va_1,
		};

		var jqxhr = $.post( ajax_object_add2Card.ajax_url, data, function(response) {})
		  /*.done(function( response ) {})*/
		  .fail(function( response ) {})
		  .always(function( response ) {});

		jqxhr.always(function(response) {
			if( response == 'success' ) {
				$('.wait-remove').fadeOut(270).delay(270).remove();
				cso.reloadSubTotal();
				console.log('removeItemFromCart');
			}
		});
	}

	let removeCartQueue = $.Deferred().resolve().promise();
	let pendingRemoveCount = 0;

	function removeItemFromCart_v2(sku_id, product_id = null) {

		$('.wrap-sub-total').addClass('calculating-price');

		$('#ttp-payment [data-spinner]')
			.removeClass('d-none');

		pendingRemoveCount++;

		removeCartQueue = removeCartQueue.then(function() {

			return $.ajax({
				url: ajax_object_add2Card.ajax_url,
				type: 'POST',
				data: {
					action: 'ttp_remove_item_from_card_v2',
					taobao_ttp_x: $('meta[name="taobao-ttp-x"]').attr('content'),
					skuId: sku_id,
					productId: product_id
				}
			})
			.then(
				function(response) {

					response = $.trim(response);

					if (response === 'success') {

						$('.mc-line[data-sku-id="' + sku_id + '"]')
							.remove();

						console.log('Removed:', sku_id);

					} else {

						console.warn(
							'Remove failed:',
							sku_id,
							response
						);
					}
				},
				function(xhr, status, error) {

					console.error(
						'Remove cart error:',
						sku_id,
						status,
						error
					);
				}
			)
			.always(function() {

				pendingRemoveCount--;

				// ลบทั้งหมดใน queue เสร็จแล้ว
				if (pendingRemoveCount === 0) {

					console.log('All remove finished');

					cso.reloadSubTotal();
				}

			});

		});

		return removeCartQueue;
	}
});

(function($) {

    $.fn.updateVal = function( val ) {

        this.each( function( index ) {
            $(this).text( val );
			$(this).removeClass('spinner');
        });

    }

    $.fn.updateItemTotal = function( val, price ) {

		//var p = parseFloat( $(this).find('.mc-price').text().trim().replace(',', '') );
		//var qty = $(this).find('.quantity').val().trim();
		//var total = cso.thouSep2(p*qty);
		//let p = $(this).closest('.mc-calc').data('final-price');
		let p = $(this).find('.p-group.active .final-price').data('final-price');
		
		let total = cso.TodNiYom( p*val, 2 );

//console.log('price p',p,'val',val,'total',total);

		$(this).find('.p-totle').text( cso.thouSep2( total ) );
    }

    $.fn.updateItemTotal_v2 = function( qty, price ) {

		var p = parseFloat( $(this).find('.mc-price').text().trim().replace(',', '') );
		var qty = $(this).find('.quantity').val().trim();
		var total = cso.thouSep2(p*qty);

		$(this).find('.p-totle').text(666);
    }
    //$.fn.triggerGlly = function() {}

	var Numspace = 1;

    var namespace;
    namespace = {
        something : function() {
            alert('hello there!');
        },
        bodyInfo : function() {
            alert($('body').attr('class'));
        },
        thouSep2 : function (n) {
            n += '';
            var x = n.split('.');
            var x1 = x[0];
            var x2 = x.length > 1 ? '.' + x[1] : '';
            var rgx = /(\d+)(\d{3})/;
            while (rgx.test(x1)) {
                x1 = x1.replace(rgx, '$1' + ',' + '$2');
            }
            return x1 + x2;
        },
        reloadSubTotal : function () {

			Numspace += 1;

			var Numlocal = Numspace;

			$('#ttp-payment [data-spinner]')
				.removeClass('d-none');

			var requestUrl = location.href +
				(location.href.indexOf('?') !== -1 ? '&' : '?') +
				'stax=true';

			return $.get(requestUrl, function(data) {

				// parse HTML แค่ครั้งเดียว
				var $data = $(data);

				var $dataCart = $data
					.find('.ttp-cart')
					.first();

				var $dataSttThb = $data
					.find('#stt-thb');

				// Qty
				var totalQty = $dataCart
					.find('.total-qty')
					.first()
					.text();

				// Wallet
				var wallet_balance = $data
					.find('[data-wallet-balance]')
					.first()
					.data('wallet-balance');

				sessionStorage.setItem(
					'wallet_balance',
					wallet_balance
				);

				// Yuan subtotal
				var sub_total_raw = $dataCart
					.find('.sub-total')
					.first()
					.data('sub-total');

				// THB subtotal
				var sub_total_thb_raw =
					$dataSttThb.data('stt-thb');

				var subTotalXRT_Txt =
					$dataSttThb.text();

				sessionStorage.setItem(
					'sub_total',
					sub_total_thb_raw
				);

				var yuan_sign =
					'<i class="fa fa-jpy" aria-hidden="true"></i> ';

				// Yuan
				$('.ttp-cart .sub-total')
					.attr(
						'data-sub-total',
						sub_total_raw
					);

				$('.ttp-cart [data-sub-total]')
					.removeClass('spinner')
					.html(
						yuan_sign +
						cso.thouSep2(
							cso.TodNiYom(
								sub_total_raw,
								2,
								true
							)
						)
					);

				// Qty
				$('.ttp-cart .total-qty')
					.updateVal(totalQty);

				$('.flaticon-cart02 .count')
					.updateVal(totalQty);

				// THB
				$('#stt-thb, .sub-total-thb')
					.attr(
						'data-stt-thb',
						sub_total_thb_raw
					);

				$('.sub-total-thb')
					.html(
						'&#3647; ' +
						subTotalXRT_Txt
					);

				$('#stt-thb')
					.text(subTotalXRT_Txt);

				// VAT
				var subTotalXRT_Txt_vat = $data
					.find('#stt-thb-vat')
					.html();

				$('#stt-thb-vat')
					.html(subTotalXRT_Txt_vat);

				// Tax invoice
				var content_select_tax_invoice = $data
					.find('#content-select-tax_invoice')
					.html();

				$('#content-select-tax_invoice')
					.html(content_select_tax_invoice);

				// VAT under address
				var stt_thb_vat_under_address = $data
					.find('#stt-thb-vat-under-address')
					.html();

				$('#stt-thb-vat-under-address')
					.html(stt_thb_vat_under_address);

				// Address
				var content_selec_address = $data
					.find('#content_selec_address')
					.html();

				$('#content_selec_address')
					.html(content_selec_address);

				// Fixed price
				var show_price_fixed = $data
					.find('#show_price_fixed')
					.html();

				$('#show_price_fixed')
					.html(show_price_fixed);

				// Payment
				var payment_section = $data
					.find('#ttp-payment')
					.html();

				/*
				* เหมือน behavior เก่า:
				* เฉพาะ request ล่าสุดเท่านั้นที่ replace payment
				*/
				if (Numlocal == Numspace) {

					$('#ttp-payment')
						.html(payment_section);

					$('#ttp-payment [data-spinner]')
						.addClass('d-none');

					$('.wrap-sub-total')
						.removeClass('calculating-price');
				}

				// ของเดิมเรียกทุก response
				csAli.setPayment(
					wallet_balance,
					sub_total_thb_raw
				);

				console.log(
					'stt',
					sub_total_raw,
					sub_total_thb_raw
				);

			})
			.fail(function(xhr, status, error) {

				console.error(
					'reloadSubTotal error:',
					status,
					error
				);

			});
		},
		ChangeQty : function ( p_id, sku_id, p_price ) {

			$('.ttp-full-cart [data-ali-id="'+ p_id +'"]').each(function( index ) {

					let FinalPrice = $(this).closest('.mc-calc').find('.p-group.active .final-price');
					let price = FinalPrice.data('final-price');
					let promoPrice = FinalPrice.data('promo-price');
					let currentval = FinalPrice.data('current-val');
					if( price > promoPrice ) price = promoPrice;
					let line_tt = ( parseFloat( price ) * parseInt( currentval ) );

					// $(this).closest('.mc-calc').find('.p-totle').text( cso.TodNiYom( line_tt, 2 ) );
			});
		},
		updateQty_v2 : function (skuId, v, price) {

			var productLine = $(
				'.ttp-full-cart .mc-line[data-sku-id="' +
				skuId +
				'"]'
			);

			$('.wrap-sub-total')
				.addClass('calculating-price');

			$('#ttp-payment [data-spinner]')
				.removeClass('d-none');

			productLine
				.find('.qty input.quantity')
				.prop('disabled', true)
				.parent()
				.addClass('relative');

			var data = {
				action: 'ttp_update_item_qty_v2',
				taobao_ttp_x:
					$('meta[name="taobao-ttp-x"]').attr('content'),
				skuId: skuId,
				qty: v
			};

			var jqxhr = $.post(
				AJAXurl,
				data
			);

			jqxhr
				.done(function(response) {

					response = $.trim(response);

					if (response !== 'success') {
						return;
					}

					productLine
						.find('.mc-calc')
						.updateItemTotal(v, price);

					$('.qty input.quantity[data-sku-id="' + skuId + '"]')
						.data('current-val', v);

					// behavior เดิม
					cso.reloadSubTotal();

				})
				.fail(function(xhr, status, error) {

					console.error(
						'Qty update error:',
						skuId,
						status,
						error
					);

					$('.wrap-sub-total')
						.removeClass('calculating-price');

					$('#ttp-payment [data-spinner]')
						.addClass('d-none');

				})
				.always(function() {

					$('.qty input.quantity[data-sku-id="' + skuId + '"]')
						.prop('disabled', false)
						.removeClass('update-qty')
						.parent()
						.removeClass('relative spinner');

				});

			return jqxhr;
		},
		calcAllAttrByID : function ( Ths ) {


			Ths.closest('.mc-calc').find('[data-step]').removeClass('active');

			let pID = Ths.data('ali-id');
			let total = 0;
			let price = 0;

			// data-price-step-id="531872923297"
			$('[data-price-step-id="' + pID + '"] [data-step]').removeClass('active');

			$('.ttp-full-cart [data-ali-id="'+ pID +'"]').each(function( index ) {
				total += parseInt( $(this).val() );
			});

			$('.ttp-full-cart [data-price-step-id="'+ pID +'"]').each(function( index ) {

				$(this).find('.all-attr-qty').text( cso.TodNiYom( total ) );

				let qty = $(this).closest('.mc-calc').find('input.quantity').val();
				let priceTag = $(this).closest('.mc-calc').find('[data-provider]');
				let provider = priceTag.data('provider');
				let price_type = priceTag.data('price-type');
				let priceSteps = JSON.parse( $(this).find('.js_ali_'+pID).text() );
				let i = 0;
				$.each(priceSteps.price, function( index, step ) {
					if( total >= step.startAmount ) {
						price = step.price;
						i = index;
					}
				});

				if( provider != '1688' || price_type == 'sku-1688' ) {
					let FinalPrice = $(this).find('.p-group .final-price');
					price = FinalPrice.data('final-price');
					if( price > FinalPrice.data('promo-price') ) {
						price = FinalPrice.data('promo-price');
					}
				}
				if( price_type == 'sku-1688' ) i = 0;

//console.log('p',price, 'pt',price_type,'q', qty); // working

				$(this).find('[data-step="'+i+'"]').addClass('active');
				$(this).closest('.mc-calc').find( '.mc-price').text(price);
				$(this).closest('.mc-calc').find( '.mc-price').attr( 'data-mc-price', price );

				let xrt = $('#exchange-rate').data('exchange-rate');
				let price_thb = xrt * price;
				//let tt_thb = price_thb * Ths.val();
				let tt_thb = price_thb * qty;

				// Update item THB Price
				$(this).closest('.mc-calc').find( '.p.est-thb').html( '&#3647; ' + cso.TodNiYom( price_thb ) );

				// Update item THB Total
				$(this).closest('.mc-calc').find( '.tt.est-thb').html( '&#3647; ' + cso.TodNiYom( tt_thb ) );

				$(this).closest('.mc-calc').attr( 'data-final-price', price );
			});

			return {
				price: price,
				total: total
			};
		},
		set_AttrPrice : function ( qty ) {

			$('[data-step]').removeClass('active');

			let price = 0;
			let i = 0;
			$.each(ttp_price_steps.price, function( index, step ) {
				if( qty >= step.startAmount ) {
					//console.log( 'qty => '+qty, 'begin => ' + step.begin, 'price => '+step.price );
					price = step.price;
					i = index;
					//console.log(i,step.begin,qty);
				}
			});

			$('[data-step="'+i+'"]').addClass('active');
		},
        updateQty : function ( productData ) {

            var UpdateLine = $('.ttp-full-cart .del-btn[data-product-id="'+productData.id+'"][data-var-0="'+productData.v0+'"][data-var-1="'+productData.v1+'"]').closest('.mc-line');
            UpdateLine.find('.qty input.quantity').prop('disabled', true).parent().addClass('relative');
            // $('.ttp-cart .sub-total').addClass('spinner');
            let data = {
                'action': 'ttp_update_item_qty',
                'product_id': productData.id,
                'product_va_0': productData.v0,
                'product_va_1': productData.v1,
                'qty': productData.qty,
            };

            let jqxhr = $.post( AJAXurl, data, function(response) {})
                /*.done(function( response ) {})*/
                .fail(function( response ) {})
                .always(function( response ) {});

            jqxhr.always(function(response) {
                if( response == 'success' ) {
                    UpdateLine.find('.mc-calc').updateItemTotal(productData.qty);
                    cso.reloadSubTotal();
                    UpdateLine.find('.qty input.quantity').prop('disabled', false).removeClass('update-qty').parent().removeClass('relative');
                    UpdateLine.find('.qty input.quantity').data('current-val', productData.qty);
                }
            });
        },
        GenGlly : function ( rs ) {

                var Thumb = '';
                var link = '';

            rs.find('.product-single-image img').each(function( index ) {

                var src = cso.get_original_img( $(this).attr('src') );
                if(index > 0){
                    link += '<li><a href="' + src + '"><img src="' + src + '"></a></li>';
                } else {
                    Thumb = '<div class="glly-thumb"><ul><li><a href="' + src + '"><img src="' + src + '"></a></li></ul></div>';
                }
            });

            var Links = '<div class="glly-items"><ul>' + link + '</ul></div>';

            rs.find('.product-single-image').after('<div class="col-lg-4 col-md-4 col-sm-4 product-single-image glly">' + Thumb + Links + '</div>');
            rs.find('.product-single-image').not('.glly').remove();

            return rs;
        },
        setVariable : function () {

            // no-gap
            $('.form-check-label img').parent().addClass('no-gap');
            $('.form-check-label img').parent().append('<span class="triangle-bottomright c-check"></span><i class="fa fa-check c-check" aria-hidden="true"></i>');

            $(document).on('click','.form-check-label',function(e){
                e.preventDefault();
                $(this).prev().prop( "checked", true );

                // image border
                $(this).parent().find('.form-check-label').removeClass('active');
                $(this).addClass('active');

                // send image to big thumbnail
                if($(this).find('img').length){
                    var sc = $(this).find('img').attr('src');
                    $('.glly-thumb ul li a img').attr('src',sc);
                }
            });

        },
        setCartButton : function () {
            var waper = $('#addCart .add-to-cart .action-wrapper');
			waper.find('i').remove();
			
			if( TTPcargo.is_user_login == true ) {
				waper.prepend('<i class="fa fa-cart-plus" aria-hidden="true"></i>');
			} else {
				$('#addCart').addClass('not-login');
			}

			var user_status = 0;
			if( TTPcargo.is_user_login == true ) user_status = 1;
			$('#addCart').attr('data-login', user_status);
			$('#addCart').attr('data-url', TTPcargo.login_url);
			$('#addCart .action-name').text( TTPcargo.text_add_to_cart );

        },
        clearCart : function () {

            $('.flaticon-cart02 .count').text( '0' );
            $('.ttp-mini-cart').html('Your cart is empty.');

        },
        setQty2text : function () {

            $('.mc-line .qty').each(function( index ) {
                $(this).html( $(this).find('.quantity').val() );
            });
        },
		goSingleProduct : function ( ttpProvider, pID ) {
            var url = 'https://taobao.ttpcargo.com/product?provider=' + ttpProvider + '&itemId=' + pID;
            window.open( url, '_self' );
		},
		goSearchPage : function ( provider, keyword, gopage ) {
			let url = 'https://taobao.ttpcargo.com/search?provider=' + provider + '&keyword=' + keyword + '&gopage=' + gopage;
            //let url = 'https://taobao.ttpcargo.com/product?provider=' + provider + '&itemId=' + pID;
            window.open( url, '_self' );
        },
		get_original_img : function (url) {
			var jpg = url.split('.jpg');
			var src = url;
			if( jpg.length > 2 ){
				src = jpg[0] + '.jpg';
			}
			return src;
		},
		TodNiYom : function ( num, decimalN, keepZeroDec ) {

			if( decimalN > 0 ) {
				var numN = parseFloat( num ).toFixed( decimalN );
			} else {
				var numN = Math.round( num * 100 ) / 100 ;
			}
			let numS = numN.toString();
			if( numS.includes('.') ) {
				let numArr = numS.split('.');
				let zeroQty = numArr[1].split('0').length - 1;
				if( zeroQty == decimalN && keepZeroDec !== true ) {
					numN = Number( numArr[0] );
				}
			}
			decimalN = null;
			return numN.toLocaleString();
		}
    };

    window.cso = namespace;

}(jQuery));



// // ---------------- ลบสินค้า ----------------
// document.addEventListener("click", function (e) {
//     const btn = e.target.closest(".del-btn");
//     if (!btn) return;

//     const item = btn.closest(".mc-line");
//     const shopLine = btn.closest(".shop_line");

//     if (item) item.remove();
//     if (shopLine && shopLine.querySelectorAll(".mc-line").length === 0) {
//         shopLine.remove();
//     }

//     forceCheckReady();
// });


// // ---------------- Utility: รอ DOM ให้ update เสร็จก่อนค่อยเช็ค ----------------
// function forceCheckReady() {
//     let retries = 25; // 25 × 80ms = 2 วินาที
//     const timer = setInterval(() => {

//         const addrId    = Number(document.querySelector("#addr_id")?.textContent.trim() || 0);
//         const taxAddrId = Number(document.querySelector("#tax_invoice_addr_id")?.textContent.trim() || 0);

//         const slipVal = document.querySelector("#bacs_upload_slip")?.value.trim() || "";
//         const hasSlip = slipVal !== "";

//         const hasAddress = addrId > 0 || taxAddrId > 0;
//         const hasItem = document.querySelectorAll(".mc-line").length > 0;

//         if ((hasAddress && hasSlip && hasItem) || retries <= 0) {
//             updateCheckoutButton();
//             clearInterval(timer);
//         }

//         retries--;

//     }, 80);
// }


// // ---------------- เลือกที่อยู่ ----------------
// document.addEventListener("click", function (e) {
//     if (e.target.closest(".popup-multiple-address")) {
//         setTimeout(() => {
//             restoreSlipPreview();
//             forceCheckReady();
//         }, 200);
//     }
// });


// // ---------------- Observe addr_id (เวลาระบบเขียน DOM ที่อยู่) ----------------
// const addrIdEl = document.querySelector("#addr_id");
// if (addrIdEl) {
//     new MutationObserver(() => {
//         setTimeout(() => {
//             restoreSlipPreview();
//             forceCheckReady();
//         }, 200);
//     }).observe(addrIdEl, { childList: true, characterData: true, subtree: true });
// }


// // ---------------- อัปโหลดสลิป ----------------
// document.addEventListener("change", function (e) {
//     if (!e.target.matches("#upload-file")) return;

//     const fileInput = e.target;
//     const dest = document.querySelector("#destination");
//     const hidden = document.querySelector("#bacs_upload_slip");

//     if (!dest) return;

//     hidden.value = "";
//     dest.innerHTML = "";

//     if (!fileInput.files || !fileInput.files[0]) {
//         forceCheckReady();
//         return;
//     }

//     const file = fileInput.files[0];
//     const url = URL.createObjectURL(file);

//     // แสดง preview
//     dest.innerHTML = `
//         <ul>
//             <li>
//                 <img src="${url}" class="payment-slip">
//                 <div class="file-info">${file.name}: ${file.size} bytes</div>
//             </li>
//         </ul>
//     `;

//     // อ่านไฟล์เป็น base64
//     const reader = new FileReader();
//     reader.onload = function (event) {
//         hidden.value = event.target.result || "";
//         setTimeout(forceCheckReady, 100);
//     };
//     reader.readAsDataURL(file);
// });


// // ---------------- Restore preview (กัน theme ลบรูป) ----------------
// function restoreSlipPreview() {
//     const hidden = document.querySelector("#bacs_upload_slip");
//     const dest = document.querySelector("#destination");

//     if (!hidden || !dest) return;

//     const base64 = hidden.value.trim();
//     if (!base64) return;

//     const preview = dest.querySelector(".payment-slip");
//     if (preview) return;

//     dest.innerHTML = `
//         <ul>
//             <li>
//                 <img src="${base64}" class="payment-slip">
//             </li>
//         </ul>
//     `;
// }


// // ---------------- เฝ้าดู #destination ว่าถูกรบกวนไหม ----------------
// const destination = document.getElementById("destination");
// if (destination) {
//     new MutationObserver(() => {
//         const preview = destination.querySelector(".payment-slip");

//         if (!preview) restoreSlipPreview();

//         setTimeout(forceCheckReady, 100);
//     }).observe(destination, { childList: true, subtree: true });
// }


// function updateCheckoutButton() {
//     const checkoutBtn = document.getElementById("checkout1");
//     if (!checkoutBtn) return;

//     const hasItem = document.querySelectorAll(".mc-line").length > 0;

//     // --- ค่าที่อยู่ ---
//     const addrId     = Number(document.querySelector("#addr_id")?.textContent.trim() || 0);
//     const taxAddrId  = Number(document.querySelector("#tax_invoice_addr_id")?.textContent.trim() || 0);

//     const hasAddress = addrId > 0;          // ที่อยู่จัดส่ง (ต้องมีเสมอ)
//     const hasTaxAddr = taxAddrId > 0;       // ที่อยู่ออกใบกำกับภาษี

//     // --- ตรวจว่าเลือกโหมดภาษีไหม ---
//     const wantsTaxInvoice = document.querySelector("#tax_invoice_true")?.checked ?? false;

//     // --- เช็คสลิป ---
//     const slipVal = document.querySelector("#bacs_upload_slip")?.value.trim() || "";
//     const hasSlip = slipVal !== "";

//     let canCheckout = false;

//     if (hasItem && hasAddress && hasSlip) {

//         if (wantsTaxInvoice) {
//             // ถ้าเลือกใบกำกับภาษี → ต้องมีที่อยู่ออกใบกำกับด้วย
//             canCheckout = hasTaxAddr;
//         } else {
//             // ถ้าไม่เลือกใบภาษี → ใช้แค่ที่อยู่จัดส่งพอ
//             canCheckout = true;
//         }
//     }

//     checkoutBtn.classList.toggle("disabled", !canCheckout);
//     checkoutBtn.disabled = !canCheckout;
// }





// document.addEventListener("click", function(e) {
//     const btn = e.target.closest(".del-btn");
//     if (!btn) return;

//     // สินค้าที่จะลบ
//     const item = btn.closest(".mc-line");

//     // กล่องร้านนั้น
//     const shopLine = btn.closest(".shop_line");

//     // ลบสินค้าออกจาก DOM
//     item.remove();

//     // ถ้าในร้านนี้ไม่มีสินค้าแล้ว → ลบร้านออกด้วย
//     if (shopLine.querySelectorAll(".mc-line").length === 0) {
//         shopLine.remove();
//     }

//     // ตรวจสอบปุ่มสั่งซื้อ
//     checkCanCheckout();
// });


// function checkCanCheckout() {
//     const checkoutBtn = document.getElementById("checkout1");

//     // เช็กว่ามีสินค้าไหม
//     const hasItem = document.querySelectorAll(".mc-line").length > 0;

//     // เช็กว่ามีที่อยู่ไหม
//     const addressInput = document.querySelector("#shipping-address");
//     const hasAddress = addressInput && addressInput.value.trim() !== "";

//     // ถ้ามีสินค้าด้วย + มีที่อยู่ด้วย → เปิดปุ่ม
//     if (hasItem && hasAddress) {
//         checkoutBtn.classList.remove("disabled");
//         checkoutBtn.disabled = false;
//     } else {
//         checkoutBtn.classList.add("disabled");
//         checkoutBtn.disabled = true;
//     }
// }


// // ---------------- ลบสินค้า ----------------
// document.addEventListener("click", function(e) {
//     const btn = e.target.closest(".del-btn");
//     if (!btn) return;

//     const item = btn.closest(".mc-line");
//     const shopLine = btn.closest(".shop_line");

//     if (item) item.remove();

//     if (shopLine && shopLine.querySelectorAll(".mc-line").length === 0) {
//         shopLine.remove();
//     }

//     checkCanCheckout();
// });


// // ---------------- เลือกที่อยู่ (แค่เปิด popup) ----------------
// // อันนี้จะมีหรือไม่มีก็ได้ แต่มีไว้ไม่เสียหาย
// document.addEventListener("click", function (e) {
//     if (e.target.closest(".popup-multiple-address")) {
//         // แค่กันไว้ เผื่อบางธีมอัปเดต addr_id ทันที
//         setTimeout(checkCanCheckout, 300);
//     }
// });


// // ---------------- Observe การเปลี่ยนแปลงของ addr_id โดยตรง ----------------
// const addrIdEl = document.querySelector("#wrap-checkout-btn #addr_id");
// if (addrIdEl) {
//     const addressObserver = new MutationObserver(() => {
//         // เวลาที่ระบบอัปเดตค่า addr_id (หลังเลือกที่อยู่เสร็จ)
//         setTimeout(checkCanCheckout, 50);
//     });
//     addressObserver.observe(addrIdEl, {
//         childList: true,
//         characterData: true,
//         subtree: true
//     });
// }


// const destination = document.getElementById("destination");
// if (destination) {
//     const slipObserver = new MutationObserver(() => {
//         setTimeout(checkCanCheckout, 100);
//     });
//     slipObserver.observe(destination, {
//         childList: true,
//         subtree: true
//     });
// }


// function checkCanCheckout() {
//     const checkoutBtn = document.getElementById("checkout1");
//     if (!checkoutBtn) return;

//     // 1) เช็คว่ามีสินค้าไหม
//     const hasItem = document.querySelectorAll(".mc-line").length > 0;

//     // 2) ที่อยู่จัดส่งต้องมีค่า
//     const addrIdNode = document.querySelector("#wrap-checkout-btn #addr_id");
//     const addrId = addrIdNode ? addrIdNode.textContent.trim() : "";
//     const hasAddress = addrId !== "" && Number(addrId) > 0;

//     // 3) มีสลิปหรือยัง?
//     const slipVal = document.getElementById("bacs_upload_slip")?.value.trim() || "";
//     const hasSlip = slipVal !== "";

//     // 4) ผู้ใช้เลือก "ออกใบกำกับภาษี" หรือไม่?
//     const wantsTaxInvoice = document.getElementById("tax_invoice_true")?.checked ?? false;

//     // 5) ถ้าต้องการใบกำกับภาษี → ต้องเช็คอีกที่อยู่
//     const taxAddrIdNode = document.querySelector("#wrap-checkout-btn #tax_invoice_addr_id");
//     const taxAddrId = taxAddrIdNode ? taxAddrIdNode.textContent.trim() : "";
//     const hasTaxAddress = taxAddrId !== "" && Number(taxAddrId) > 0;

//     // ---------------------------------
//     // 😎 เงื่อนไขเปิดปุ่มแบบ FINAL
//     // ---------------------------------
//     let canCheckout = false;

//     if (hasItem && hasAddress && hasSlip) {

//         if (wantsTaxInvoice) {
//             // ต้องการใบกำกับภาษี → ต้องมีที่อยู่ออกใบกำกับด้วย
//             canCheckout = hasTaxAddress;
//         } else {
//             // ไม่ต้องการใบกำกับภาษี
//             canCheckout = true;
//         }
//     }

//     // -----------------------------
//     // เปิด / ปิด ปุ่ม
//     // -----------------------------
//     checkoutBtn.classList.toggle("disabled", !canCheckout);
//     checkoutBtn.disabled = !canCheckout;
// }
document.addEventListener("click", function(e) {
    const btn = e.target.closest(".del-btn");
    if (!btn) return;

    // สินค้าที่จะลบ
    const item = btn.closest(".mc-line");

    // กล่องร้านนั้น
    const shopLine = btn.closest(".shop_line");

    // ลบสินค้าออกจาก DOM
    item.remove();

    // ถ้าในร้านนี้ไม่มีสินค้าแล้ว → ลบร้านออกด้วย
    if (shopLine.querySelectorAll(".mc-line").length === 0) {
        shopLine.remove();
    }

    // ตรวจสอบปุ่มสั่งซื้อ
    checkCanCheckout();
});


function checkCanCheckout() {
    const checkoutBtn = document.getElementById("checkout1");

    // เช็กว่ามีสินค้าไหม
    const hasItem = document.querySelectorAll(".mc-line").length > 0;

    // เช็กว่ามีที่อยู่ไหม
    const addressInput = document.querySelector("#shipping-address");
    const hasAddress = addressInput && addressInput.value.trim() !== "";

    // ถ้ามีสินค้าด้วย + มีที่อยู่ด้วย → เปิดปุ่ม
    if (hasItem && hasAddress) {
        checkoutBtn.classList.remove("disabled");
        checkoutBtn.disabled = false;
    } else {
        checkoutBtn.classList.add("disabled");
        checkoutBtn.disabled = true;
    }
}






