jQuery(function($){
    const urlAPI = "https://ttpcargo.com";

    let domIconFavorite =
        '<a class="link-dropdown style2 link-favorite" href="https://' + window.location.hostname + '/สินค้าที่ถูกใจ">' +
            '<span class="icon fa fa-heart favoreit-icon"  aria-label="สินค้าที่ถูกใจ">' +
                '<span class="favorite-cout"></span>' +
            '</span>' +
        '</a>';

    function setCartAriaLabel() {
    $('a.link-dropdown.style2:has(.flaticon-cart02) .flaticon-cart02')
        .attr('aria-label', 'ตะกร้าสินค้า');
}

    let getStrTTP = $('#header>.header-top>.container>span').text() || '';
    let user_ttpID = '';

    if (getStrTTP.indexOf(' ') !== -1) {
        user_ttpID = getStrTTP.substring(getStrTTP.indexOf(' ') + 1).substr(3).trim();
    }

    $('.header-control').append(domIconFavorite);

    setCartAriaLabel();

    const observer = new MutationObserver(function() {
        setCartAriaLabel();
    });

    if (document.body) {
        observer.observe(document.body, {
            childList: true,
            subtree: true
        });
    }

    if (user_ttpID !== "") {
        $.ajax({
            url: urlAPI + "/api/favorite_count.php",
            type: "post",
            cache: false,
            dataType: "json",
            data: {
                user_id: user_ttpID
            },
            success: function(response) {
                $('.favorite-cout').text(response.count || '0');
            },
            error: function() {
                $('.favorite-cout').text('0');
            }
        });
    } else {
        $('.favorite-cout').text('0');
    }
});