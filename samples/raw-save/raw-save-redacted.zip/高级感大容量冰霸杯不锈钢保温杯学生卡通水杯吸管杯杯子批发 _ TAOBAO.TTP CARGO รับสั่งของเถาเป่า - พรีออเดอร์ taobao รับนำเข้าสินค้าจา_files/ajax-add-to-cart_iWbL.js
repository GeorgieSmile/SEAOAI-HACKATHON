jQuery(function($){

	// v.0.0.1
	var dev = 'ajax-add-to-cart.js v.6';
	//console.log( dev );

	var TTpProduct	= $('#ttp-product');
	var addCart		= '#addCart';
	var sA			= '#sec-alert';
	var va_0		= 'input[name="variants_0"]';
	var va_1		= 'input[name="variants_1"]';

	/**
	 * Add to Cart
	 */
	$(document).on('click', addCart, function(e) {
		e.preventDefault();
		if( ! $(this).hasClass('spinner') ){

			if( $(this).hasClass('not-login') ) {
				// Go to login page
				window.open( $(this).data('url'), '_blank' );
			} else {
				$(this).addClass('spinner').prop('disabled', true);
				addToCartAction();
			}
		}
	});

	/**
	 * Close Alert
	 */
	$(document).on('click', function (e) {
		if ($(e.target).closest(sA).length === 1 && $(e.target).attr('id') == 'sec-alert'){
			closeAlert();
		}
		var tID = $(e.target).attr('id');
		if( tID == 'close-sec-alert' || tID == 'btn-continue-shopping' ){
			closeAlert();
		}
	});

	/**
	 * Go to /cart page.
	 */
	$(document).on('click', '.btn-go', function (e) {
		e.preventDefault();
		if (typeof $(this).data('link') !== 'undefined') {
			location.href = $(this).data('link');
		}
	});

	if( TTpProduct.length ){
		$('body').on('DOMNodeInserted', '.product-single', function(e) {
			$(addCart).removeAttr('disabled');
		});
	}
	/* ---------------------------------------------- Function ---------------------------------------------- */

	function closeAlert(){
		$(sA).fadeOut(280);
		setTimeout(function(){
			$(sA).removeClass('d-flex').removeAttr('style');
		}, 300);
	}

	function addToCartAction() {
		var productData = { 
			"product_id"		: TTpProduct.data('itemid'),
			"product_name"		: $('.product-single-info h2').text(),
			"provider"			: TTpProduct.data('provider'),
			"price"				: getProductPrice('#currentPrice'),
			"thumbnail"			: $('#product-slider').find('img:first').data('large'),
			"product_quantity"	: $('#quantity-input').val(),
		};

		/**
		 * Variable 0
		 */
		var aC = '';
		if($(va_0).length && $(va_0).is(':checked')){
			productData['variants_0'] = {
				"label" : $(va_0+':checked').data('label'),
				"image" : $(va_0+':checked').data('image'),
				"data"	: $(va_0+':checked').data('data'),
				"group"	: $(va_0+':checked').data('group'),
				"label"	: $(va_0+':checked').data('label'),
			};
		} else {
			aC += $(va_0).closest('tr').find('td.label').text().trim();
		}

		/**
		 * Variable 1
		 */
		if($(va_1).length && $(va_1).is(':checked')){
			productData['variants_1'] = {
				"label" : $(va_1+':checked').data('label'),
				"image" : $(va_1+':checked').data('image'),
				"data"	: $(va_1+':checked').data('data'),
				"group"	: $(va_1+':checked').data('group'),
				"label"	: $(va_1+':checked').data('label'),
			};
		} else {
			if($(va_0).length && ! $(va_0).is(':checked')){
				if($(va_1).length && ! $(va_1).is(':checked')) aC += ' & ';
			}
			aC += $(va_1).closest('tr').find('td.label').text().trim();
		}

		if(aC.length){
			alert('Please Select '+aC);
			ActiveAddCart();
		} else {
			/** working
			 * Add to Cart
			 */
			addToCartAjax( productData );
		}
	}
	function getProductPrice(Ic) {

		if($(Ic).find('del').length > 0){
			var rP = $('<div>'+$('#currentPrice').html()+'</div>');
			rP.find('del').remove();
			var oP = rP.text().trim();
		} else {
			var oP = $('#currentPrice').text().trim();
		}
		var oP = oP.replace(',', '');
		return oP;
	}
	function getProductImage(){

		var src = '';

		// img 1
		var va_1_img		= $(va_1+':checked').data('image');
	
		if( $(va_0).length && $(va_0).is(':checked') && $(va_0+':checked').data('image').length > 0 ){
			src = $(va_0+':checked').data('image');
		} else if( $(va_1).length && $(va_1).is(':checked') && $(va_1+':checked').data('image').length > 0 ){
			src = $(va_1+':checked').data('image');
		} else {
			src = $('#product-slider').find('img:first').data('large');
		}
		return src;
	}
	function getProductAttr(){

		var attr = '';
		var at1 = false;

		if($(va_0).length && $(va_0).is(':checked')){
			if( $(va_0+':checked').data('image').length > 0 ){
				attr += attr + $(va_0+':checked').data('group') +': '+ $(va_0+':checked').data('label');
				at1 = true;
			}
		}

		if($(va_1).length && $(va_1).is(':checked')){
			if( $(va_1+':checked').data('image').length > 0 ){
				if(at1 == true){
					attr += ', ';
				}
				attr += attr + $(va_1+':checked').data('group') +': '+ $(va_1+':checked').data('label');
			}
		}
		return attr;
	}

	/**
	 * Add 1 product to Cart
	 */
	function addToCartAjax( productData ){

		var data = {
			'action': 'ttp_add_to_card',
			'txt': ajax_object_add2Card.txtx,
			'product_data': productData,
		};

		var jqxhr = $.post( ajax_object_add2Card.ajax_url, data, function(response) {
			ActiveAddCart();
		})
		  /*.done(function( response ) {
			console.log( ".done success" );
		  })*/
		  .fail(function( response ) {
			//console.log( response );
		  })
		  .always(function( response ) {});

		jqxhr.always(function(response) {
			successAlert(productData);
			reloadCart();
			console.log('Added to cart --> '+response);
		});
	}

	/**
	 * Add to Cart Alert
	 */
	function successAlert( pD ){

		// Image
		$(sA+' .wrap-img img').attr('src', getProductImage());

		// Title
		$(sA+' .title').text(pD.product_name);

		// Attr
		$(sA+' .attr').text( getProductAttr() );

		// Quantity
		$(sA+' .qty').text(pD.product_quantity);

		// Price
		var price = parseFloat( pD.price ).toFixed( 2 );
		$(sA+' .u-price').text( cso.thouSep2(price) );

		// Total
		var tt = pD.product_quantity * pD.price;
		var tt1 = parseFloat( tt ).toFixed( 2 );
		$(sA+' .s-total').text(cso.thouSep2(tt1));

		$(sA).addClass('d-flex');
	}

	function ActiveAddCart(){
		$(addCart).removeClass('spinner').prop('disabled', false);
	}

	function reloadCart() {
		$.get(location.href, function (data) {

			var totalQty = $(data).find('.ttp-mini-cart .total-qty').first().text();
			$('.flaticon-cart02 .count').updateVal( totalQty );

			data = $(data).find('.ttp-mini-cart:first').html();
			$('.ttp-mini-cart').html(data);
			console.log('minicart reloaded!');
		});
	}
});